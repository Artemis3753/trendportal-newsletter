<?php
/**
 * Plugin Name: TP Cardnews Helper
 * Description: 관리자 전용 탭 "트란시스 카드뉴스 도우미". 피그마 플러그인(트란시스 카드뉴스 읽기)이 만든 zip과 인스타 캡션·영상 주소를 주문으로 받고, 처리 결과(초안·미리보기·고친 것 목록)를 보여 준다. 처리는 사이트 밖(tools/cardnews/cardnews.py)이 REST로 주문을 가져가서 한다.
 * Version: 1.5.0
 * Author: Trendportal
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * 10/17 사용자 결정(A, 탭 먼저): 주문 창구는 사이트 관리자 탭, 요리는 사이트 밖.
 * 워드프레스(PHP) 안에서는 큰 사진 처리에 시간·메모리 제한이 있고, alt·제목·오타 같은 판단을 할 Claude도 없어서다.
 * 그래서 이 플러그인은 주문을 받아 두고 상태만 보여 준다. 가져가는 쪽은 REST(아래 tp-cardnews/v1)로 온다.
 *
 * 저장: 주문 = 비공개 글 유형(tp_cn_order) 하나 + 메타. 따로 DB 표를 만들지 않아 지우기·백업이 글과 같다.
 * zip = uploads/tp-cardnews/ 아래 무작위 이름. 미디어 라이브러리에 섞이지 않게 하고, 주소를 추측할 수 없게 한다.
 */

const TP_CN_TYPE = 'tp_cn_order';
const TP_CN_DIR  = 'tp-cardnews';
const TP_CN_SLUG = 'tp-cardnews';
const TP_CN_MAX  = 200 * 1024 * 1024; // zip 상한. 764(카드 17장)가 16MB였다

// 상태 이름은 영어로 저장하고, 화면에는 한국어로 (REST로 오가는 값이 글자 깨짐 걱정 없게)
const TP_CN_STATUS = array(
	'new'     => '주문 접수',
	'revise'  => '수정 접수', // 완성된 초안에 "고쳐 주세요"가 들어온 주문 (10/17 사용자: 관리자 창에서 메모로 고치기)
	'working' => '요리 중',
	'done'    => '완성',
	'failed'  => '주방 멈춤',
);

add_action(
	'init',
	function () {
		register_post_type(
			TP_CN_TYPE,
			array(
				'label'    => '카드뉴스 주문',
				'public'   => false,
				'show_ui'  => false, // 목록은 도우미 탭이 직접 그린다
				'supports' => array( 'title' ),
			)
		);
	}
);

// ── 파일 ────────────────────────────────────────────────

function tp_cn_dir() {
	$dir = wp_upload_dir()['basedir'] . '/' . TP_CN_DIR;
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
		// 폴더 목록이 열리지 않게 빈 index.php
		file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" );
	}
	return $dir;
}

// 주문을 지우면 zip도 같이 지운다
add_action(
	'before_delete_post',
	function ( $post_id ) {
		if ( get_post_type( $post_id ) !== TP_CN_TYPE ) {
			return;
		}
		$zip = get_post_meta( $post_id, '_tp_cn_zip', true );
		if ( $zip && is_file( tp_cn_dir() . '/' . $zip ) ) {
			unlink( tp_cn_dir() . '/' . $zip );
		}
	}
);

/**
 * 영상 칸: 한 줄에 "카드 번호 = 주소". "4 https://…", "4: https://…", "4번 https://…"도 받아 준다.
 * 돌려주는 값: [ 번호 => 주소 ] 또는 못 읽은 줄이 있으면 WP_Error.
 */
function tp_cn_parse_videos( $text ) {
	$out = array();
	foreach ( preg_split( '/\R/', (string) $text ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( ! preg_match( '/^(\d{1,2})\s*번?\s*[=:.]?\s*(https?:\/\/\S+)$/u', $line, $m ) ) {
			return new WP_Error( 'tp_cn_video', "영상 칸에서 이 줄을 못 읽었어요: {$line} — \"4 = https://…\"처럼 카드 번호와 주소를 적어 주세요" );
		}
		$out[ (string) (int) $m[1] ] = esc_url_raw( $m[2] );
	}
	return $out;
}

/**
 * 받은 zip이 피그마 플러그인 결과인지 본다 (figma/scan.json이 있어야 한다).
 * 돌려주는 값: 묶음 이름(scan.json의 group.name) 또는 WP_Error. ZipArchive가 없는 서버면 검사를 건너뛴다.
 */
function tp_cn_check_zip( $path, $filename ) {
	$fallback = preg_replace( '/\.zip$/i', '', $filename );
	if ( ! class_exists( 'ZipArchive' ) ) {
		return $fallback;
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $path ) ) {
		return new WP_Error( 'tp_cn_zip', 'zip 파일을 열 수 없어요. 내려받다 끊긴 파일일 수 있어요 — 다시 받아 주세요' );
	}
	$scan = $zip->getFromName( 'figma/scan.json' );
	$zip->close();
	if ( false === $scan ) {
		return new WP_Error( 'tp_cn_zip', "이 zip에는 figma/scan.json이 없어요. 피그마 플러그인 '트란시스 카드뉴스 읽기'로 받은 zip인지 확인해 주세요" );
	}
	$data = json_decode( $scan, true );
	return ! empty( $data['group']['name'] ) ? $data['group']['name'] : $fallback;
}

// ── 초인종: 주문이 들어오면 클라우드의 셰프(Claude Code routine)를 바로 깨운다 ──────────
/*
 * 10/17 사용자 결정 A(즉시 신호). 매시간 알람으로 깨우면 최대 1시간을 기다리고 주문 없는 날에도 빈손으로 깨어나서다.
 * routine의 API 트리거 주소로 POST 한 번 = 셰프 한 번 출근. 열쇠(토큰)는 이 사이트 설정에만 두고 화면에 다시 보여 주지 않는다.
 * 열쇠가 새도 할 수 있는 건 "셰프 깨우기"뿐이다: 셰프는 신호에 딸린 글을 무시하고 탭의 '접수' 주문만 처리한다(tools/cardnews/PROMPT.md).
 */
const TP_CN_BELL = 'tp_cn_bell'; // 옵션 이름: array( 'url' => …, 'token' => … )

function tp_cn_ring( $id ) {
	$bell = get_option( TP_CN_BELL, array() );
	if ( empty( $bell['url'] ) || empty( $bell['token'] ) ) {
		$err = '초인종이 아직 설정되지 않았어요 (아래 "셰프 초인종 설정")';
	} else {
		$res = wp_remote_post(
			$bell['url'],
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization'     => 'Bearer ' . $bell['token'],
					// routine 문서(10/17 확인)가 요구하는 머리글. 실험 기능이라 바뀌면 이 날짜만 고친다
					'anthropic-beta'    => 'experimental-cc-routine-2026-04-01',
					'anthropic-version' => '2023-06-01',
					'Content-Type'      => 'application/json',
				),
				// 셰프는 이 글을 따르지 않는다. 실행 기록에서 어느 주문 때 깨웠는지 알아보는 표시일 뿐
				'body'    => wp_json_encode( array( 'text' => "order {$id}" ) ),
			)
		);
		$code = is_wp_error( $res ) ? 0 : wp_remote_retrieve_response_code( $res );
		if ( $code >= 200 && $code < 300 ) {
			update_post_meta( $id, '_tp_cn_rang_at', time() );
			delete_post_meta( $id, '_tp_cn_bell_err' );
			return true;
		}
		$err = is_wp_error( $res )
			? '셰프에게 연결하지 못했어요: ' . $res->get_error_message()
			: "셰프가 응답하지 않았어요 (오류 {$code}" . ( 401 === $code ? ', 열쇠가 틀렸거나 바뀌었어요' : '' ) . ')';
	}
	update_post_meta( $id, '_tp_cn_bell_err', $err );
	return false;
}

// 초인종 설정 저장 (관리자만). 열쇠 칸을 비워 두면 기존 열쇠를 그대로 둔다 — 화면에 열쇠를 다시 채워 보여 주지 않아서
add_action(
	'admin_post_tp_cn_bell',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 바꿀 수 있어요' );
		}
		check_admin_referer( 'tp_cn_bell' );
		$bell  = get_option( TP_CN_BELL, array() );
		$url   = esc_url_raw( trim( wp_unslash( $_POST['bell_url'] ?? '' ) ) );
		$token = trim( sanitize_text_field( wp_unslash( $_POST['bell_token'] ?? '' ) ) );
		$back  = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		// 엉뚱한 곳으로 열쇠를 보내지 않게, routine 주소 모양만 받는다
		if ( ! preg_match( '#^https://api\.anthropic\.com/v1/claude_code/routines/trig_\w+/fire$#', $url ) ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( '초인종 주소는 https://api.anthropic.com/v1/claude_code/routines/trig_…/fire 모양이에요' ), $back ) );
			exit;
		}
		$bell['url'] = $url;
		if ( '' !== $token ) {
			$bell['token'] = $token;
		}
		update_option( TP_CN_BELL, $bell, false ); // autoload 끔: 탭에서만 쓰는 값이라 모든 페이지에서 불러올 필요 없다
		wp_safe_redirect( add_query_arg( 'tp_cn_info', 'bell', $back ) );
		exit;
	}
);

// "셰프 다시 부르기": 초인종이 실패했거나, 주방이 멈췄거나, 너무 오래 요리 중일 때
add_action(
	'admin_post_tp_cn_recall',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 부를 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_recall_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		// 처음 요리는 zip이 있어야 하고, 수정은 지난번 작업 기록(state)만 있어도 된다
		$can = get_post_meta( $id, '_tp_cn_zip', true ) || ( get_post_meta( $id, '_tp_cn_feedback', true ) && get_post_meta( $id, '_tp_cn_state', true ) );
		if ( TP_CN_TYPE !== get_post_type( $id ) || ! $can ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( '이 주문은 zip이 없어서 다시 요리할 수 없어요. 새로 주문해 주세요' ), $back ) );
			exit;
		}
		// 셰프는 '접수' 주문만 가져가니 상태를 되돌린 뒤 깨운다. 수정 요청이 남아 있으면 '수정 접수'로
		update_post_meta( $id, '_tp_cn_status', get_post_meta( $id, '_tp_cn_feedback', true ) ? 'revise' : 'new' );
		delete_post_meta( $id, '_tp_cn_error' );
		$ok = tp_cn_ring( $id );
		wp_safe_redirect( $ok ? add_query_arg( 'tp_cn_ok', $id, $back ) : add_query_arg( 'tp_cn_err', rawurlencode( get_post_meta( $id, '_tp_cn_bell_err', true ) ), $back ) );
		exit;
	}
);

// "고쳐 주세요": 완성된 초안에 메모로 수정을 요청한다. 셰프가 지난번 작업 기록을 이어받아 같은 초안을 고친다
add_action(
	'admin_post_tp_cn_revise',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 요청할 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_revise_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$fail = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};
		$text = trim( sanitize_textarea_field( wp_unslash( $_POST['feedback'] ?? '' ) ) );
		if ( TP_CN_TYPE !== get_post_type( $id ) || 'done' !== get_post_meta( $id, '_tp_cn_status', true ) ) {
			$fail( '완성된 주문만 고칠 수 있어요' );
		}
		if ( '' === $text ) {
			$fail( '무엇을 고칠지 적어 주세요' );
		}
		if ( ! get_post_meta( $id, '_tp_cn_state', true ) ) {
			// 1.4.0 전에 완성된 주문은 작업 기록이 없어서 이어서 고칠 수 없다
			$fail( '이 주문은 작업 기록이 없어서 고칠 수 없어요. 편집기에서 직접 고치거나 새로 주문해 주세요' );
		}
		update_post_meta( $id, '_tp_cn_feedback', $text );
		update_post_meta( $id, '_tp_cn_status', 'revise' );
		delete_post_meta( $id, '_tp_cn_error' );
		if ( ! tp_cn_ring( $id ) ) {
			$fail( '수정 요청은 받았는데 셰프를 깨우지 못했어요. ' . get_post_meta( $id, '_tp_cn_bell_err', true ) );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_rev', $id, $back ) );
		exit;
	}
);

// "주문 지우기": 주문 + 그 임시글 + 셰프가 그 주문 때 올린 사진을 함께 버린다(10/17 사용자).
// 발행된 글은 절대 안 지우고 주문 기록만 지운다. 요리 중인 주문은 셰프가 일하는 중이라 막는다
add_action(
	'admin_post_tp_cn_delete',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 지울 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_delete_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$say  = function ( $kind, $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_' . $kind, rawurlencode( $msg ), $back ) );
			exit;
		};
		if ( TP_CN_TYPE !== get_post_type( $id ) ) {
			$say( 'err', '없는 주문이에요' );
		}
		if ( 'working' === get_post_meta( $id, '_tp_cn_status', true ) ) {
			$say( 'err', '셰프가 요리 중이라 지금은 못 지워요. 끝난 뒤에 지워 주세요' );
		}
		$draft = get_post( (int) get_post_meta( $id, '_tp_cn_post', true ) );
		$note  = '';
		if ( $draft && 'post' === $draft->post_type && 'publish' !== $draft->post_status ) {
			// 셰프가 올린 사진 = 이 글이 쓰는 사진 중 파일 이름이 "order-<주문 번호>-"로 시작하는 것(cardnews.py upload가 붙이는 이름).
			// 다른 글과 같이 쓰는 사진일 수 있는 나머지는 건드리지 않는다
			preg_match_all( '/wp-image-(\d+)/', $draft->post_content, $m );
			$media = array_unique( array_merge( array_map( 'intval', $m[1] ), array( (int) get_post_thumbnail_id( $draft ) ) ) );
			$gone  = 0;
			foreach ( $media as $mid ) {
				$file = $mid ? get_attached_file( $mid ) : '';
				if ( $file && 0 === strpos( wp_basename( $file ), "order-{$id}-" ) && wp_delete_attachment( $mid, true ) ) {
					++$gone;
				}
			}
			wp_delete_post( $draft->ID, true );
			$note = " 임시글 {$draft->ID}과 사진 {$gone}장도 지웠어요.";
		} elseif ( $draft && 'publish' === $draft->post_status ) {
			$note = " 글 {$draft->ID}은 이미 발행돼서 그대로 뒀어요.";
		}
		wp_delete_post( $id, true ); // zip은 before_delete_post에서 같이 지워진다
		$say( 'info', "주문 {$id}을 지웠어요.{$note}" );
	}
);

// zip은 글이 발행되거나 휴지통에 갈 때 지운다(10/17 사용자: 수정 요청 때 "사진 바꿔"에 원본이 필요해서 완성 때 지우던 것을 바꿈).
// 발행 전까지는 주문당 수 MB가 남는다
function tp_cn_drop_zip_for_post( $post_id ) {
	$orders = get_posts(
		array(
			'post_type'   => TP_CN_TYPE,
			'post_status' => 'private',
			'numberposts' => 5,
			'meta_key'    => '_tp_cn_post',
			'meta_value'  => (int) $post_id,
		)
	);
	foreach ( $orders as $order ) {
		$zip = get_post_meta( $order->ID, '_tp_cn_zip', true );
		if ( $zip && is_file( tp_cn_dir() . '/' . $zip ) ) {
			unlink( tp_cn_dir() . '/' . $zip );
		}
		update_post_meta( $order->ID, '_tp_cn_zip', '' );
	}
}
add_action(
	'transition_post_status',
	function ( $new, $old, $post ) {
		if ( 'post' === $post->post_type && 'publish' === $new && 'publish' !== $old ) {
			tp_cn_drop_zip_for_post( $post->ID );
		}
	},
	10,
	3
);
add_action( 'wp_trash_post', 'tp_cn_drop_zip_for_post' );

// ── 주문 받기 (탭의 폼) ──────────────────────────────────

add_action(
	'admin_post_tp_cn_order',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 주문할 수 있어요' );
		}
		check_admin_referer( 'tp_cn_order' );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$fail = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};

		$file = isset( $_FILES['zip'] ) ? $_FILES['zip'] : null;
		if ( ! $file || UPLOAD_ERR_NO_FILE === $file['error'] ) {
			$fail( 'zip 파일을 골라 주세요' );
		}
		if ( UPLOAD_ERR_OK !== $file['error'] ) {
			$fail( "zip을 올리다 멈췄어요 (오류 {$file['error']}). 파일이 너무 크면 이렇게 될 수 있어요" );
		}
		if ( ! preg_match( '/\.zip$/i', $file['name'] ) || $file['size'] > TP_CN_MAX ) {
			$fail( 'zip 파일만, 200MB까지 받을 수 있어요' );
		}
		$caption = trim( sanitize_textarea_field( wp_unslash( $_POST['caption'] ?? '' ) ) );
		if ( '' === $caption ) {
			$fail( '인스타 캡션을 붙여 넣어 주세요' );
		}
		$videos = tp_cn_parse_videos( wp_unslash( $_POST['videos'] ?? '' ) );
		if ( is_wp_error( $videos ) ) {
			$fail( $videos->get_error_message() );
		}
		$group = tp_cn_check_zip( $file['tmp_name'], $file['name'] );
		if ( is_wp_error( $group ) ) {
			$fail( $group->get_error_message() );
		}

		// wp_handle_upload는 허용 형식 목록에 zip이 없으면 막는다 — 관리자만 쓰는 칸이라 직접 옮기고 위에서 확장자·내용을 본다
		$name = bin2hex( random_bytes( 16 ) ) . '.zip';
		if ( ! move_uploaded_file( $file['tmp_name'], tp_cn_dir() . '/' . $name ) ) {
			$fail( 'zip을 저장하지 못했어요. 잠시 뒤 다시 해 주세요' );
		}

		$id = wp_insert_post(
			array(
				'post_type'   => TP_CN_TYPE,
				'post_status' => 'private',
				'post_title'  => sanitize_text_field( $group ),
			)
		);
		update_post_meta( $id, '_tp_cn_status', 'new' );
		update_post_meta( $id, '_tp_cn_zip', $name );
		update_post_meta( $id, '_tp_cn_caption', $caption );
		update_post_meta( $id, '_tp_cn_videos', $videos );
		update_post_meta( $id, '_tp_cn_memo', trim( sanitize_textarea_field( wp_unslash( $_POST['memo'] ?? '' ) ) ) );

		if ( ! tp_cn_ring( $id ) ) {
			// 주문은 저장됐으니 다시 쓸 필요는 없다. 목록의 "셰프 다시 부르기"로 이어서 할 수 있게 알려 준다
			$fail( '주문은 받았는데 셰프를 깨우지 못했어요. ' . get_post_meta( $id, '_tp_cn_bell_err', true ) . ' — 주문 현황에서 "셰프 다시 부르기"를 눌러 주세요' );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_ok', $id, $back ) );
		exit;
	}
);

/**
 * 주문 하나를 화면·REST에서 같이 쓰는 모양으로.
 */
function tp_cn_order( $post, $with_state = false ) {
	$id      = $post->ID;
	$draft   = (int) get_post_meta( $id, '_tp_cn_post', true );
	$changes = get_post_meta( $id, '_tp_cn_changes', true );
	$out     = array(
		'id'      => $id,
		'group'   => $post->post_title,
		'created' => get_post_time( 'c', true, $post ),
		'status'  => get_post_meta( $id, '_tp_cn_status', true ) ?: 'new',
		'caption' => get_post_meta( $id, '_tp_cn_caption', true ),
		'videos'  => (object) ( get_post_meta( $id, '_tp_cn_videos', true ) ?: array() ),
		'memo'    => get_post_meta( $id, '_tp_cn_memo', true ),
		'zip'     => rest_url( "tp-cardnews/v1/orders/{$id}/zip" ),
		'post_id' => $draft ?: null,
		'title'   => get_post_meta( $id, '_tp_cn_title', true ),
		'changes' => is_array( $changes ) ? $changes : array(),
		'error'   => get_post_meta( $id, '_tp_cn_error', true ),
		// 요리가 끝난(완성·멈춤) 시각. 메뉴 배지와 "방금 완성" 표시가 이걸로 "아직 안 본 결과"를 센다
		'finished' => (int) max( (int) get_post_meta( $id, '_tp_cn_done_at', true ), (int) get_post_meta( $id, '_tp_cn_failed_at', true ) ),
		// 초인종 기록: "셰프 다시 부르기" 버튼을 언제 보여 줄지 정하는 데 쓴다
		'rang_at'  => (int) get_post_meta( $id, '_tp_cn_rang_at', true ),
		'bell_err' => get_post_meta( $id, '_tp_cn_bell_err', true ),
		'started'  => (int) get_post_meta( $id, '_tp_cn_working_at', true ),
		'has_zip'  => (bool) get_post_meta( $id, '_tp_cn_zip', true ),
		// 수정 요청: 지금 들어온 요청, 지난 수정들(요청 + 셰프가 손본 것), 셰프가 이어받을 작업 기록(파일 이름 → 내용)
		'feedback' => get_post_meta( $id, '_tp_cn_feedback', true ),
		'rounds'   => get_post_meta( $id, '_tp_cn_rounds', true ) ?: array(),
	);
	// 작업 기록은 수십 KB라 셰프가 주문을 가져갈 때(상태를 골라 물을 때)만 싣는다 — 탭이 20초마다 묻는 목록엔 빼서 가볍게
	if ( $with_state ) {
		$out['state'] = (object) ( json_decode( (string) get_post_meta( $id, '_tp_cn_state', true ), true ) ?: array() );
	}
	return $out;
}

function tp_cn_orders( $status = null, $limit = 30 ) {
	$args = array(
		'post_type'      => TP_CN_TYPE,
		'post_status'    => 'private',
		'posts_per_page' => $limit,
		'orderby'        => 'date',
		'order'          => 'DESC',
	);
	if ( $status ) {
		$args['meta_key']   = '_tp_cn_status';
		$args['meta_value'] = $status;
		$args['order']      = 'ASC'; // 가져가는 쪽은 먼저 들어온 주문부터
	}
	$with_state = (bool) $status;
	return array_map(
		function ( $p ) use ( $with_state ) {
			return tp_cn_order( $p, $with_state );
		},
		get_posts( $args )
	);
}

// ── REST: 사이트 밖 주방이 주문을 가져가고 결과를 적는 곳 ───────────

add_action(
	'rest_api_init',
	function () {
		$admin = function () {
			return current_user_can( 'manage_options' ); // 애플리케이션 비밀번호로 들어온 관리자만
		};
		$find  = function ( $id ) {
			$post = get_post( (int) $id );
			return ( $post && TP_CN_TYPE === $post->post_type ) ? $post : null;
		};

		register_rest_route(
			'tp-cardnews/v1',
			'/orders',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) {
					$status = $req->get_param( 'status' );
					return tp_cn_orders( isset( TP_CN_STATUS[ $status ] ) ? $status : null, 50 );
				},
			)
		);

		register_rest_route(
			'tp-cardnews/v1',
			'/orders/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) use ( $find ) {
					$post = $find( $req['id'] );
					if ( ! $post ) {
						return new WP_Error( 'tp_cn_none', '없는 주문이에요', array( 'status' => 404 ) );
					}
					$id = $post->ID;
					if ( null !== $req->get_param( 'status' ) ) {
						if ( ! isset( TP_CN_STATUS[ $req['status'] ] ) ) {
							return new WP_Error( 'tp_cn_status', '상태는 new·revise·working·done·failed 중 하나예요', array( 'status' => 400 ) );
						}
						update_post_meta( $id, '_tp_cn_status', $req['status'] );
						update_post_meta( $id, '_tp_cn_' . $req['status'] . '_at', time() );
						// 수정 요청을 끝냈으면 그 요청과 손본 것을 지난 수정 목록에 쌓고 요청 칸을 비운다
						$feedback = get_post_meta( $id, '_tp_cn_feedback', true );
						if ( 'done' === $req['status'] && $feedback ) {
							$rounds   = get_post_meta( $id, '_tp_cn_rounds', true ) ?: array();
							$rounds[] = array(
								'feedback' => $feedback,
								'changes'  => is_array( $req->get_param( 'changes' ) ) ? array_values( array_map( 'sanitize_text_field', $req['changes'] ) ) : array(),
								'at'       => time(),
							);
							update_post_meta( $id, '_tp_cn_rounds', $rounds );
							delete_post_meta( $id, '_tp_cn_feedback' );
							$revised = true;
						}
					}
					// 셰프의 작업 기록: 다음 수정 때 빈 컴퓨터에서 이어받는다. 글 HTML까지 수십 KB라 메타 하나에 JSON으로
					if ( is_array( $req->get_param( 'state' ) ) ) {
						update_post_meta( $id, '_tp_cn_state', wp_slash( wp_json_encode( $req['state'], JSON_UNESCAPED_UNICODE ) ) );
					}
					if ( null !== $req->get_param( 'post_id' ) ) {
						update_post_meta( $id, '_tp_cn_post', (int) $req['post_id'] );
					}
					if ( null !== $req->get_param( 'title' ) ) {
						update_post_meta( $id, '_tp_cn_title', sanitize_text_field( $req['title'] ) );
					}
					// 처음 요리 때 손본 것만 여기에. 수정 때 손본 것은 위에서 그 회차 기록에 들어갔다
					if ( is_array( $req->get_param( 'changes' ) ) && empty( $revised ) ) {
						update_post_meta( $id, '_tp_cn_changes', array_values( array_map( 'sanitize_text_field', $req['changes'] ) ) );
					}
					if ( null !== $req->get_param( 'error' ) ) {
						update_post_meta( $id, '_tp_cn_error', sanitize_text_field( $req['error'] ) );
					}
					return tp_cn_order( get_post( $id ) );
				},
			)
		);

		// zip은 공개 주소로 열어 두지 않고, 관리자 인증을 거쳐 여기서 내려준다
		register_rest_route(
			'tp-cardnews/v1',
			'/orders/(?P<id>\d+)/zip',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) use ( $find ) {
					$post = $find( $req['id'] );
					$path = $post ? tp_cn_dir() . '/' . get_post_meta( $post->ID, '_tp_cn_zip', true ) : '';
					if ( ! $post || ! is_file( $path ) ) {
						return new WP_Error( 'tp_cn_none', 'zip이 없어요', array( 'status' => 404 ) );
					}
					header( 'Content-Type: application/zip' );
					header( 'Content-Length: ' . filesize( $path ) );
					readfile( $path );
					exit;
				},
			)
		);
	}
);

// ── 탭 화면 ──────────────────────────────────────────────

/*
 * 알림 B(10/17 사용자 결정 A+B): wp-admin 어느 화면에서든 메뉴에 "아직 안 본 결과" 수를 배지로 (업데이트 수가 뜨는 것과 같은 모양).
 * "봤다" = 사람마다 도우미 탭을 마지막으로 연 시각(사용자 메타). 탭을 여는 순간 배지가 사라지고,
 * 그 전 시각은 남겨 두었다가 그 뒤에 끝난 주문에 "방금 완성" 표시를 붙인다.
 */
add_action(
	'admin_menu',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$uid  = get_current_user_id();
		$seen = (int) get_user_meta( $uid, '_tp_cn_seen', true );
		$on   = isset( $_GET['page'] ) && TP_CN_SLUG === $_GET['page'];
		$GLOBALS['tp_cn_prev_seen'] = $seen;
		if ( $on ) {
			update_user_meta( $uid, '_tp_cn_seen', time() );
		}
		$unseen = $on ? 0 : count(
			array_filter(
				tp_cn_orders(),
				function ( $o ) use ( $seen ) {
					return $o['finished'] > $seen;
				}
			)
		);
		$title = '카드뉴스 도우미' . ( $unseen ? sprintf( ' <span class="awaiting-mod count-%1$d"><span class="pending-count">%1$d</span></span>', $unseen ) : '' );
		add_menu_page( '트란시스 카드뉴스 도우미', $title, 'manage_options', TP_CN_SLUG, 'tp_cn_page', 'dashicons-pets', 3 );
	}
);

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'toplevel_page_' . TP_CN_SLUG !== $hook ) {
			return;
		}
		// 일정표와 같은 글꼴(둘 다 SIL OFL 1.1 — 10/17 라이선스 원문 확인)
		wp_enqueue_style( 'tp-cn-fonts', 'https://fonts.googleapis.com/css2?family=Jua&family=IBM+Plex+Sans+KR:wght@400;500;700&display=swap', array(), null );
	}
);

function tp_cn_page() {
	$msg = array();
	if ( isset( $_GET['tp_cn_err'] ) ) {
		$msg = array( 'bad', sanitize_text_field( wp_unslash( $_GET['tp_cn_err'] ) ) );
	} elseif ( isset( $_GET['tp_cn_info'] ) ) {
		$info = sanitize_text_field( wp_unslash( $_GET['tp_cn_info'] ) );
		$msg  = array( 'ok', 'bell' === $info ? '초인종 설정을 저장했어요. 다음 주문부터 셰프가 바로 와요.' : $info );
	} elseif ( isset( $_GET['tp_cn_ok'] ) && 'new' === get_post_meta( (int) $_GET['tp_cn_ok'], '_tp_cn_status', true ) ) {
		// 아직 접수 상태일 때만. 요리가 시작·끝난 뒤엔 목록이 상태를 말해 주니 "곧 시작해요"가 남아 있으면 헷갈린다
		$msg = array( 'ok', '주문 받았어요! 셰프 트란시스가 곧 요리를 시작해요.' );
	} elseif ( isset( $_GET['tp_cn_rev'] ) && 'revise' === get_post_meta( (int) $_GET['tp_cn_rev'], '_tp_cn_status', true ) ) {
		$msg = array( 'ok', '수정 요청 받았어요! 셰프 트란시스가 같은 초안을 고쳐 둘게요.' );
	}
	tp_cn_render(
		tp_cn_orders(),
		$msg,
		array(
			'face'   => plugins_url( 'mascot.jpg', __FILE__ ),
			'rest'   => plugins_url( 'mascot-rest.png', __FILE__ ),
			'action' => admin_url( 'admin-post.php' ),
			'nonce'  => wp_nonce_field( 'tp_cn_order', '_wpnonce', true, false ),
			// 알림 A: 탭이 스스로 상태를 확인할 때 쓰는 주소와 로그인 확인 값(쿠키 인증에는 wp_rest nonce가 필요)
			'poll'   => rest_url( 'tp-cardnews/v1/orders' ),
			'rnonce' => wp_create_nonce( 'wp_rest' ),
			'seen'   => isset( $GLOBALS['tp_cn_prev_seen'] ) ? (int) $GLOBALS['tp_cn_prev_seen'] : time(),
			'bell'   => get_option( TP_CN_BELL, array() ),
			'now'    => time(),
		)
	);
}

/**
 * 이 주문에 "셰프 다시 부르기"가 필요한지와 그 이유. 필요 없으면 null.
 * 기다리는 시간: 초인종 뒤 셰프가 주문을 가져가기까지 보통 1~2분, 요리는 10분 안팎(711 실측 전 추정)이라 넉넉히.
 */
function tp_cn_recall_reason( $o, $now ) {
	$waiting = in_array( $o['status'], array( 'new', 'revise' ), true );
	if ( $waiting && $o['bell_err'] ) {
		return $o['bell_err'];
	}
	if ( $waiting && $o['rang_at'] && $now - $o['rang_at'] > 15 * MINUTE_IN_SECONDS ) {
		return '초인종을 눌렀는데 15분이 지나도 셰프가 주문을 가져가지 않았어요.';
	}
	if ( 'working' === $o['status'] && $o['started'] && $now - $o['started'] > 45 * MINUTE_IN_SECONDS ) {
		return '요리가 45분 넘게 끝나지 않아요. 셰프가 중간에 멈췄을 수 있어요.';
	}
	if ( 'failed' === $o['status'] && ( $o['has_zip'] || $o['feedback'] ) ) {
		return ''; // 멈춘 이유는 이미 위에 나온다 — 버튼만
	}
	return null;
}

/**
 * 화면 그리기. 주문 목록·알림·주소를 넘겨받기만 해서, 워드프레스 없이도 가짜 주문으로 그려 볼 수 있다(시안·검증용).
 */
function tp_cn_render( $orders, $msg, $u ) {
	$fmt = function ( $iso ) {
		return $iso ? wp_date( 'n월 j일 H:i', strtotime( $iso ) ) : '';
	};
	?>
<div class="tpcn" id="tpcn" data-poll="<?php echo esc_url( $u['poll'] ); ?>" data-nonce="<?php echo esc_attr( $u['rnonce'] ); ?>">
<style>
/* 셰프 트란시스의 주방(10/17 사용자: "요리사 컨셉, 빵모자, 테마·배경도"). 둥근 패널·파스텔 칩·Jua 제목은 일정표와 같은 말투,
   색은 주방 쪽으로: 크림 바탕, 갈색 글자, 상태 = 주문서 파랑 · 버터(요리 중) · 바질(완성) · 토마토(멈춤) */
body.toplevel_page_tp-cardnews #wpcontent, body.toplevel_page_tp-cardnews #wpfooter { background: #fbf4e6; }
.tpcn { --bg: #fdf8ee; --card: #fffdf8; --ink: #3b2f2a; --muted: #8c7f73; --line: #efe3cf; --line-strong: #dcc9ab;
  --new: #3a86ff; --new-soft: #dde9ff; --revise: #7a5af8; --revise-soft: #ebe5ff; --working: #d08c12; --working-soft: #fbedc9;
  --done: #2f9e6b; --done-soft: #d9f1e3; --failed: #e4572e; --failed-soft: #fde3da; --fresh: #b8572e; --fresh-soft: #fbe6da;
  --tomato: #e4572e;
  --font-display: "Jua", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif;
  --font-body: "IBM Plex Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif;
  max-width: 980px; margin: 18px 20px 40px 0; display: grid; gap: 18px; color: var(--ink); font-family: var(--font-body); font-size: 14px; line-height: 1.55; word-break: keep-all; }
.tpcn * { box-sizing: border-box; }
.tpcn [hidden] { display: none !important; }
/* 맨 위 행주 띠: 토마토색 깅엄 체크 */
.tpcn-towel { height: 12px; border-radius: 999px; opacity: .85;
  background: repeating-linear-gradient(90deg, rgba(228, 87, 46, .55) 0 12px, transparent 12px 24px), repeating-linear-gradient(0deg, rgba(228, 87, 46, .55) 0 6px, #fff6ea 6px 12px); }
.tpcn-head { position: relative; display: flex; align-items: center; gap: 14px; padding-top: 18px; }
.tpcn-face { position: relative; flex: none; border: 0; padding: 0; background: none; border-radius: 50%; cursor: pointer; }
.tpcn-face img { display: block; width: 56px; height: 56px; border-radius: 50%; object-fit: cover; box-shadow: 0 0 0 3px var(--card), 0 4px 12px rgba(59, 47, 42, .18); }
.tpcn-face:focus-visible { outline: 2px solid var(--new); outline-offset: 2px; }
/* 셰프 모자: 사진은 그대로 두고 그림을 머리 위에 얹는다 */
.tpcn-hat { position: absolute; left: 6px; top: -30px; width: 46px; height: auto; transform: rotate(-10deg); pointer-events: none; filter: drop-shadow(0 2px 2px rgba(59, 47, 42, .15)); }
/* 오른쪽 위 반짝이: 눌러 볼 수 있다는 작은 신호(일정표와 같음) */
.tpcn-spark { position: absolute; top: 0; right: -10px; font-size: 16px; line-height: 1; pointer-events: none; }
.tpcn-head h1 { margin: 0; padding: 0; font-family: var(--font-display); font-weight: 400; font-size: 27px; line-height: 1.15; color: var(--ink); }
.tpcn-head p { margin: 2px 0 0; color: var(--muted); font-size: 13px; }
/* 얼굴을 누르면 쓰는 법이 말풍선으로 */
.tpcn-bubble { position: absolute; z-index: 5; top: 86px; left: 0; width: min(380px, 100%); margin: 0; padding: 12px 14px; border-radius: 14px; border: 1px solid var(--line); background: var(--card); font-size: 13px; box-shadow: 0 8px 24px rgba(20, 22, 40, .18); }
.tpcn-bubble::before { content: ""; position: absolute; top: -7px; left: 20px; width: 12px; height: 12px; background: var(--card); border: solid var(--line); border-width: 1px 0 0 1px; transform: rotate(45deg); border-radius: 2px; }
.tpcn-bubble ol { margin: 0; padding-left: 18px; }
.tpcn-bubble li { margin: 2px 0; }
@media (prefers-reduced-motion: no-preference) {
  .tpcn-spark { animation: tpcn-twinkle 2.4s ease-in-out infinite; }
  .tpcn-face.wag { animation: tpcn-wag .5s ease; }
  @keyframes tpcn-twinkle { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: .35; transform: scale(.75); } }
  @keyframes tpcn-wag { 25% { transform: rotate(-10deg); } 75% { transform: rotate(10deg); } }
}
.tpcn-msg { margin: 0; padding: 12px 16px; border-radius: 14px; font-weight: 700; }
.tpcn-msg.ok { background: var(--done-soft); color: #13784f; }
.tpcn-msg.bad { background: var(--failed-soft); color: #b42333; }
.tpcn-panel { background: var(--card); border-radius: 22px; padding: 18px; border: 1px solid var(--line); box-shadow: 0 1px 2px rgba(59, 47, 42, .04), 0 8px 24px rgba(59, 47, 42, .06); min-width: 0; }
.tpcn-panel h2 { margin: 0 0 14px; font-family: var(--font-display); font-weight: 400; font-size: 20px; display: flex; align-items: baseline; gap: 8px; color: var(--ink); }
.tpcn-panel h2 small { font-family: var(--font-body); font-size: 12px; color: var(--muted); font-weight: 500; }
.tpcn-form { display: grid; gap: 14px; }
.tpcn-field label { display: block; margin-bottom: 6px; font-weight: 700; }
.tpcn-field label em { margin-left: 4px; font-style: normal; font-weight: 500; font-size: 12px; color: var(--muted); }
.tpcn-field .tpcn-hint { margin: 6px 0 0; font-size: 12px; color: var(--muted); }
.tpcn-field .tpcn-hint b { color: var(--ink); }
.tpcn-how { margin-top: 6px; font-size: 12.5px; }
.tpcn-how summary { display: inline-block; cursor: pointer; color: var(--fresh); font-weight: 700; }
.tpcn-how ul { margin: 8px 0 0; padding: 10px 14px 10px 28px; border-radius: 12px; background: var(--bg); border: 1px dashed var(--line-strong); }
.tpcn-how li { margin: 3px 0; }
.tpcn-how code { padding: 1px 6px; border-radius: 6px; background: var(--card); border: 1px solid var(--line); font-size: 12px; }
.tpcn textarea { width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font: inherit; color: var(--ink); resize: vertical; }
.tpcn textarea:focus { border-color: var(--new); outline: none; box-shadow: 0 0 0 3px var(--new-soft); }
/* zip 넣는 칸: 점선 상자. 고르면 파일 이름이 상자 안에 뜬다 */
.tpcn-drop { position: relative; display: flex; align-items: center; gap: 12px; padding: 16px; border: 2px dashed var(--line-strong); border-radius: 16px; background: var(--bg); cursor: pointer; }
.tpcn-drop:hover, .tpcn-drop.is-over { border-color: var(--new); background: var(--new-soft); }
.tpcn-drop.has-file { border-style: solid; border-color: var(--done); background: var(--done-soft); }
.tpcn-drop input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
.tpcn-drop .tpcn-ico { flex: none; width: 40px; height: 40px; border-radius: 12px; display: grid; place-items: center; background: var(--card); font-size: 20px; }
.tpcn-drop b { display: block; font-size: 14px; }
.tpcn-drop span { font-size: 12px; color: var(--muted); }
.tpcn-go { justify-self: start; padding: 11px 22px; border: 0; border-radius: 999px; background: var(--tomato); color: #fff; font-family: var(--font-display); font-size: 17px; cursor: pointer; box-shadow: 0 4px 0 #b8401d; }
.tpcn-go:hover { background: #ec6a43; }
.tpcn-go:active { transform: translateY(2px); box-shadow: 0 2px 0 #b8401d; }
.tpcn-go:disabled { opacity: .5; cursor: wait; }
.tpcn-list { margin: 0; padding: 0; list-style: none; display: grid; gap: 10px; }
.tpcn-item { display: grid; grid-template-columns: 44px 1fr auto; gap: 4px 12px; align-items: start; padding: 12px; border: 1px solid var(--line); border-radius: 16px; }
.tpcn-no { min-width: 44px; height: 36px; padding: 0 6px; border-radius: 12px; display: grid; place-items: center; font-family: var(--font-display); font-size: 15px; color: #fff; background: var(--s); }
.tpcn-item h3 { margin: 0; font-size: 15px; font-weight: 700; color: var(--ink); }
.tpcn-item .tpcn-when { margin: 0; font-size: 12px; color: var(--muted); }
.tpcn-chip { display: inline-flex; align-items: center; gap: 5px; padding: 3px 10px; border-radius: 999px; font-size: 12.5px; font-weight: 700; white-space: nowrap; background: var(--s-soft); color: var(--s); }
.tpcn-chip::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
.tpcn-item.is-working .tpcn-chip::before { animation: tpcn-blink 1.2s ease-in-out infinite; }
/* 마지막으로 탭을 본 뒤에 끝난 주문: 테두리를 상태 색으로, 이름 옆에 작은 표 */
.tpcn-item.is-fresh { border-color: var(--s); box-shadow: 0 0 0 3px var(--s-soft); }
.tpcn-fresh { display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 999px; background: var(--s); color: #fff; font-size: 11px; font-weight: 700; vertical-align: 2px; }
.tpcn-live-btn { margin-left: 8px; padding: 3px 12px; border: 0; border-radius: 999px; background: var(--done); color: #fff; font: inherit; font-size: 12.5px; cursor: pointer; }
@keyframes tpcn-blink { 50% { opacity: .2; } }
.s-new { --s: var(--new); --s-soft: var(--new-soft); }
.s-revise { --s: var(--revise); --s-soft: var(--revise-soft); }
.s-working { --s: var(--working); --s-soft: var(--working-soft); }
/* 고쳐 주세요: 완성된 주문 아래 메모 칸 + 지난 수정 기록 */
.tpcn-revise { margin-top: 10px; display: grid; gap: 6px; }
.tpcn-revise textarea { font-size: 13px; }
.tpcn-revise button { justify-self: start; padding: 6px 16px; border: 0; border-radius: 999px; background: var(--revise); color: #fff; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; }
.tpcn-rounds { margin: 8px 0 0; padding: 0; list-style: none; display: grid; gap: 6px; }
.tpcn-rounds > li { padding: 8px 10px; border-radius: 10px; background: var(--bg); border: 1px dashed var(--line-strong); }
.tpcn-rounds b { color: var(--revise); }
.tpcn-rounds ul { margin: 4px 0 0; padding-left: 18px; color: var(--muted); }
.s-done { --s: var(--done); --s-soft: var(--done-soft); }
.s-failed { --s: var(--failed); --s-soft: var(--failed-soft); }
.tpcn-body { grid-column: 2 / -1; font-size: 13px; }
.tpcn-body p { margin: 4px 0 0; }
.tpcn-body .tpcn-title { font-weight: 700; }
.tpcn-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.tpcn-links a { display: inline-block; padding: 5px 12px; border-radius: 999px; border: 1.5px solid var(--line); color: var(--ink); text-decoration: none; font-weight: 700; font-size: 12.5px; }
.tpcn-links a.main { background: var(--ink); border-color: var(--ink); color: #fff; }
.tpcn-links a:hover { border-color: var(--muted); }
.tpcn-body details { margin-top: 8px; }
.tpcn-body summary { cursor: pointer; color: var(--fresh); font-weight: 700; }
.tpcn-body details ul { margin: 6px 0 0; padding-left: 18px; }
.tpcn-recall { margin-top: 8px; }
.tpcn-recall p { margin: 0 0 6px; color: var(--muted); }
.tpcn-recall button { padding: 5px 14px; border: 0; border-radius: 999px; background: var(--tomato); color: #fff; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; }
.tpcn-bell summary { cursor: pointer; font-family: var(--font-display); font-size: 18px; }
.tpcn-bell summary small { margin-left: 6px; font-family: var(--font-body); font-size: 12px; color: var(--muted); }
.tpcn-bell form { display: grid; gap: 12px; margin-top: 12px; }
.tpcn-bell input[type=url], .tpcn-bell input[type=password] { width: 100%; padding: 9px 12px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font: inherit; }
/* 주문 지우기: 눈에 덜 띄게 오른쪽 아래 작은 글씨 */
.tpcn-del { margin-top: 8px; text-align: right; }
.tpcn-del button { padding: 0; border: 0; background: none; color: var(--muted); font: inherit; font-size: 12px; cursor: pointer; }
.tpcn-del button:hover { color: var(--failed); text-decoration: underline; }
.tpcn-empty { display: grid; justify-items: center; gap: 6px; padding: 18px 0 8px; color: var(--muted); text-align: center; }
.tpcn-empty img { width: 180px; height: auto; }
@media (max-width: 782px) {
  .tpcn { margin-right: 10px; }
  .tpcn-item { grid-template-columns: 44px 1fr; }
  .tpcn-item .tpcn-chip { grid-column: 2; justify-self: start; }
}
</style>

<div class="tpcn-towel" aria-hidden="true"></div>
<header class="tpcn-head">
	<button type="button" class="tpcn-face" id="tpcn-face" aria-label="쓰는 법 보기" aria-controls="tpcn-bubble">
		<img src="<?php echo esc_url( $u['face'] ); ?>" width="56" height="56" alt="셰프 모자를 쓴 트란시스 마스코트, 허스키 인형">
		<svg class="tpcn-hat" viewBox="0 0 64 50" aria-hidden="true"><path d="M15 35C4 35 2 20 13 18 12 6 27 2 32 10c5-8 21-5 19 8 11 2 9 17-2 17Z" fill="#fff" stroke="#dcc9ab" stroke-width="2.2" stroke-linejoin="round"/><rect x="15" y="32" width="34" height="13" rx="3.5" fill="#fff" stroke="#dcc9ab" stroke-width="2.2"/><path d="M24 34v9M32 34v9M40 34v9" stroke="#efe3cf" stroke-width="2.2" stroke-linecap="round"/></svg>
		<span class="tpcn-spark" aria-hidden="true">✨</span>
	</button>
	<div>
		<h1>트란시스 카드뉴스 도우미</h1>
		<p>피그마 zip을 주문서로 넣어 주면, 셰프 트란시스가 사이트 초안으로 요리해 둘게요</p>
	</div>
	<div class="tpcn-bubble" id="tpcn-bubble" role="status" hidden>
		<ol>
			<li>피그마에서 카드 묶음을 선택하고 플러그인 <b>트란시스 카드뉴스 읽기</b> → zip 내려받기</li>
			<li>여기에 zip · 인스타 캡션 · (있으면) 영상 주소 넣고 <b>주문 넣기</b></li>
			<li><b>완성</b>이 뜨면 미리보기로 맛보고, 셰프가 손본 것 확인한 뒤 발행!</li>
		</ol>
	</div>
</header>

	<?php if ( $msg ) : ?>
<p class="tpcn-msg <?php echo esc_attr( $msg[0] ); ?>" id="tpcn-msg"><?php echo esc_html( $msg[1] ); ?></p>
	<?php endif; ?>
<?php // 알림 A: 요리가 끝나면 여기에 뜬다 (주문서를 쓰는 중이면 새로고침 대신 이 줄로 알린다) ?>
<p class="tpcn-msg ok" id="tpcn-live" role="status" hidden></p>

<section class="tpcn-panel">
	<h2>새 주문서 <small>카드뉴스 하나 = 주문 하나</small></h2>
	<form class="tpcn-form" id="tpcn-form" method="post" action="<?php echo esc_url( $u['action'] ); ?>" enctype="multipart/form-data">
		<input type="hidden" name="action" value="tp_cn_order">
		<?php echo $u['nonce']; // phpcs:ignore WordPress.Security.EscapeOutput -- wp_nonce_field 결과 ?>
		<div class="tpcn-field">
			<label for="tpcn-zip">피그마 zip <em>필수</em></label>
			<div class="tpcn-drop" id="tpcn-drop">
				<span class="tpcn-ico" aria-hidden="true">📦</span>
				<div><b id="tpcn-zipname">zip을 여기에 끌어다 놓거나 눌러서 고르기</b><span>'트란시스 카드뉴스 읽기'에서 받은 파일 그대로</span></div>
				<input type="file" id="tpcn-zip" name="zip" accept=".zip,application/zip" required title=""><?php // title을 비워야 브라우저 기본 말풍선("No file chosen")이 안 뜬다 ?>
			</div>
		</div>
		<div class="tpcn-field">
			<label for="tpcn-caption">인스타 캡션 <em>필수</em></label>
			<textarea id="tpcn-caption" name="caption" rows="7" required placeholder="인스타 게시물 본문을 그대로 붙여 넣어 주세요 (해시태그 줄은 알아서 빼요)"></textarea>
		</div>
		<div class="tpcn-field">
			<label for="tpcn-videos">영상 카드 <em>있을 때만</em></label>
			<textarea id="tpcn-videos" name="videos" rows="3" placeholder="4 = https://www.instagram.com/reel/…&#10;7 = https://youtu.be/…"></textarea>
			<p class="tpcn-hint">한 줄에 하나씩 <b>카드 번호 = 원본 영상 주소</b> · 영상 카드가 없으면 비워 두세요</p>
			<?php // 10/17 사용자: 쓰는 법을 도우미 화면에서도 알 수 있게 — 평소엔 접어 두고 필요할 때 펼친다 ?>
			<details class="tpcn-how">
				<summary>자세히 보기</summary>
				<ul>
					<li><b>카드 번호</b> = 피그마 프레임 이름 끝 숫자예요. 예: <code>트렌드포털 802-4</code> → <b>4</b> (표지가 1번이라, 카드뉴스를 넘겨 보는 순서와 같아요)</li>
					<li><b>주소</b> = 원래 영상이 올라간 곳의 주소. 인스타 릴스·게시물, 유튜브(일반·youtu.be·쇼츠), X를 받아요</li>
					<li><code>4 = 주소</code> · <code>4 주소</code> · <code>4: 주소</code> · <code>4번 주소</code> 모두 괜찮아요</li>
					<li>공유할 때 붙는 <code>?igsh=…</code> 같은 꼬리는 그대로 붙여 넣어도 알아서 떼요</li>
					<li>우리가 직접 가진 영상 파일(mp4)은 아직 이 칸으로 못 받아요 — 메모에 적어 주세요</li>
				</ul>
			</details>
		</div>
		<div class="tpcn-field">
			<label for="tpcn-memo">메모 <em>선택</em></label>
			<textarea id="tpcn-memo" name="memo" rows="2" placeholder="예: 제목에 '팝업' 넣어 주세요"></textarea>
		</div>
		<button type="submit" class="tpcn-go" id="tpcn-go">주문 넣기</button>
	</form>
</section>

<section class="tpcn-panel">
	<h2>주문 현황 <small>최근 30개</small></h2>
	<?php if ( ! $orders ) : ?>
	<div class="tpcn-empty">
		<img src="<?php echo esc_url( $u['rest'] ); ?>" width="180" alt="쉬고 있는 트란시스">
		<p>아직 주문이 없어요. 셰프 트란시스는 쉬는 중!</p>
	</div>
	<?php else : ?>
	<ol class="tpcn-list">
		<?php
		foreach ( $orders as $o ) :
			$s = isset( TP_CN_STATUS[ $o['status'] ] ) ? $o['status'] : 'new';
			?>
		<li class="tpcn-item s-<?php echo esc_attr( $s ); ?> is-<?php echo esc_attr( $s ); ?><?php echo $o['finished'] > $u['seen'] ? ' is-fresh' : ''; ?>" data-id="<?php echo (int) $o['id']; ?>" data-status="<?php echo esc_attr( $s ); ?>">
			<span class="tpcn-no" title="주문 번호"><?php echo (int) $o['id']; ?></span>
			<div>
				<h3><?php echo esc_html( $o['group'] ); ?><?php if ( $o['finished'] > $u['seen'] ) : ?> <span class="tpcn-fresh">방금 나왔어요</span><?php endif; ?></h3>
				<p class="tpcn-when"><?php echo esc_html( $fmt( $o['created'] ) ); ?> 주문</p>
			</div>
			<span class="tpcn-chip"><?php echo esc_html( TP_CN_STATUS[ $s ] ); ?></span>
			<div class="tpcn-body">
			<?php if ( 'new' === $s ) : ?>
				<?php if ( null === tp_cn_recall_reason( $o, $u['now'] ) ) : // 초인종이 실패했으면 "곧 가져가요"는 틀린 말이라 아래 이유만 ?>
				<p>셰프 트란시스가 곧 주문서를 가져가요.</p>
				<?php endif; ?>
			<?php elseif ( 'revise' === $s ) : ?>
				<p>✏️ <?php echo esc_html( $o['feedback'] ); ?></p>
				<?php if ( null === tp_cn_recall_reason( $o, $u['now'] ) ) : ?>
				<p>셰프 트란시스가 곧 와서 같은 초안을 고쳐요.</p>
				<?php endif; ?>
			<?php elseif ( 'working' === $s ) : ?>
				<p><?php echo $o['feedback'] ? '✏️ ' . esc_html( $o['feedback'] ) . ' — 고치는 중이에요.' : '사진을 고르고 글을 굽는 중이에요.'; ?></p>
			<?php elseif ( 'failed' === $s ) : ?>
				<p><?php echo esc_html( $o['error'] ?: '이유를 남기지 못하고 주방이 멈췄어요.' ); ?></p>
				<?php if ( $o['post_id'] ) : // 수정 중에 멈춰도 지난 초안은 그대로 있다 ?>
				<div class="tpcn-links">
					<a href="<?php echo esc_url( home_url( '/?p=' . (int) $o['post_id'] . '&preview=true' ) ); ?>" target="_blank" rel="noopener">지난 초안 미리보기</a>
					<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $o['post_id'] . '&action=edit' ) ); ?>">편집기에서 열기</a>
				</div>
				<?php endif; ?>
			<?php else : ?>
				<?php if ( $o['title'] ) : ?>
				<p class="tpcn-title"><?php echo esc_html( $o['title'] ); ?></p>
				<?php endif; ?>
				<?php if ( $o['post_id'] ) : ?>
				<div class="tpcn-links">
					<a class="main" href="<?php echo esc_url( home_url( '/?p=' . (int) $o['post_id'] . '&preview=true' ) ); ?>" target="_blank" rel="noopener">미리보기</a>
					<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $o['post_id'] . '&action=edit' ) ); ?>">편집기에서 열기 · 발행</a>
				</div>
				<?php endif; ?>
				<?php if ( $o['changes'] ) : ?>
				<details>
					<summary>셰프가 손본 것 <?php echo count( $o['changes'] ); ?>건</summary>
					<ul>
						<?php foreach ( $o['changes'] as $c ) : ?>
						<li><?php echo esc_html( $c ); ?></li>
						<?php endforeach; ?>
					</ul>
				</details>
				<?php endif; ?>
				<?php if ( $o['rounds'] ) : ?>
				<ol class="tpcn-rounds">
					<?php foreach ( $o['rounds'] as $i => $r ) : ?>
					<li><b><?php echo (int) $i + 1; ?>차 수정</b> · <?php echo esc_html( $r['feedback'] ); ?>
						<?php if ( ! empty( $r['changes'] ) ) : ?>
						<ul>
							<?php foreach ( $r['changes'] as $c ) : ?>
							<li><?php echo esc_html( $c ); ?></li>
							<?php endforeach; ?>
						</ul>
						<?php endif; ?>
					</li>
					<?php endforeach; ?>
				</ol>
				<?php endif; ?>
				<?php if ( $o['post_id'] ) : ?>
				<?php // 10/17 사용자: Claude Code 없이 관리자 창에서 메모로 고치기. 셰프가 같은 초안을 고치고 위 기록에 쌓인다 ?>
				<form class="tpcn-revise" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
					<input type="hidden" name="action" value="tp_cn_revise">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_revise_' . (int) $o['id'] ); ?>
					<textarea name="feedback" rows="2" required placeholder="고쳐 주세요 — 예: 제목을 더 짧게 / 3번 설명 두 문단으로 / 카테고리는 브랜드로"></textarea>
					<button type="submit">✏️ 다시 요리</button>
				</form>
				<?php endif; ?>
			<?php endif; ?>
			<?php
			$why = tp_cn_recall_reason( $o, $u['now'] );
			if ( null !== $why ) :
				?>
				<form class="tpcn-recall" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
					<?php if ( '' !== $why ) : ?>
					<p><?php echo esc_html( $why ); ?></p>
					<?php endif; ?>
					<input type="hidden" name="action" value="tp_cn_recall">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_recall_' . (int) $o['id'] ); ?>
					<button type="submit">🔔 셰프 다시 부르기</button>
				</form>
			<?php endif; ?>
			<?php if ( 'working' !== $s ) : // 요리 중엔 못 지운다(셰프가 일하는 중) ?>
				<form class="tpcn-del" method="post" action="<?php echo esc_url( $u['action'] ); ?>" onsubmit="return confirm('주문 <?php echo (int) $o['id']; ?>을 지울까요?\n아직 발행 안 한 임시글과 셰프가 올린 사진도 같이 지워져요. 되돌릴 수 없어요.');">
					<input type="hidden" name="action" value="tp_cn_delete">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_delete_' . (int) $o['id'] ); ?>
					<button type="submit">🗑 주문 지우기</button>
				</form>
			<?php endif; ?>
			</div>
		</li>
		<?php endforeach; ?>
	</ol>
	<?php endif; ?>
</section>

<?php // 초인종 설정: 처음 한 번과 열쇠를 바꿀 때만 쓰니 접어 둔다. 열쇠는 저장 뒤 다시 보여 주지 않는다 ?>
<details class="tpcn-panel tpcn-bell"<?php echo empty( $u['bell']['token'] ) ? ' open' : ''; ?>>
	<summary>🔔 셰프 초인종 설정 <small><?php echo empty( $u['bell']['token'] ) ? '아직 설정 안 됨 — 주문해도 셰프가 오지 않아요' : '연결됨'; ?></small></summary>
	<form method="post" action="<?php echo esc_url( $u['action'] ); ?>">
		<input type="hidden" name="action" value="tp_cn_bell">
		<?php wp_nonce_field( 'tp_cn_bell' ); ?>
		<p class="tpcn-hint">claude.ai/code/routines → 셰프 routine → Edit → API 트리거에서 받은 주소와 열쇠를 넣어 주세요.</p>
		<div class="tpcn-field">
			<label for="tpcn-bell-url">주소</label>
			<input type="url" id="tpcn-bell-url" name="bell_url" required value="<?php echo esc_attr( $u['bell']['url'] ?? '' ); ?>" placeholder="https://api.anthropic.com/v1/claude_code/routines/trig_…/fire">
		</div>
		<div class="tpcn-field">
			<label for="tpcn-bell-token">열쇠 <em><?php echo empty( $u['bell']['token'] ) ? '필수' : '바꿀 때만 — 비워 두면 그대로'; ?></em></label>
			<input type="password" id="tpcn-bell-token" name="bell_token" autocomplete="off" <?php echo empty( $u['bell']['token'] ) ? 'required' : ''; ?> placeholder="sk-ant-…">
		</div>
		<button type="submit" class="tpcn-go">저장</button>
	</form>
</details>

<script>
(() => {
	const $ = id => document.getElementById(id);
	// 얼굴을 누르면 꼬리 흔들기 + 쓰는 법 말풍선 (8초 뒤 저절로 닫힘)
	let t;
	$('tpcn-face').addEventListener('click', () => {
		const open = $('tpcn-bubble').hidden;
		$('tpcn-bubble').hidden = !open;
		$('tpcn-face').classList.remove('wag');
		void $('tpcn-face').offsetWidth;
		$('tpcn-face').classList.add('wag');
		clearTimeout(t);
		if (open) t = setTimeout(() => { $('tpcn-bubble').hidden = true; }, 8000);
	});
	// zip 칸: 고른 파일 이름을 보여 주고, 끌어다 놓을 때 상자 색을 바꾼다
	const drop = $('tpcn-drop'), zip = $('tpcn-zip');
	zip.addEventListener('change', () => {
		const f = zip.files[0];
		drop.classList.toggle('has-file', !!f);
		$('tpcn-zipname').textContent = f ? `${f.name} · ${(f.size / 1048576).toFixed(1)}MB` : 'zip을 여기에 끌어다 놓거나 눌러서 고르기';
	});
	['dragenter', 'dragover'].forEach(e => zip.addEventListener(e, () => drop.classList.add('is-over')));
	['dragleave', 'drop'].forEach(e => zip.addEventListener(e, () => drop.classList.remove('is-over')));
	// 큰 zip은 올리는 데 시간이 걸려서, 두 번 누르지 않게 버튼을 잠근다
	$('tpcn-form').addEventListener('submit', () => { $('tpcn-go').disabled = true; $('tpcn-go').textContent = '올리는 중…'; });

	// ── 알림 A(10/17 사용자 결정 A+B): 접수·요리 중인 주문이 있으면 20초마다 상태를 확인한다 ──
	// 바뀐 게 있으면: 주문서를 쓰는 중이 아니면 새로고침해서 목록을 다시 그리고, 쓰는 중이면 알림 줄만 띄운다(쓰던 내용을 날리지 않게)
	const base = document.title;
	const items = [...document.querySelectorAll('.tpcn-item')];
	const known = Object.fromEntries(items.map(li => [li.dataset.id, li.dataset.status]));
	const waiting = () => Object.values(known).some(s => s === 'new' || s === 'revise' || s === 'working');
	const typing = () => zip.files.length || ['tpcn-caption', 'tpcn-videos', 'tpcn-memo'].some(id => $(id).value.trim());
	const FLASH = 'tpcn-flash', LAST = 'tpcn-reloaded';
	const done = { done: '✅ 완성', failed: '⚠️ 주방 멈춤' };
	const clean = location.pathname + '?page=<?php echo esc_js( TP_CN_SLUG ); ?>';
	// 주문 직후 붙은 ?tp_cn_ok= 꼬리를 주소창에서 지운다 — 그대로 새로고침하면 "곧 시작해요" 알림이 또 뜨던 문제(10/17)
	if (/[?&]tp_cn_(ok|err|info|rev)=/.test(location.search)) history.replaceState(null, '', clean);

	// 새로고침 뒤: 무엇이 끝났는지 위에 띄우고, 다른 탭을 보고 있었다면 탭 제목으로도 알린다
	try {
		const f = sessionStorage.getItem(FLASH);
		if (f) {
			sessionStorage.removeItem(FLASH);
			$('tpcn-live').textContent = f;
			$('tpcn-live').hidden = false;
			if (document.hidden) document.title = f.split(' · ')[0] + ' · ' + base;
		}
	} catch (e) {}
	document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(() => { document.title = base; }, 2500); });

	async function check() {
		let list;
		try {
			const r = await fetch(document.getElementById('tpcn').dataset.poll, { headers: { 'X-WP-Nonce': document.getElementById('tpcn').dataset.nonce }, credentials: 'same-origin' });
			if (!r.ok) return;
			list = await r.json();
		} catch (e) { return; }
		const changed = list.filter(o => known[o.id] !== undefined && known[o.id] !== o.status);
		if (!changed.length) return;
		changed.forEach(o => { known[o.id] = o.status; });
		const ends = changed.filter(o => done[o.status]);
		const text = ends.length
			? ends.map(o => `${done[o.status]} · 주문 ${o.id} ${o.group}`).join('  /  ') + (ends.some(o => o.status === 'done') ? ' — 미리보기로 맛보세요!' : '')
			: `🍳 주문 ${changed[0].id} 요리를 시작했어요`;
		if (ends.length && document.hidden) document.title = done[ends[0].status] + ' · ' + base;
		// 30초 안에 또 새로고침하지 않는다: 혹시 화면과 서버 상태가 계속 어긋나도 새로고침이 끝없이 돌지 않게
		let recent = false;
		try { recent = Date.now() - Number(sessionStorage.getItem(LAST) || 0) < 30000; } catch (e) {}
		if (!typing() && !recent) {
			try { sessionStorage.setItem(FLASH, text); sessionStorage.setItem(LAST, String(Date.now())); } catch (e) {}
			location.replace(clean);
			return;
		}
		$('tpcn-live').innerHTML = '';
		$('tpcn-live').append(text, Object.assign(document.createElement('button'), { type: 'button', className: 'tpcn-live-btn', textContent: '목록 새로 보기', onclick: () => location.reload() }));
		$('tpcn-live').hidden = false;
	}
	(function loop() {
		if (!waiting()) return; // 기다릴 주문이 없으면 확인하지 않는다
		setTimeout(async () => { await check(); loop(); }, 20000);
	})();
})();
</script>
</div>
	<?php
}
