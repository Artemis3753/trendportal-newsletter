<?php
/**
 * Plugin Name: TP Cardnews Helper
 * Description: 관리자 전용 탭 "트란시스 카드뉴스 도우미". 피그마 플러그인(트란시스 카드뉴스 비서)이 만든 zip과 인스타 캡션·영상 주소를 주문으로 받고, 처리 결과(초안·미리보기·고친 것 목록)를 보여 준다. 처리는 사이트 밖(tools/cardnews/cardnews.py)이 REST로 주문을 가져가서 한다.
 * Version: 1.30.6
 * Author: Trendportal
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * 10/17 사용자 결정(A, 탭 먼저): 주문 창구는 사이트 관리자 탭, 요리는 사이트 밖.
 * 워드프레스(PHP) 안에서는 큰 사진 처리에 시간·메모리 제한이 있고, alt·제목·오타 같은 판단을 할 Claude도 없어서다.
 * 그래서 이 플러그인은 주문을 받아 두고 상태만 보여 준다. 가져가는 쪽은 REST(아래 tp-cardnews/v1)로 온다.
 *
 * 저장: 주문 = 비공개 글 유형(tp_cn_order) 하나 + 메타. 따로 DB 표를 만들지 않아 지우기·백업이 글과 같다.
 * zip = uploads/tp-cardnews/ 아래 무작위 이름. 미디어 라이브러리에 섞이지 않게 하고, 주소를 추측할 수 없게 한다.
 */

const TP_CN_TYPE = 'tp_cn_order';
const TP_CN_DIR  = 'tp-cardnews';
const TP_CN_SLUG = 'tp-cardnews';
const TP_CN_MAX  = 200 * 1024 * 1024; // zip 상한. 764(카드 17장)가 16MB였다
const TP_CN_PAGE = 30;                // 주문 현황을 한 번에 펼치는 개수

// 상태 이름은 영어로 저장하고, 화면에는 한국어로 (REST로 오가는 값이 글자 깨짐 걱정 없게)
const TP_CN_STATUS = array(
	'new'     => '주문 접수',
	'revise'  => '수정 접수', // 완성된 초안에 "고쳐 주세요"가 들어온 주문 (10/17 사용자: 관리자 창에서 메모로 고치기)
	'working' => '요리 중',
	'done'    => '완성',
	'failed'  => '주방 멈춤',
	// 셰프가 추측하면 틀릴 것 같아 멈추고 묻는 상태(10/17 사용자: 웹폼 결과도 대화처럼). 사람이 답하면 answered → 셰프가 이어서
	'question' => '질문 있어요',
	'answered' => '답 접수',
);

add_action(
	'init',
	function () {
		register_post_type(
			TP_CN_TYPE,
			array(
				'label'    => '카드뉴스 주문',
				'public'   => false,
				'show_ui'  => false, // 목록은 도우미 탭이 직접 그린다
				'supports' => array( 'title' ),
			)
		);
	}
);

// ── 파일 ────────────────────────────────────────────────

function tp_cn_dir() {
	$dir = wp_upload_dir()['basedir'] . '/' . TP_CN_DIR;
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
		// 폴더 목록이 열리지 않게 빈 index.php
		file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" );
	}
	return $dir;
}

// 주문에 딸린 파일(zip + 영상 카드 파일 + 인터뷰 대상 사진)을 지운다. 주문을 지울 때, 그리고 글이 발행·휴지통으로 갈 때
function tp_cn_unlink_files( $order_id ) {
	$names = array( get_post_meta( $order_id, '_tp_cn_zip', true ) );
	foreach ( (array) get_post_meta( $order_id, '_tp_cn_files', true ) as $f ) {
		$names[] = is_array( $f ) ? $f['file'] : '';
	}
	// 인터뷰 대상은 이름·주소는 남기고(목록·수정 때 필요) 사진 파일만 지운다
	$people = get_post_meta( $order_id, '_tp_cn_people', true );
	if ( is_array( $people ) ) {
		foreach ( $people as $i => $p ) {
			$names[]              = $p['file'] ?? '';
			$people[ $i ]['file'] = '';
		}
		update_post_meta( $order_id, '_tp_cn_people', $people );
	}
	foreach ( array_filter( $names ) as $name ) {
		if ( is_file( tp_cn_dir() . '/' . $name ) ) {
			unlink( tp_cn_dir() . '/' . $name );
		}
	}
	update_post_meta( $order_id, '_tp_cn_zip', '' );
	update_post_meta( $order_id, '_tp_cn_files', array() );
}

add_action(
	'before_delete_post',
	function ( $post_id ) {
		if ( get_post_type( $post_id ) === TP_CN_TYPE ) {
			tp_cn_unlink_files( $post_id );
		}
	}
);

/*
 * 영상 카드 칸(1.6.0, 10/17 사용자 A): 한 줄 = 카드 번호 + 파일(선택) + 원본 주소(선택).
 * 셰프는 "주소가 있느냐"로 할 일을 정한다 — 주소 있음 = 남의 영상(정지 화면 + ▶ 링크, 영상은 사이트에 안 올림),
 * 주소 없음 + 영상 파일 = 우리가 찍은 영상(소리 빼고 사이트에서 바로 재생). 사진 파일은 정지 화면이나 카드 사진으로 쓴다.
 */
const TP_CN_FILE_TYPES = array(
	'mp4'  => 'video',
	'mov'  => 'video',
	'm4v'  => 'video',
	'webm' => 'video',
	'jpg'  => 'image',
	'jpeg' => 'image',
	'png'  => 'image',
	'webp' => 'image',
);

// 확장자만 바꾼 엉뚱한 파일을 셰프(ffmpeg)에게 넘기지 않게, 파일 머리 몇 바이트로 종류를 한 번 더 본다
function tp_cn_sniff( $path ) {
	$head = (string) file_get_contents( $path, false, null, 0, 16 );
	if ( 'ftyp' === substr( $head, 4, 4 ) || "\x1a\x45\xdf\xa3" === substr( $head, 0, 4 ) ) {
		return 'video'; // mp4·mov·m4v는 4번째 바이트부터 ftyp, webm은 EBML 머리
	}
	if ( "\xff\xd8\xff" === substr( $head, 0, 3 ) || "\x89PNG" === substr( $head, 0, 4 ) || ( 'RIFF' === substr( $head, 0, 4 ) && 'WEBP' === substr( $head, 8, 4 ) ) ) {
		return 'image';
	}
	return '';
}

/**
 * 영상 카드 줄들 → array( 'videos' => [ 번호 => 주소 ], 'files' => [ 번호 => 올린 파일 정보 ] ) 또는 WP_Error.
 * 파일은 아직 옮기지 않는다(다른 칸 검사가 다 끝난 뒤에 옮긴다).
 */
function tp_cn_parse_video_rows( $cards, $urls, $files ) {
	$out = array(
		'videos' => array(),
		'files'  => array(),
	);
	foreach ( (array) $cards as $i => $card ) {
		$raw  = trim( (string) ( $urls[ $i ] ?? '' ) );
		$url  = esc_url_raw( $raw, array( 'http', 'https' ) );
		$file = ( isset( $files['error'][ $i ] ) && UPLOAD_ERR_NO_FILE !== $files['error'][ $i ] )
			? array(
				'name'     => $files['name'][ $i ],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			)
			: null;
		$card = trim( (string) $card );
		if ( '' === $raw && ! $file ) {
			continue; // 빈 줄 (카드 번호만 적은 줄도 넣을 게 없으니 넘긴다)
		}
		if ( ! preg_match( '/^\d{1,2}$/', $card ) || (int) $card < 1 ) {
			return new WP_Error( 'tp_cn_video', '영상 카드 줄에 카드 번호를 적어 주세요 (표지가 1번)' );
		}
		$no = (string) (int) $card;
		// 1.27.0(10/25): 표지(1번)가 영상인 새 포맷 — 글자가 영상에 박혀 있어서 영상 파일만 받는다. 원본 주소·사진은 쓸 데가 없다
		if ( '1' === $no && ( '' !== $raw || ! $file ) ) {
			return new WP_Error( 'tp_cn_video', '1번(표지)은 영상 파일만 넣어 주세요 — 글자가 영상에 들어 있는 표지 영상이에요. 주소는 필요 없어요' );
		}
		if ( isset( $out['videos'][ $no ] ) || isset( $out['files'][ $no ] ) ) {
			return new WP_Error( 'tp_cn_video', "{$no}번 카드가 영상 카드 칸에 두 번 있어요" );
		}
		if ( '' === $url && '' !== $raw ) {
			return new WP_Error( 'tp_cn_video', "{$no}번 주소를 못 읽었어요 — https://로 시작하는 주소를 붙여 넣어 주세요" );
		}
		if ( '' !== $url ) {
			$out['videos'][ $no ] = $url;
		}
		if ( $file ) {
			if ( UPLOAD_ERR_OK !== $file['error'] ) {
				return new WP_Error( 'tp_cn_video', "{$no}번 파일을 올리다 멈췄어요 (오류 {$file['error']}). 파일이 너무 크면 이렇게 될 수 있어요" );
			}
			$ext  = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
			$kind = TP_CN_FILE_TYPES[ $ext ] ?? '';
			if ( ! $kind || tp_cn_sniff( $file['tmp_name'] ) !== $kind ) {
				return new WP_Error( 'tp_cn_video', "{$no}번 파일은 영상(mp4·mov·m4v·webm)이나 사진(jpg·png·webp)만 받아요" );
			}
			if ( '1' === $no && 'video' !== $kind ) {
				return new WP_Error( 'tp_cn_video', '1번(표지)은 영상 파일(mp4·mov·m4v·webm)만 받아요' );
			}
			$out['files'][ $no ] = array(
				'tmp'  => $file['tmp_name'],
				'name' => sanitize_file_name( $file['name'] ),
				'ext'  => $ext,
				'kind' => $kind,
			);
		}
	}
	return $out;
}

/*
 * 인터뷰 폼(1.8.0, 10/17 사용자: 도우미 = 카드뉴스 폼 + 인터뷰 폼). 형식은 주문하는 사람이 고른다 —
 * 카피 모음형 때처럼 카드 모양으로 자동으로 고르다 엉뚱한 틀이 붙는 일을 막으려고. 값은 cardnews.py의 order.json "layout"과 같다
 */
const TP_CN_LAYOUTS = array(
	'qa'    => '질문 여러 개',
	'panel' => '패널',
);

/**
 * 인터뷰 대상 줄들(이름 · 인스타 주소 · 프로필 사진, 모두 선택) → 목록 또는 WP_Error.
 * 글 시작·끝 프로필 카드 재료다. 비워도 주문은 된다(사용자 결정: 항상 선택) — 셰프가 프로필 카드를 빼고 알린다.
 * 파일은 아직 옮기지 않는다(다른 칸 검사가 다 끝난 뒤에 옮긴다).
 * 광고 폼(1.11.0)도 같은 칸을 광고 브랜드 칸으로 쓴다 — $label은 오류 문구에 들어갈 이름.
 */
function tp_cn_parse_people( $names, $instas, $files, $label = '인터뷰 대상' ) {
	$out = array();
	foreach ( (array) $names as $i => $name ) {
		$name  = trim( sanitize_text_field( (string) $name ) );
		$raw   = trim( (string) ( $instas[ $i ] ?? '' ) );
		$insta = esc_url_raw( $raw, array( 'https', 'http' ) );
		$has   = isset( $files['error'][ $i ] ) && UPLOAD_ERR_NO_FILE !== $files['error'][ $i ];
		if ( '' === $name && '' === $raw && ! $has ) {
			continue;
		}
		$who = '' !== $name ? $name : ( '' !== $raw ? $raw : '사진만 넣은 줄' );
		if ( '' !== $raw && ! preg_match( '#^https?://(www\.)?instagram\.com/[A-Za-z0-9._]+/?#', $insta ) ) {
			return new WP_Error( 'tp_cn_people', "{$label} '{$who}'의 인스타 주소를 못 읽었어요 — https://www.instagram.com/계정/ 모양으로 붙여 넣어 주세요" );
		}
		if ( '' === $name && '' === $raw ) {
			return new WP_Error( 'tp_cn_people', "{$label} 사진만 있고 이름·인스타 주소가 없는 줄이 있어요" );
		}
		$p = array(
			'name'  => $name,
			'insta' => $insta,
			'tmp'   => '',
			'ext'   => '',
		);
		if ( $has ) {
			if ( UPLOAD_ERR_OK !== $files['error'][ $i ] ) {
				return new WP_Error( 'tp_cn_people', "{$label} '{$who}' 사진을 올리다 멈췄어요 (오류 {$files['error'][ $i ]})" );
			}
			$ext = strtolower( pathinfo( $files['name'][ $i ], PATHINFO_EXTENSION ) );
			if ( 'image' !== ( TP_CN_FILE_TYPES[ $ext ] ?? '' ) || 'image' !== tp_cn_sniff( $files['tmp_name'][ $i ] ) ) {
				return new WP_Error( 'tp_cn_people', "{$label} '{$who}' 사진은 jpg·png·webp만 받아요" );
			}
			$p['tmp'] = $files['tmp_name'][ $i ];
			$p['ext'] = $ext;
		}
		$out[] = $p;
	}
	return $out;
}

/**
 * 셰프가 손본 것 한 줄 → [단계, 글자]. 단계는 셰프가 붙인 이름표로 정한다(10/18 사용자: 중요도에 따라 강조, 시안 1018-1 C).
 * 3 = '꼭 확인:'(발행하면 곤란할 수 있음) · 2 = '확인 필요:'(한 번 봐야 함) · 1 = 셰프가 한 일 기록.
 * '꼭 확인'은 1.12.0부터 생긴 이름표라 그 전 주문은 '확인 필요'까지만 나온다
 */
function tp_cn_level( $line ) {
	if ( preg_match( '/^\s*꼭\s*확인\s*:\s*(.*)$/su', $line, $m ) ) {
		return array( 3, $m[1] );
	}
	if ( preg_match( '/^\s*확인\s*필요\s*:\s*(.*)$/su', $line, $m ) ) {
		return array( 2, $m[1] );
	}
	return array( 1, $line );
}

/**
 * 손본 것 한 줄을 <li>로. 확인 항목은 이모지를 앞에 달고 이름표는 뗀다(이모지가 그 뜻을 대신한다)
 */
function tp_cn_change_li( $line ) {
	list( $lv, $text ) = tp_cn_level( $line );
	$mark = array( 3 => '❗ ', 2 => '🟡 ', 1 => '' )[ $lv ];
	return '<li class="lv' . $lv . '">' . esc_html( $mark . $text ) . '</li>';
}

/**
 * 받은 zip이 피그마 플러그인 결과인지 본다 (figma/scan.json이 있어야 한다).
 * 돌려주는 값: 묶음 이름(scan.json의 group.name) 또는 WP_Error. ZipArchive가 없는 서버면 검사를 건너뛴다.
 */
function tp_cn_check_zip( $path, $filename ) {
	$fallback = preg_replace( '/\.zip$/i', '', $filename );
	if ( ! class_exists( 'ZipArchive' ) ) {
		return $fallback;
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $path ) ) {
		return new WP_Error( 'tp_cn_zip', 'zip 파일을 열 수 없어요. 내려받다 끊긴 파일일 수 있어요 — 다시 받아 주세요' );
	}
	$scan = $zip->getFromName( 'figma/scan.json' );
	$zip->close();
	if ( false === $scan ) {
		return new WP_Error( 'tp_cn_zip', "이 zip에는 figma/scan.json이 없어요. 피그마 플러그인 '트란시스 카드뉴스 비서'로 받은 zip인지 확인해 주세요" );
	}
	$data = json_decode( $scan, true );
	return ! empty( $data['group']['name'] ) ? $data['group']['name'] : $fallback;
}

// ── 초인종: 주문이 들어오면 클라우드의 셰프(Claude Code routine)를 바로 깨운다 ──────────
/*
 * 10/17 사용자 결정 A(즉시 신호). 매시간 알람으로 깨우면 최대 1시간을 기다리고 주문 없는 날에도 빈손으로 깨어나서다.
 * routine의 API 트리거 주소로 POST 한 번 = 셰프 한 번 출근. 열쇠(토큰)는 이 사이트 설정에만 두고 화면에 다시 보여 주지 않는다.
 * 열쇠가 새도 할 수 있는 건 "셰프 깨우기"뿐이다: 셰프는 신호에 딸린 글을 무시하고 탭의 '접수' 주문만 처리한다(tools/cardnews/PROMPT.md).
 */
const TP_CN_BELL = 'tp_cn_bell'; // 옵션 이름: array( 'url' => …, 'token' => … )

/** 트란시스 일정표 앱 주소(숨은 주소). TP Transis Frame 설정이 없으면 빈 문자열 — 탭은 안내만 보여 준다 */
function tp_cn_transis_app_url() {
	$opt  = get_option( 'tp_transis_frame' );
	$slug = is_array( $opt ) && ! empty( $opt['slug'] ) ? trim( $opt['slug'], '/' ) : '';
	return '' === $slug ? '' : home_url( '/' . $slug . '/' );
}

function tp_cn_ring( $id ) {
	$bell = get_option( TP_CN_BELL, array() );
	if ( empty( $bell['url'] ) || empty( $bell['token'] ) ) {
		$err = '초인종이 아직 설정되지 않았어요 (아래 "셰프 초인종 설정")';
	} else {
		$res = wp_remote_post(
			$bell['url'],
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization'     => 'Bearer ' . $bell['token'],
					// routine 문서(10/17 확인)가 요구하는 머리글. 실험 기능이라 바뀌면 이 날짜만 고친다
					'anthropic-beta'    => 'experimental-cc-routine-2026-04-01',
					'anthropic-version' => '2023-06-01',
					'Content-Type'      => 'application/json',
				),
				// 셰프는 이 글을 따르지 않는다. 실행 기록에서 어느 주문 때 깨웠는지 알아보는 표시일 뿐
				'body'    => wp_json_encode( array( 'text' => "order {$id}" ) ),
			)
		);
		$code = is_wp_error( $res ) ? 0 : wp_remote_retrieve_response_code( $res );
		if ( $code >= 200 && $code < 300 ) {
			update_post_meta( $id, '_tp_cn_rang_at', time() );
			delete_post_meta( $id, '_tp_cn_bell_err' );
			return true;
		}
		$err = is_wp_error( $res )
			? '셰프에게 연결하지 못했어요: ' . $res->get_error_message()
			: "셰프가 응답하지 않았어요 (오류 {$code}" . ( 401 === $code ? ', 열쇠가 틀렸거나 바뀌었어요' : '' ) . ')';
	}
	update_post_meta( $id, '_tp_cn_bell_err', $err );
	return false;
}

// 초인종 설정 저장 (관리자만). 열쇠 칸을 비워 두면 기존 열쇠를 그대로 둔다 — 화면에 열쇠를 다시 채워 보여 주지 않아서
add_action(
	'admin_post_tp_cn_bell',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 바꿀 수 있어요' );
		}
		check_admin_referer( 'tp_cn_bell' );
		$bell  = get_option( TP_CN_BELL, array() );
		$url   = esc_url_raw( trim( wp_unslash( $_POST['bell_url'] ?? '' ) ) );
		$token = trim( sanitize_text_field( wp_unslash( $_POST['bell_token'] ?? '' ) ) );
		$back  = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		// 엉뚱한 곳으로 열쇠를 보내지 않게, routine 주소 모양만 받는다
		if ( ! preg_match( '#^https://api\.anthropic\.com/v1/claude_code/routines/trig_\w+/fire$#', $url ) ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( '초인종 주소는 https://api.anthropic.com/v1/claude_code/routines/trig_…/fire 모양이에요' ), $back ) );
			exit;
		}
		$bell['url'] = $url;
		if ( '' !== $token ) {
			$bell['token'] = $token;
		}
		update_option( TP_CN_BELL, $bell, false ); // autoload 끔: 탭에서만 쓰는 값이라 모든 페이지에서 불러올 필요 없다
		wp_safe_redirect( add_query_arg( 'tp_cn_info', 'bell', $back ) );
		exit;
	}
);

// "셰프 다시 부르기": 초인종이 실패했거나, 주방이 멈췄거나, 너무 오래 요리 중일 때
add_action(
	'admin_post_tp_cn_recall',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 부를 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_recall_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		// 처음 요리는 zip이 있어야 하고, 수정은 지난번 작업 기록(state)만 있어도 된다
		$can = get_post_meta( $id, '_tp_cn_zip', true ) || ( get_post_meta( $id, '_tp_cn_feedback', true ) && get_post_meta( $id, '_tp_cn_state', true ) );
		if ( TP_CN_TYPE !== get_post_type( $id ) || ! $can ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( '이 주문은 zip이 없어서 다시 요리할 수 없어요. 새로 주문해 주세요' ), $back ) );
			exit;
		}
		// 셰프는 '접수' 주문만 가져가니 상태를 되돌린 뒤 깨운다. 수정 요청이 남아 있으면 '수정 접수'로
		$again = get_post_meta( $id, '_tp_cn_answer', true ) ? 'answered' : ( get_post_meta( $id, '_tp_cn_feedback', true ) ? 'revise' : 'new' );
		update_post_meta( $id, '_tp_cn_status', $again );
		delete_post_meta( $id, '_tp_cn_error' );
		$ok = tp_cn_ring( $id );
		wp_safe_redirect( $ok ? add_query_arg( 'tp_cn_ok', $id, $back ) : add_query_arg( 'tp_cn_err', rawurlencode( get_post_meta( $id, '_tp_cn_bell_err', true ) ), $back ) );
		exit;
	}
);

// "고쳐 주세요": 완성된 초안에 메모로 수정을 요청한다. 셰프가 지난번 작업 기록을 이어받아 같은 초안을 고친다
add_action(
	'admin_post_tp_cn_revise',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 요청할 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_revise_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$fail = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};
		$text   = trim( sanitize_textarea_field( wp_unslash( $_POST['feedback'] ?? '' ) ) );
		$status = TP_CN_TYPE === get_post_type( $id ) ? get_post_meta( $id, '_tp_cn_status', true ) : '';
		if ( 'done' !== $status && 'failed' !== $status ) {
			$fail( '완성되거나 멈춘 주문만 고칠 수 있어요' );
		}
		if ( '' === $text ) {
			$fail( '무엇을 고칠지 적어 주세요' );
		}
		$has_state = (bool) get_post_meta( $id, '_tp_cn_state', true );
		if ( 'done' === $status || $has_state ) {
			if ( ! $has_state ) {
				// 1.4.0 전에 완성된 주문은 작업 기록이 없어서 이어서 고칠 수 없다
				$fail( '이 주문은 작업 기록이 없어서 고칠 수 없어요. 편집기에서 직접 고치거나 새로 주문해 주세요' );
			}
			// 수정하다 멈춘 주문(1.28.0)이면 처음 요청을 지우지 않고 이어 붙인다 — 멈춘 이유에 답하는 글이라 앞 요청이 같이 있어야 뜻이 통한다
			$before = 'failed' === $status ? (string) get_post_meta( $id, '_tp_cn_feedback', true ) : '';
			update_post_meta( $id, '_tp_cn_feedback', '' === $before ? $text : $before . "\n(추가) " . $text );
			update_post_meta( $id, '_tp_cn_status', 'revise' );
		} elseif ( get_post_meta( $id, '_tp_cn_zip', true ) ) {
			// 처음 요리에서 멈췄다면 고칠 초안(작업 기록)이 아직 없다. 셰프는 zip을 다시 풀어 처음부터 하되, 사람이 쓴 말은 메모 칸으로 넘긴다
			// (메모는 이 글 하나만 움직이는 지시라서 셰프 지시문이 이미 그렇게 읽는다)
			$memo = (string) get_post_meta( $id, '_tp_cn_memo', true );
			update_post_meta( $id, '_tp_cn_memo', '' === $memo ? $text : $memo . "\n(주방이 멈춘 뒤 추가) " . $text );
			update_post_meta( $id, '_tp_cn_status', 'new' );
		} else {
			$fail( '이 주문은 zip도 작업 기록도 없어서 다시 요리할 수 없어요. 새로 주문해 주세요' );
		}
		delete_post_meta( $id, '_tp_cn_error' );
		if ( ! tp_cn_ring( $id ) ) {
			$fail( '요청은 받았는데 셰프를 깨우지 못했어요. ' . get_post_meta( $id, '_tp_cn_bell_err', true ) );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_rev', $id, $back ) );
		exit;
	}
);

// 발행: 셰프가 만든 초안을 탭에서 바로 공개한다(10/18 사용자 — 편집기에서 열어 발행하던 걸 버튼 하나로).
// 발행되면 원래 있던 transition_post_status 훅이 zip·영상·대상 사진을 지운다
add_action(
	'admin_post_tp_cn_publish',
	function () {
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_publish_' . $id );
		$back  = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$draft = (int) get_post_meta( $id, '_tp_cn_post', true );
		$fail  = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};
		if ( TP_CN_TYPE !== get_post_type( $id ) || ! $draft || 'post' !== get_post_type( $draft ) ) {
			$fail( '발행할 초안을 찾지 못했어요' );
		}
		if ( ! current_user_can( 'publish_post', $draft ) ) {
			$fail( '이 계정은 글을 발행할 권한이 없어요' );
		}
		if ( 'publish' === get_post_status( $draft ) ) {
			$fail( '이미 발행된 글이에요' );
		}
		if ( in_array( get_post_meta( $id, '_tp_cn_status', true ), array( 'working', 'revise', 'answered' ), true ) ) {
			$fail( '셰프가 이 초안을 고치는 중이에요. 끝난 뒤에 발행해 주세요' );
		}
		$args = array( 'ID' => $draft, 'post_status' => 'publish' );
		if ( 'future' === get_post_status( $draft ) ) {
			// 예약된 글을 지금 발행: 날짜가 미래로 남아 있으면 워드프레스가 다시 '예약'으로 되돌린다
			$args['post_date']     = current_time( 'mysql' );
			$args['post_date_gmt'] = current_time( 'mysql', true );
			$args['edit_date']     = true;
		}
		$r = wp_update_post( $args, true );
		if ( is_wp_error( $r ) ) {
			$fail( '발행하지 못했어요: ' . $r->get_error_message() );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_info', '발행했어요! 사이트에 공개됐어요.', $back ) );
		exit;
	}
);

// ── 예약 발행 (1.26.0, 10/23 사용자) ─────────────────────────
// 주간 글은 금요일 08:30에 인스타·뉴스레터와 같이 나가야 해서, 그 시각을 사람이 지키지 않아도 되게 한다.
// 워드프레스 '예약'(post_status future)을 그대로 쓴다. 시각이 되면 워드프레스가 발행하고, 그때도 transition_post_status 훅이 zip을 지운다.
/** 시각 칸의 기본값: 다가오는 금요일 08:30(사이트 시간대). 지금이 그 시각 5분 전 안쪽이면 다음 주 금요일. */
function tp_cn_default_when() {
	$now = new DateTimeImmutable( 'now', wp_timezone() );
	$t   = $now->setTime( 8, 30 )->modify( '+' . ( ( 5 - (int) $now->format( 'N' ) + 7 ) % 7 ) . ' days' );
	if ( $t->getTimestamp() < $now->getTimestamp() + 300 ) {
		$t = $t->modify( '+7 days' );
	}
	return $t->format( 'Y-m-d\TH:i' );
}

/** '2026-10-23T08:30' → 예약을 건다. 돌려주는 값 = 성공하면 예약 시각의 타임스탬프, 아니면 WP_Error. */
function tp_cn_schedule_post( $draft, $when ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', (string) $when ) ) {
		return new WP_Error( 'when', '예약 날짜와 시각을 확인해 주세요' );
	}
	$at = date_create_immutable( $when, wp_timezone() );
	if ( ! $at ) {
		return new WP_Error( 'when', '예약 날짜와 시각을 확인해 주세요' );
	}
	if ( $at->getTimestamp() < time() + 300 ) {
		return new WP_Error( 'when', '예약 시각은 지금부터 5분 뒤 이후로 골라 주세요' );
	}
	$r = wp_update_post(
		array(
			'ID'            => $draft,
			'post_status'   => 'future',
			'post_date'     => $at->format( 'Y-m-d H:i:s' ),
			'post_date_gmt' => gmdate( 'Y-m-d H:i:s', $at->getTimestamp() ),
			'edit_date'     => true,
		),
		true
	);
	if ( is_wp_error( $r ) ) {
		return new WP_Error( 'save', '예약하지 못했어요: ' . $r->get_error_message() );
	}
	if ( 'future' !== get_post_status( $draft ) ) {
		return new WP_Error( 'save', '예약이 걸리지 않았어요 (글 상태: ' . get_post_status( $draft ) . ')' );
	}
	return $at->getTimestamp();
}

add_action(
	'admin_post_tp_cn_schedule',
	function () {
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_schedule_' . $id );
		$back  = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$draft = (int) get_post_meta( $id, '_tp_cn_post', true );
		$fail  = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};
		if ( TP_CN_TYPE !== get_post_type( $id ) || ! $draft || 'post' !== get_post_type( $draft ) ) {
			$fail( '예약할 초안을 찾지 못했어요' );
		}
		if ( ! current_user_can( 'publish_post', $draft ) ) {
			$fail( '이 계정은 글을 발행할 권한이 없어요' );
		}
		if ( 'publish' === get_post_status( $draft ) ) {
			$fail( '이미 발행된 글이에요' );
		}
		if ( in_array( get_post_meta( $id, '_tp_cn_status', true ), array( 'working', 'revise', 'answered' ), true ) ) {
			$fail( '셰프가 이 초안을 고치는 중이에요. 끝난 뒤에 예약해 주세요' );
		}
		$ts = tp_cn_schedule_post( $draft, sanitize_text_field( wp_unslash( $_POST['when'] ?? '' ) ) );
		if ( is_wp_error( $ts ) ) {
			$fail( $ts->get_error_message() );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_info', rawurlencode( '⏰ 예약했어요! ' . wp_date( 'n월 j일 H:i', $ts ) . '에 사이트에 공개돼요.' ), $back ) );
		exit;
	}
);

// 예약 취소: 초안으로 돌려 둔다(예약 시각은 그대로 남아 있어도 초안이라 공개되지 않는다)
add_action(
	'admin_post_tp_cn_unschedule',
	function () {
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_unschedule_' . $id );
		$back  = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$draft = (int) get_post_meta( $id, '_tp_cn_post', true );
		$fail  = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};
		if ( TP_CN_TYPE !== get_post_type( $id ) || ! $draft || 'future' !== get_post_status( $draft ) ) {
			$fail( '예약된 글이 아니에요' );
		}
		if ( ! current_user_can( 'publish_post', $draft ) ) {
			$fail( '이 계정은 글을 발행할 권한이 없어요' );
		}
		$r = wp_update_post( array( 'ID' => $draft, 'post_status' => 'draft' ), true );
		if ( is_wp_error( $r ) ) {
			$fail( '예약을 취소하지 못했어요: ' . $r->get_error_message() );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_info', rawurlencode( '예약을 취소했어요. 초안으로 돌아갔어요.' ), $back ) );
		exit;
	}
);

// ── 저장·좋아요 1,000+ 뱃지 (저장 1.24.0 10/20 사용자 A+B, 좋아요 10/26 추가) ─────────────
// 인스타 저장 1,000회를 넘긴 카드의 글에 태그 tp1000을, 좋아요 1,000회를 넘긴 글에 tplike1000을 달면
// 사이트 카드에 "저장 1,000+" / "좋아요 1,000+" 뱃지가 뜬다(모양은 추가 CSS·TP Related Posts).
// 한 글에 둘 다 달 수 있다(10/26 사용자 결정): 저장이 1,000을 넘는 글은 좋아요도 넘는 일이 흔할 것이라, 택일로 막지 않았다.
// 수치는 계정 주인만 인사이트에서 보니 사람이 표시한다: 주문할 때 체크(A) 또는 나중에 넘기면 주문 목록의 버튼(B).
// 표시 여부는 주문 메타가 기준이다 — 셰프의 draft가 고칠 때마다 order.json의 태그로 통째로 덮어써서,
// 셰프가 보고할 때마다 여기서 다시 붙인다. 뱃지 종류는 이 표 한 곳에서만 늘리고 줄인다(키 = 폼 체크 칸 이름)
const TP_CN_BADGES = array(
	'saved' => array(
		'meta'  => '_tp_cn_saved',
		'slug'  => 'tp1000',
		'name'  => 'TP 1,000',
		'label' => '저장',
		'icon'  => '🔖',
		'hint'  => '인스타 저장이 1,000번 넘었으면 눌러 주세요',
	),
	'liked' => array(
		'meta'  => '_tp_cn_liked',
		'slug'  => 'tplike1000',
		'name'  => 'TP 좋아요 1,000',
		'label' => '좋아요',
		'icon'  => '❤️',
		'hint'  => '인스타 좋아요가 1,000번 넘었으면 눌러 주세요',
	),
);

// 뱃지 하나를 주문 메타에 맞춰 글에 붙이거나 뗀다(다른 뱃지·다른 태그는 건드리지 않는다)
function tp_cn_apply_badge( $order_id, $key ) {
	$badge   = TP_CN_BADGES[ $key ];
	$post_id = (int) get_post_meta( $order_id, '_tp_cn_post', true );
	if ( ! $post_id || 'post' !== get_post_type( $post_id ) ) {
		return;
	}
	$term = get_term_by( 'slug', $badge['slug'], 'post_tag' );
	if ( ! $term ) {
		// 태그를 지웠을 수도 있어서(10/16 시리즈를 접을 때 tp1000이 그랬다), 없으면 같은 주소로 다시 만든다
		$made = wp_insert_term( $badge['name'], 'post_tag', array( 'slug' => $badge['slug'] ) );
		if ( is_wp_error( $made ) ) {
			return;
		}
		$term_id = (int) $made['term_id'];
	} else {
		$term_id = (int) $term->term_id;
	}
	if ( get_post_meta( $order_id, $badge['meta'], true ) ) {
		wp_set_post_terms( $post_id, array( $term_id ), 'post_tag', true ); // true = 다른 태그는 그대로 두고 더하기
	} else {
		wp_remove_object_terms( $post_id, $term_id, 'post_tag' );
	}
}

// 셰프가 보고한 뒤: 켜져 있는 뱃지만 다시 붙인다(꺼진 뱃지까지 떼면 관리자 화면에서 손으로 단 같은 태그가 사라질 수 있다)
function tp_cn_reapply_badges( $order_id ) {
	foreach ( TP_CN_BADGES as $key => $badge ) {
		if ( get_post_meta( $order_id, $badge['meta'], true ) ) {
			tp_cn_apply_badge( $order_id, $key );
		}
	}
}

add_action(
	'admin_post_tp_cn_badge',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 바꿀 수 있어요' );
		}
		$id  = (int) ( $_POST['order'] ?? 0 );
		$key = (string) ( $_POST['badge'] ?? '' );
		if ( ! isset( TP_CN_BADGES[ $key ] ) ) {
			wp_die( '알 수 없는 뱃지예요' );
		}
		check_admin_referer( 'tp_cn_badge_' . $id . '_' . $key );
		$badge = TP_CN_BADGES[ $key ];
		$back  = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		if ( TP_CN_TYPE !== get_post_type( $id ) || ! get_post_meta( $id, '_tp_cn_post', true ) ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( '글이 만들어진 주문에만 표시할 수 있어요' ), $back ) );
			exit;
		}
		$on = ! get_post_meta( $id, $badge['meta'], true );
		update_post_meta( $id, $badge['meta'], $on ? 1 : 0 );
		tp_cn_apply_badge( $id, $key );
		wp_safe_redirect( add_query_arg( 'tp_cn_info', rawurlencode( $on ? "{$badge['icon']} {$badge['label']} 1,000+ 뱃지를 달았어요." : "{$badge['label']} 1,000+ 뱃지를 뗐어요." ), $back ) );
		exit;
	}
);

// 셰프의 질문에 답하기: 답을 남기고 셰프를 다시 부른다. 셰프는 질문할 때 맡긴 작업 기록을 되살려 이어서 만든다
add_action(
	'admin_post_tp_cn_answer',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 답할 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_answer_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$text = trim( sanitize_textarea_field( wp_unslash( $_POST['answer'] ?? '' ) ) );
		if ( TP_CN_TYPE !== get_post_type( $id ) || 'question' !== get_post_meta( $id, '_tp_cn_status', true ) || '' === $text ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( '셰프가 질문한 주문에만, 답을 적어서 보낼 수 있어요' ), $back ) );
			exit;
		}
		update_post_meta( $id, '_tp_cn_answer', $text );
		update_post_meta( $id, '_tp_cn_status', 'answered' );
		delete_post_meta( $id, '_tp_cn_error' );
		$ok = tp_cn_ring( $id );
		wp_safe_redirect( $ok ? add_query_arg( 'tp_cn_info', '답을 전했어요! 셰프 트란시스가 이어서 만들어요.', $back ) : add_query_arg( 'tp_cn_err', rawurlencode( '답은 받았는데 셰프를 깨우지 못했어요. ' . get_post_meta( $id, '_tp_cn_bell_err', true ) ), $back ) );
		exit;
	}
);

// "주문 지우기": 주문 + 그 임시글 + 셰프가 그 주문 때 올린 사진을 함께 버린다(10/17 사용자).
// 발행된 글은 절대 안 지우고 주문 기록만 지운다. 요리 중인 주문은 셰프가 일하는 중이라 막는다
add_action(
	'admin_post_tp_cn_delete',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 지울 수 있어요' );
		}
		$id = (int) ( $_POST['order'] ?? 0 );
		check_admin_referer( 'tp_cn_delete_' . $id );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$say  = function ( $kind, $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_' . $kind, rawurlencode( $msg ), $back ) );
			exit;
		};
		if ( TP_CN_TYPE !== get_post_type( $id ) ) {
			$say( 'err', '없는 주문이에요' );
		}
		if ( 'working' === get_post_meta( $id, '_tp_cn_status', true ) ) {
			$say( 'err', '셰프가 요리 중이라 지금은 못 지워요. 끝난 뒤에 지워 주세요' );
		}
		$draft = get_post( (int) get_post_meta( $id, '_tp_cn_post', true ) );
		$note  = '';
		if ( $draft && 'future' === $draft->post_status ) {
			$say( 'err', '예약된 글이 있어서 지울 수 없어요. 먼저 예약을 취소해 주세요 (지우면 예약된 글도 같이 지워져요)' );
		}
		if ( $draft && 'post' === $draft->post_type && 'publish' !== $draft->post_status ) {
			// 셰프가 올린 사진 = 이 글이 쓰는 사진 중 파일 이름이 "order-<주문 번호>-"로 시작하는 것(cardnews.py upload가 붙이는 이름).
			// 다른 글과 같이 쓰는 사진일 수 있는 나머지는 건드리지 않는다.
			// 본문 사진(wp-image-N)·영상 블록({"id":N})·대표 이미지에 더해, 셰프 작업 기록(media.json)도 본다 —
			// 영상 포스터는 주소로만 쓰여서 본문에 번호가 없고, 수정 때 바꾼 정지 화면은 본문에서 빠져 있다
			preg_match_all( '/wp-image-(\d+)|<!-- wp:video \{"id":(\d+)/', $draft->post_content, $m );
			$ids   = array_map( 'intval', array_filter( array_merge( $m[1], $m[2] ) ) );
			$state = json_decode( (string) get_post_meta( $id, '_tp_cn_state', true ), true );
			foreach ( (array) json_decode( (string) ( $state['media.json'] ?? '' ), true ) as $item ) {
				$ids[] = (int) ( $item['id'] ?? 0 );
			}
			$media = array_unique( array_merge( $ids, array( (int) get_post_thumbnail_id( $draft ) ) ) );
			$gone  = 0;
			foreach ( $media as $mid ) {
				$file = $mid ? get_attached_file( $mid ) : '';
				if ( $file && 0 === strpos( wp_basename( $file ), "order-{$id}-" ) && wp_delete_attachment( $mid, true ) ) {
					++$gone;
				}
			}
			wp_delete_post( $draft->ID, true );
			$note = " 임시글 {$draft->ID}과 사진 {$gone}장도 지웠어요.";
		} elseif ( $draft && 'publish' === $draft->post_status ) {
			$note = " 글 {$draft->ID}은 이미 발행돼서 그대로 뒀어요.";
		}
		wp_delete_post( $id, true ); // zip은 before_delete_post에서 같이 지워진다
		$say( 'info', "주문 {$id}을 지웠어요.{$note}" );
	}
);

// zip·영상 카드 파일은 글이 발행되거나 휴지통에 갈 때 지운다(10/17 사용자: 수정 요청 때 "사진 바꿔"·"다른 장면으로"에 원본이 필요해서 완성 때 지우던 것을 바꿈).
// 발행 전까지는 주문당 수~수십 MB가 남는다. 남의 영상 원본도 여기서 지워져서 사이트에 오래 남지 않는다
function tp_cn_drop_zip_for_post( $post_id ) {
	$orders = get_posts(
		array(
			'post_type'   => TP_CN_TYPE,
			'post_status' => 'private',
			'numberposts' => 5,
			'meta_key'    => '_tp_cn_post',
			'meta_value'  => (int) $post_id,
		)
	);
	foreach ( $orders as $order ) {
		tp_cn_unlink_files( $order->ID );
	}
}
add_action(
	'transition_post_status',
	function ( $new, $old, $post ) {
		if ( 'post' === $post->post_type && 'publish' === $new && 'publish' !== $old ) {
			tp_cn_drop_zip_for_post( $post->ID );
		}
	},
	10,
	3
);
add_action( 'wp_trash_post', 'tp_cn_drop_zip_for_post' );

// ── 주문 받기 (탭의 폼) ──────────────────────────────────

add_action(
	'admin_post_tp_cn_order',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '관리자만 주문할 수 있어요' );
		}
		check_admin_referer( 'tp_cn_order' );
		$back = admin_url( 'admin.php?page=' . TP_CN_SLUG );
		$fail = function ( $msg ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'tp_cn_err', rawurlencode( $msg ), $back ) );
			exit;
		};

		$file = isset( $_FILES['zip'] ) ? $_FILES['zip'] : null;
		if ( ! $file || UPLOAD_ERR_NO_FILE === $file['error'] ) {
			$fail( 'zip 파일을 골라 주세요' );
		}
		if ( UPLOAD_ERR_OK !== $file['error'] ) {
			$fail( "zip을 올리다 멈췄어요 (오류 {$file['error']}). 파일이 너무 크면 이렇게 될 수 있어요" );
		}
		if ( ! preg_match( '/\.zip$/i', $file['name'] ) || $file['size'] > TP_CN_MAX ) {
			$fail( 'zip 파일만, 200MB까지 받을 수 있어요' );
		}
		$caption = trim( sanitize_textarea_field( wp_unslash( $_POST['caption'] ?? '' ) ) );
		if ( '' === $caption ) {
			$fail( '인스타 캡션을 붙여 넣어 주세요' );
		}
		$rows = tp_cn_parse_video_rows( wp_unslash( $_POST['vcard'] ?? array() ), wp_unslash( $_POST['vurl'] ?? array() ), $_FILES['vfile'] ?? array() );
		if ( is_wp_error( $rows ) ) {
			$fail( $rows->get_error_message() );
		}
		// 인터뷰 폼: 형식은 꼭 고르고, 대상 칸은 비워도 된다. 카드뉴스 폼이면 인터뷰 칸에 뭐가 남아 있어도 안 본다
		$interview = 'interview' === ( $_POST['kind'] ?? '' );
		$layout    = $interview ? sanitize_key( wp_unslash( $_POST['layout'] ?? '' ) ) : '';
		if ( $interview && ! isset( TP_CN_LAYOUTS[ $layout ] ) ) {
			$fail( '인터뷰 형식을 골라 주세요 (질문 여러 개 / 패널)' );
		}
		// 광고 폼(1.11.0, 10/18 사용자): 인터뷰처럼 글 시작·끝에 광고 브랜드 프로필 카드를 단다. 같은 칸(pname·pinsta·pfile)을 쓴다
		$ad     = 'ad' === ( $_POST['kind'] ?? '' );
		$label  = $ad ? '광고 브랜드' : '인터뷰 대상';
		$people = ( $interview || $ad ) ? tp_cn_parse_people( wp_unslash( $_POST['pname'] ?? array() ), wp_unslash( $_POST['pinsta'] ?? array() ), $_FILES['pfile'] ?? array(), $label ) : array();
		if ( is_wp_error( $people ) ) {
			$fail( $people->get_error_message() );
		}
		// 광고 글은 브랜드 계정 링크가 핵심이라 인스타 주소는 꼭 받는다(사진은 없어도 카드는 만들어진다)
		if ( $ad && ! array_filter( array_column( $people, 'insta' ) ) ) {
			$fail( '광고 브랜드의 인스타 주소를 넣어 주세요' );
		}
		$group = tp_cn_check_zip( $file['tmp_name'], $file['name'] );
		if ( is_wp_error( $group ) ) {
			$fail( $group->get_error_message() );
		}

		// wp_handle_upload는 허용 형식 목록에 zip이 없으면 막는다 — 관리자만 쓰는 칸이라 직접 옮기고 위에서 확장자·내용을 본다.
		// 영상 카드 파일도 미디어 라이브러리가 아니라 zip 옆에 둔다: 남의 영상 원본은 사이트에 공개되면 안 되고, 셰프만 REST로 받아 간다
		$name = bin2hex( random_bytes( 16 ) ) . '.zip';
		if ( ! move_uploaded_file( $file['tmp_name'], tp_cn_dir() . '/' . $name ) ) {
			$fail( 'zip을 저장하지 못했어요. 잠시 뒤 다시 해 주세요' );
		}
		$stored = array();
		foreach ( $rows['files'] as $no => $f ) {
			$fname = bin2hex( random_bytes( 16 ) ) . '.' . $f['ext'];
			if ( ! move_uploaded_file( $f['tmp'], tp_cn_dir() . '/' . $fname ) ) {
				// 반쯤 저장된 주문을 남기지 않게 이미 옮긴 파일까지 치운다
				foreach ( array_merge( array( $name ), array_column( $stored, 'file' ) ) as $gone ) {
					unlink( tp_cn_dir() . '/' . $gone );
				}
				$fail( "{$no}번 파일을 저장하지 못했어요. 잠시 뒤 다시 해 주세요" );
			}
			$stored[ $no ] = array(
				'file' => $fname,
				'name' => $f['name'],
				'kind' => $f['kind'],
			);
		}
		foreach ( $people as $i => $p ) {
			$people[ $i ]['file'] = '';
			if ( $p['tmp'] ) {
				$pname = bin2hex( random_bytes( 16 ) ) . '.' . $p['ext'];
				if ( ! move_uploaded_file( $p['tmp'], tp_cn_dir() . '/' . $pname ) ) {
					foreach ( array_merge( array( $name ), array_column( $stored, 'file' ), array_filter( array_column( $people, 'file' ) ) ) as $gone ) {
						unlink( tp_cn_dir() . '/' . $gone );
					}
					$fail( "{$label} '{$p['name']}' 사진을 저장하지 못했어요. 잠시 뒤 다시 해 주세요" );
				}
				$people[ $i ]['file'] = $pname;
			}
			unset( $people[ $i ]['tmp'], $people[ $i ]['ext'] );
		}

		$id = wp_insert_post(
			array(
				'post_type'   => TP_CN_TYPE,
				'post_status' => 'private',
				'post_title'  => sanitize_text_field( $group ),
			)
		);
		update_post_meta( $id, '_tp_cn_status', 'new' );
		update_post_meta( $id, '_tp_cn_zip', $name );
		update_post_meta( $id, '_tp_cn_caption', $caption );
		update_post_meta( $id, '_tp_cn_videos', $rows['videos'] );
		update_post_meta( $id, '_tp_cn_files', $stored );
		update_post_meta( $id, '_tp_cn_memo', trim( sanitize_textarea_field( wp_unslash( $_POST['memo'] ?? '' ) ) ) );
		// 뉴스레터 폼(1.20.0, 10/18 사용자): 주간 총정리 zip → 사이트 주간 글 초안 + 뉴스레터. 이번 주 소개할 제보 주소를 줄마다 받는다
		$newsletter = 'newsletter' === ( $_POST['kind'] ?? '' );
		update_post_meta( $id, '_tp_cn_kind', $interview ? 'interview' : ( $ad ? 'ad' : ( $newsletter ? 'newsletter' : 'cardnews' ) ) );
		$reports = $newsletter ? preg_split( '/\R/', (string) wp_unslash( $_POST['reports'] ?? '' ) ) : array();
		update_post_meta( $id, '_tp_cn_reports', array_values( array_filter( array_map( 'esc_url_raw', array_map( 'trim', $reports ) ) ) ) );
		update_post_meta( $id, '_tp_cn_layout', $layout );
		update_post_meta( $id, '_tp_cn_people', array_values( $people ) );
		// 주간 총정리(뉴스레터)는 카드 한 편이 아니라 한 주 모음이라 뱃지 대상이 아니다
		foreach ( TP_CN_BADGES as $key => $badge ) {
			update_post_meta( $id, $badge['meta'], ( ! $newsletter && ! empty( $_POST[ $key ] ) ) ? 1 : 0 );
		}

		if ( ! tp_cn_ring( $id ) ) {
			// 주문은 저장됐으니 다시 쓸 필요는 없다. 목록의 "셰프 다시 부르기"로 이어서 할 수 있게 알려 준다
			$fail( '주문은 받았는데 셰프를 깨우지 못했어요. ' . get_post_meta( $id, '_tp_cn_bell_err', true ) . ' — 주문 현황에서 "셰프 다시 부르기"를 눌러 주세요' );
		}
		wp_safe_redirect( add_query_arg( 'tp_cn_ok', $id, $back ) );
		exit;
	}
);

// 저장된 영상 카드 파일 목록. 발행 뒤 지운 주문은 빈 값('' 또는 빈 배열)이라 배열인 것만 센다
function tp_cn_file_list( $id ) {
	$files = get_post_meta( $id, '_tp_cn_files', true );
	$out   = array();
	foreach ( is_array( $files ) ? $files : array() as $no => $f ) {
		$out[ (string) $no ] = array(
			'name' => $f['name'],
			'kind' => $f['kind'],
			'url'  => rest_url( "tp-cardnews/v1/orders/{$id}/files/{$no}" ),
		);
	}
	return $out;
}

// 인터뷰 대상: 이름·인스타 주소·사진 받는 주소(관리자 인증 필요, 발행 뒤엔 사진이 지워져 null)
function tp_cn_people_list( $id ) {
	$people = get_post_meta( $id, '_tp_cn_people', true );
	$out    = array();
	foreach ( is_array( $people ) ? $people : array() as $i => $p ) {
		$out[] = array(
			'name'  => $p['name'],
			'insta' => $p['insta'],
			'photo' => ! empty( $p['file'] ) ? rest_url( "tp-cardnews/v1/orders/{$id}/people/{$i}" ) : null,
		);
	}
	return $out;
}

/**
 * 주문 하나를 화면·REST에서 같이 쓰는 모양으로.
 */
function tp_cn_order( $post, $with_state = false ) {
	$id      = $post->ID;
	$draft   = (int) get_post_meta( $id, '_tp_cn_post', true );
	$changes = get_post_meta( $id, '_tp_cn_changes', true );
	$out     = array(
		'id'      => $id,
		'group'   => $post->post_title,
		'created' => get_post_time( 'c', true, $post ),
		'status'  => get_post_meta( $id, '_tp_cn_status', true ) ?: 'new',
		'caption' => get_post_meta( $id, '_tp_cn_caption', true ),
		'videos'  => (object) ( get_post_meta( $id, '_tp_cn_videos', true ) ?: array() ),
		// 영상 카드 파일: 카드 번호 → 원래 파일 이름·종류(video|image)·받는 주소(관리자 인증 필요)
		'files'   => (object) tp_cn_file_list( $id ),
		'memo'    => get_post_meta( $id, '_tp_cn_memo', true ),
		// 인터뷰 폼(1.8.0): 1.8.0 전 주문은 값이 없어서 카드뉴스로 본다
		'kind'    => get_post_meta( $id, '_tp_cn_kind', true ) ?: 'cardnews',
		'layout'  => get_post_meta( $id, '_tp_cn_layout', true ),
		'people'  => tp_cn_people_list( $id ),
		// 뉴스레터 폼(1.20.0): 이번 주 소개할 제보 주소들, 셰프가 만든 뉴스레터가 있는지(본문은 무거워서 목록·REST엔 안 싣는다)
		'reports' => get_post_meta( $id, '_tp_cn_reports', true ) ?: array(),
		'has_newsletter' => (bool) get_post_meta( $id, '_tp_cn_newsletter', true ),
		'saved'   => (bool) get_post_meta( $id, '_tp_cn_saved', true ),
		'liked'   => (bool) get_post_meta( $id, '_tp_cn_liked', true ),
		'zip'     => rest_url( "tp-cardnews/v1/orders/{$id}/zip" ),
		'post_id' => $draft ?: null,
		// 초안이 발행됐는지(탭에 발행 버튼 대신 '글 보기'를 보이려고). 지워진 초안이면 빈 값
		'post_status' => $draft ? (string) get_post_status( $draft ) : '',
		'post_date'   => $draft ? (string) get_post_field( 'post_date', $draft ) : '', // 사이트 시각 그대로(예약 시각 표시용)
		'title'   => get_post_meta( $id, '_tp_cn_title', true ),
		'changes' => is_array( $changes ) ? $changes : array(),
		'error'   => get_post_meta( $id, '_tp_cn_error', true ),
		// 요리가 끝난(완성·멈춤) 시각. 메뉴 배지와 "방금 완성" 표시가 이걸로 "아직 안 본 결과"를 센다
		'finished' => (int) max( (int) get_post_meta( $id, '_tp_cn_done_at', true ), (int) get_post_meta( $id, '_tp_cn_failed_at', true ), (int) get_post_meta( $id, '_tp_cn_question_at', true ) ),
		// 초인종 기록: "셰프 다시 부르기" 버튼을 언제 보여 줄지 정하는 데 쓴다
		'rang_at'  => (int) get_post_meta( $id, '_tp_cn_rang_at', true ),
		'bell_err' => get_post_meta( $id, '_tp_cn_bell_err', true ),
		'started'  => (int) get_post_meta( $id, '_tp_cn_working_at', true ),
		'has_zip'  => (bool) get_post_meta( $id, '_tp_cn_zip', true ),
		'has_state' => (bool) get_post_meta( $id, '_tp_cn_state', true ),
		// 수정 요청: 지금 들어온 요청, 지난 수정들(요청 + 셰프가 손본 것), 셰프가 이어받을 작업 기록(파일 이름 → 내용)
		'feedback' => get_post_meta( $id, '_tp_cn_feedback', true ),
		'question' => get_post_meta( $id, '_tp_cn_question', true ),
		'answer'   => get_post_meta( $id, '_tp_cn_answer', true ),
		'rounds'   => get_post_meta( $id, '_tp_cn_rounds', true ) ?: array(),
	);
	// 작업 기록은 수십 KB라 셰프가 주문을 가져갈 때(상태를 골라 물을 때)만 싣는다 — 탭이 20초마다 묻는 목록엔 빼서 가볍게
	if ( $with_state ) {
		$out['state'] = (object) ( json_decode( (string) get_post_meta( $id, '_tp_cn_state', true ), true ) ?: array() );
	}
	return $out;
}

function tp_cn_orders( $status = null, $limit = 30 ) {
	$args = array(
		'post_type'      => TP_CN_TYPE,
		'post_status'    => 'private',
		'posts_per_page' => $limit,
		'orderby'        => 'date',
		'order'          => 'DESC',
	);
	if ( $status ) {
		$args['meta_key']   = '_tp_cn_status';
		$args['meta_value'] = $status;
		$args['order']      = 'ASC'; // 가져가는 쪽은 먼저 들어온 주문부터
	}
	$with_state = (bool) $status;
	return array_map(
		function ( $p ) use ( $with_state ) {
			return tp_cn_order( $p, $with_state );
		},
		get_posts( $args )
	);
}

// ── REST: 사이트 밖 주방이 주문을 가져가고 결과를 적는 곳 ───────────

add_action(
	'rest_api_init',
	function () {
		$admin = function () {
			return current_user_can( 'manage_options' ); // 애플리케이션 비밀번호로 들어온 관리자만
		};
		$find  = function ( $id ) {
			$post = get_post( (int) $id );
			return ( $post && TP_CN_TYPE === $post->post_type ) ? $post : null;
		};

		register_rest_route(
			'tp-cardnews/v1',
			'/orders',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) {
					$status = $req->get_param( 'status' );
					return tp_cn_orders( isset( TP_CN_STATUS[ $status ] ) ? $status : null, 50 );
				},
			)
		);

		// 뉴스레터 푸터의 발신자 정보(이름·연락처·주소). 광고성 메일이라 꼭 들어가야 하는데,
		// 스티비는 HTML 편집기 메일엔 주소록 푸터를 안 붙이고(10/20 테스트 메일) 저장소는 공개라 코드에 적을 수 없어서 사이트에 둔다
		register_rest_route(
			'tp-cardnews/v1',
			'/sender',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => $admin,
					'callback'            => function () {
						return array( 'lines' => get_option( 'tp_cn_sender', array() ) );
					},
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => $admin,
					'callback'            => function ( $req ) {
						$lines = array_values( array_filter( array_map( 'sanitize_text_field', (array) $req->get_param( 'lines' ) ) ) );
						update_option( 'tp_cn_sender', $lines, false ); // autoload 끔: 메일 조립할 때만 읽는다
						return array( 'lines' => $lines );
					},
				),
			)
		);

		register_rest_route(
			'tp-cardnews/v1',
			'/orders/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) use ( $find ) {
					$post = $find( $req['id'] );
					if ( ! $post ) {
						return new WP_Error( 'tp_cn_none', '없는 주문이에요', array( 'status' => 404 ) );
					}
					$id = $post->ID;
					if ( null !== $req->get_param( 'status' ) ) {
						if ( ! isset( TP_CN_STATUS[ $req['status'] ] ) ) {
							return new WP_Error( 'tp_cn_status', '상태는 new·revise·working·done·failed·question·answered 중 하나예요', array( 'status' => 400 ) );
						}
						update_post_meta( $id, '_tp_cn_status', $req['status'] );
						update_post_meta( $id, '_tp_cn_' . $req['status'] . '_at', time() );
						// 수정 요청을 끝냈으면 그 요청과 손본 것을 지난 수정 목록에 쌓고 요청 칸을 비운다
						$feedback = get_post_meta( $id, '_tp_cn_feedback', true );
						if ( 'done' === $req['status'] && $feedback ) {
							$rounds   = get_post_meta( $id, '_tp_cn_rounds', true ) ?: array();
							$rounds[] = array(
								'feedback' => $feedback,
								'changes'  => is_array( $req->get_param( 'changes' ) ) ? array_values( array_map( 'sanitize_text_field', $req['changes'] ) ) : array(),
								'at'       => time(),
							);
							update_post_meta( $id, '_tp_cn_rounds', $rounds );
							delete_post_meta( $id, '_tp_cn_feedback' );
							$revised = true;
						}
					}
					// 셰프의 작업 기록: 다음 수정 때 빈 컴퓨터에서 이어받는다. 글 HTML까지 수십 KB라 메타 하나에 JSON으로
					if ( is_array( $req->get_param( 'state' ) ) ) {
						update_post_meta( $id, '_tp_cn_state', wp_slash( wp_json_encode( $req['state'], JSON_UNESCAPED_UNICODE ) ) );
					}
					if ( null !== $req->get_param( 'post_id' ) ) {
						update_post_meta( $id, '_tp_cn_post', (int) $req['post_id'] );
					}
					// 셰프가 초안을 만들거나 고친 뒤엔 태그가 order.json 것으로 덮여 있다 → 뱃지 표시를 다시 맞춘다
					tp_cn_reapply_badges( $id );
					if ( null !== $req->get_param( 'title' ) ) {
						update_post_meta( $id, '_tp_cn_title', sanitize_text_field( $req['title'] ) );
					}
					// 처음 요리 때 손본 것만 여기에. 수정 때 손본 것은 위에서 그 회차 기록에 들어갔다
					if ( is_array( $req->get_param( 'changes' ) ) && empty( $revised ) ) {
						update_post_meta( $id, '_tp_cn_changes', array_values( array_map( 'sanitize_text_field', $req['changes'] ) ) );
					}
					// 뉴스레터 HTML(스티비에 붙여 넣을 것). 관리자 인증으로만 들어오고, 탭에선 스크립트를 막은 iframe 안에서만 보여 줘서 손대지 않고 그대로 둔다
					if ( is_string( $req->get_param( 'newsletter' ) ) && strlen( $req['newsletter'] ) < 2 * MB_IN_BYTES ) {
						update_post_meta( $id, '_tp_cn_newsletter', wp_slash( $req['newsletter'] ) );
					}
					if ( null !== $req->get_param( 'error' ) ) {
						update_post_meta( $id, '_tp_cn_error', sanitize_text_field( $req['error'] ) );
					}
					if ( null !== $req->get_param( 'question' ) ) {
						update_post_meta( $id, '_tp_cn_question', sanitize_textarea_field( $req['question'] ) );
						delete_post_meta( $id, '_tp_cn_answer' );
					}
					// 질문에 답을 받아 끝까지 만들었으면 질문·답은 비운다(셰프가 손본 것 목록에 남긴다)
					if ( 'done' === $req->get_param( 'status' ) ) {
						delete_post_meta( $id, '_tp_cn_question' );
						delete_post_meta( $id, '_tp_cn_answer' );
					}
					return tp_cn_order( get_post( $id ) );
				},
			)
		);

		// zip은 공개 주소로 열어 두지 않고, 관리자 인증을 거쳐 여기서 내려준다
		register_rest_route(
			'tp-cardnews/v1',
			'/orders/(?P<id>\d+)/zip',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) use ( $find ) {
					$post = $find( $req['id'] );
					$path = $post ? tp_cn_dir() . '/' . get_post_meta( $post->ID, '_tp_cn_zip', true ) : '';
					if ( ! $post || ! is_file( $path ) ) {
						return new WP_Error( 'tp_cn_none', 'zip이 없어요', array( 'status' => 404 ) );
					}
					header( 'Content-Type: application/zip' );
					header( 'Content-Length: ' . filesize( $path ) );
					readfile( $path );
					exit;
				},
			)
		);

		// 영상 카드 파일도 zip처럼 관리자 인증을 거쳐서만 내려준다
		register_rest_route(
			'tp-cardnews/v1',
			'/orders/(?P<id>\d+)/files/(?P<no>\d+)',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) use ( $find ) {
					$post  = $find( $req['id'] );
					$files = $post ? get_post_meta( $post->ID, '_tp_cn_files', true ) : '';
					$f     = is_array( $files ) ? ( $files[ (string) (int) $req['no'] ] ?? null ) : null;
					$path  = $f ? tp_cn_dir() . '/' . $f['file'] : '';
					if ( ! $f || ! is_file( $path ) ) {
						return new WP_Error( 'tp_cn_none', '파일이 없어요', array( 'status' => 404 ) );
					}
					header( 'Content-Type: application/octet-stream' );
					header( 'Content-Length: ' . filesize( $path ) );
					readfile( $path );
					exit;
				},
			)
		);

		// 인터뷰 대상 사진도 같은 방식으로 (번호 = 대상 줄 순서, 0부터)
		register_rest_route(
			'tp-cardnews/v1',
			'/orders/(?P<id>\d+)/people/(?P<no>\d+)',
			array(
				'methods'             => 'GET',
				'permission_callback' => $admin,
				'callback'            => function ( $req ) use ( $find ) {
					$post   = $find( $req['id'] );
					$people = $post ? get_post_meta( $post->ID, '_tp_cn_people', true ) : '';
					$p      = is_array( $people ) ? ( $people[ (int) $req['no'] ] ?? null ) : null;
					$path   = ! empty( $p['file'] ) ? tp_cn_dir() . '/' . $p['file'] : '';
					if ( ! $path || ! is_file( $path ) ) {
						return new WP_Error( 'tp_cn_none', '사진이 없어요', array( 'status' => 404 ) );
					}
					header( 'Content-Type: application/octet-stream' );
					header( 'Content-Length: ' . filesize( $path ) );
					readfile( $path );
					exit;
				},
			)
		);
	}
);

// ── 탭 화면 ──────────────────────────────────────────────

/*
 * 알림 B(10/17 사용자 결정 A+B): wp-admin 어느 화면에서든 메뉴에 "아직 안 본 결과" 수를 배지로 (업데이트 수가 뜨는 것과 같은 모양).
 * "봤다" = 사람마다 도우미 탭을 마지막으로 연 시각(사용자 메타). 탭을 여는 순간 배지가 사라지고,
 * 그 전 시각은 남겨 두었다가 그 뒤에 끝난 주문에 "방금 완성" 표시를 붙인다.
 */
add_action(
	'admin_menu',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$uid  = get_current_user_id();
		$seen = (int) get_user_meta( $uid, '_tp_cn_seen', true );
		$on   = isset( $_GET['page'] ) && TP_CN_SLUG === $_GET['page'];
		$GLOBALS['tp_cn_prev_seen'] = $seen;
		if ( $on ) {
			update_user_meta( $uid, '_tp_cn_seen', time() );
		}
		$unseen = $on ? 0 : count(
			array_filter(
				tp_cn_orders(),
				function ( $o ) use ( $seen ) {
					return $o['finished'] > $seen;
				}
			)
		);
		$title = '트란시스 카드뉴스 도우미' . ( $unseen ? sprintf( ' <span class="awaiting-mod count-%1$d"><span class="pending-count">%1$d</span></span>', $unseen ) : '' );
		add_menu_page( '트란시스 카드뉴스 도우미', $title, 'manage_options', TP_CN_SLUG, 'tp_cn_page', 'dashicons-pets', 3 );
	}
);

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'toplevel_page_' . TP_CN_SLUG !== $hook ) {
			return;
		}
		// 일정표와 같은 글꼴(둘 다 SIL OFL 1.1 — 10/17 라이선스 원문 확인)
		wp_enqueue_style( 'tp-cn-fonts', 'https://fonts.googleapis.com/css2?family=Jua&family=IBM+Plex+Sans+KR:wght@400;500;700&display=swap', array(), null );
	}
);

function tp_cn_page() {
	$msg = array();
	if ( isset( $_GET['tp_cn_err'] ) ) {
		$msg = array( 'bad', sanitize_text_field( wp_unslash( $_GET['tp_cn_err'] ) ) );
	} elseif ( isset( $_GET['tp_cn_info'] ) ) {
		$info = sanitize_text_field( wp_unslash( $_GET['tp_cn_info'] ) );
		$msg  = array( 'ok', 'bell' === $info ? '초인종 설정을 저장했어요. 다음 주문부터 셰프가 바로 와요.' : $info );
	} elseif ( isset( $_GET['tp_cn_ok'] ) && 'new' === get_post_meta( (int) $_GET['tp_cn_ok'], '_tp_cn_status', true ) ) {
		// 아직 접수 상태일 때만. 요리가 시작·끝난 뒤엔 목록이 상태를 말해 주니 "곧 시작해요"가 남아 있으면 헷갈린다
		$msg = array( 'ok', '주문 받았어요! 셰프 트란시스가 곧 요리를 시작해요.' );
	} elseif ( isset( $_GET['tp_cn_rev'] ) && in_array( get_post_meta( (int) $_GET['tp_cn_rev'], '_tp_cn_status', true ), array( 'revise', 'new' ), true ) ) {
		$msg = array( 'ok', '요청 받았어요! 셰프 트란시스가 다시 요리해 둘게요.' );
	}
	// 지난 주문 더 보기(1.25.0, 10/20 사용자): 처음엔 최근 30개만 그리고, 누를 때마다 30개씩 더.
	// 숫자만 키우지 않은 이유: 뉴스레터 주문은 메일 HTML을 통째로 품고 있어서 주문이 쌓일수록 탭을 열 때마다 무거워진다.
	// 하나 더 읽어 보고 남는 게 있을 때만 버튼을 단다. 300개에서 멈춘다(그 이상은 지울 때가 된 것)
	$show   = min( 300, max( TP_CN_PAGE, (int) ( $_GET['show'] ?? TP_CN_PAGE ) ) );
	$orders = tp_cn_orders( null, $show + 1 );
	$more   = count( $orders ) > $show && $show < 300;
	tp_cn_render(
		array_slice( $orders, 0, $show ),
		$msg,
		array(
			'show'   => $show,
			// 새로 펼친 첫 주문으로 바로 내려가게 그 자리에 책갈피(#tpcn-next)를 단다
			'more'   => $more ? admin_url( 'admin.php?page=' . TP_CN_SLUG . '&show=' . ( $show + TP_CN_PAGE ) . '#tpcn-next' ) : '',
			'face'   => plugins_url( 'mascot.jpg', __FILE__ ),
			'rest'   => plugins_url( 'mascot-rest.png', __FILE__ ),
			'pcap'   => plugins_url( 'profile-capture.mp4', __FILE__ ),
			// 피그마 플러그인(plugins/figma-cardnews-assistant)을 묶은 zip. 플러그인을 고치면 이 zip도 다시 묶는다
			'fplug'  => plugins_url( 'transis-figma-plugin.zip', __FILE__ ),
			// 맞춤법 검사 비서 zip. 코드는 비공개 저장소가 정본이라 이 zip은 gitignore이고 사이트에만 올린다 → 파일이 없는 곳(저장소만 받아 설치한 경우)에선 버튼을 숨긴다
			'splug'  => file_exists( plugin_dir_path( __FILE__ ) . 'transis-spellcheck-plugin.zip' ) ? plugins_url( 'transis-spellcheck-plugin.zip', __FILE__ ) : '',
			'action' => admin_url( 'admin-post.php' ),
			'nonce'  => wp_nonce_field( 'tp_cn_order', '_wpnonce', true, false ),
			// 알림 A: 탭이 스스로 상태를 확인할 때 쓰는 주소와 로그인 확인 값(쿠키 인증에는 wp_rest nonce가 필요)
			'poll'   => rest_url( 'tp-cardnews/v1/orders' ),
			'rnonce' => wp_create_nonce( 'wp_rest' ),
			'seen'   => isset( $GLOBALS['tp_cn_prev_seen'] ) ? (int) $GLOBALS['tp_cn_prev_seen'] : time(),
			'bell'   => get_option( TP_CN_BELL, array() ),
			// 트란시스 일정표 앱 주소: 저장소가 공개라 코드에 적지 않고 TP Transis Frame 설정값(숨은 주소)에서 읽는다. 관리자만 보는 탭이다
			'tapp'   => tp_cn_transis_app_url(),
			'now'    => time(),
			// 한 번 보낼 수 있는 크기(서버 upload_max_filesize·post_max_size 중 작은 값). 탭이 미리 막고 안내한다
			'max'    => wp_max_upload_size(),
		)
	);
}

/**
 * 이 주문에 "셰프 다시 부르기"가 필요한지와 그 이유. 필요 없으면 null.
 * 기다리는 시간: 초인종 뒤 셰프가 주문을 가져가기까지 보통 1~2분, 요리는 10분 안팎(711 실측 전 추정)이라 넉넉히.
 */
function tp_cn_recall_reason( $o, $now ) {
	$waiting = in_array( $o['status'], array( 'new', 'revise', 'answered' ), true );
	if ( $waiting && $o['bell_err'] ) {
		return $o['bell_err'];
	}
	if ( $waiting && $o['rang_at'] && $now - $o['rang_at'] > 15 * MINUTE_IN_SECONDS ) {
		return '초인종을 눌렀는데 15분이 지나도 셰프가 주문을 가져가지 않았어요.';
	}
	if ( 'working' === $o['status'] && $o['started'] && $now - $o['started'] > 45 * MINUTE_IN_SECONDS ) {
		return '요리가 45분 넘게 끝나지 않아요. 셰프가 중간에 멈췄을 수 있어요.';
	}
	if ( 'failed' === $o['status'] && ( $o['has_zip'] || $o['feedback'] ) ) {
		return ''; // 멈춘 이유는 이미 위에 나온다 — 버튼만
	}
	return null;
}

/**
 * 화면 그리기. 주문 목록·알림·주소를 넘겨받기만 해서, 워드프레스 없이도 가짜 주문으로 그려 볼 수 있다(시안·검증용).
 */
function tp_cn_render( $orders, $msg, $u ) {
	$fmt = function ( $iso ) {
		return $iso ? wp_date( 'n월 j일 H:i', strtotime( $iso ) ) : '';
	};
	?>
<div class="tpcn" id="tpcn" data-poll="<?php echo esc_url( $u['poll'] ); ?>" data-nonce="<?php echo esc_attr( $u['rnonce'] ); ?>">
<style>
/* 셰프 트란시스의 주방(10/17 사용자: "요리사 컨셉, 빵모자, 테마·배경도"). 둥근 패널·파스텔 칩·Jua 제목은 일정표와 같은 말투,
   색은 주방 쪽으로: 크림 바탕, 갈색 글자, 상태 = 주문서 파랑 · 버터(요리 중) · 바질(완성) · 토마토(멈춤) */
body.toplevel_page_tp-cardnews #wpcontent, body.toplevel_page_tp-cardnews #wpfooter { background: #fbf4e6; }
.tpcn { --bg: #fdf8ee; --card: #fffdf8; --ink: #3b2f2a; --muted: #8c7f73; --line: #efe3cf; --line-strong: #dcc9ab;
  --new: #3a86ff; --new-soft: #dde9ff; --revise: #7a5af8; --revise-soft: #ebe5ff; --working: #d08c12; --working-soft: #fbedc9;
  --done: #2f9e6b; --done-soft: #d9f1e3; --failed: #e4572e; --failed-soft: #fde3da; --fresh: #b8572e; --fresh-soft: #fbe6da;
  --tomato: #e4572e;
  --font-display: "Jua", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif;
  --font-body: "IBM Plex Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", system-ui, sans-serif;
  max-width: 980px; margin: 18px 20px 40px 0; display: grid; gap: 18px; color: var(--ink); font-family: var(--font-body); font-size: 14px; line-height: 1.55; word-break: keep-all; }
.tpcn * { box-sizing: border-box; }
.tpcn [hidden] { display: none !important; }
/* 맨 위 행주 띠: 토마토색 깅엄 체크 */
.tpcn-towel { height: 12px; border-radius: 999px; opacity: .85;
  background: repeating-linear-gradient(90deg, rgba(228, 87, 46, .55) 0 12px, transparent 12px 24px), repeating-linear-gradient(0deg, rgba(228, 87, 46, .55) 0 6px, #fff6ea 6px 12px); }
.tpcn-head { position: relative; display: flex; align-items: center; gap: 14px; padding-top: 18px; }
.tpcn-face { position: relative; flex: none; border: 0; padding: 0; background: none; border-radius: 50%; cursor: pointer; }
.tpcn-face img { display: block; width: 56px; height: 56px; border-radius: 50%; object-fit: cover; box-shadow: 0 0 0 3px var(--card), 0 4px 12px rgba(59, 47, 42, .18); }
.tpcn-face:focus-visible { outline: 2px solid var(--new); outline-offset: 2px; }
/* 셰프 모자: 사진은 그대로 두고 그림을 머리 위에 얹는다 */
.tpcn-hat { position: absolute; left: 6px; top: -30px; width: 46px; height: auto; transform: rotate(-10deg); pointer-events: none; filter: drop-shadow(0 2px 2px rgba(59, 47, 42, .15)); }
/* 오른쪽 위 반짝이: 눌러 볼 수 있다는 작은 신호(일정표와 같음) */
.tpcn-spark { position: absolute; top: 0; right: -10px; font-size: 16px; line-height: 1; pointer-events: none; }
.tpcn-head h1 { margin: 0; padding: 0; font-family: var(--font-display); font-weight: 400; font-size: 27px; line-height: 1.15; color: var(--ink); }
.tpcn-head p { margin: 2px 0 0; color: var(--muted); font-size: 13px; }
/* 얼굴을 누르면 쓰는 법이 말풍선으로 */
.tpcn-bubble { position: absolute; z-index: 5; top: 86px; left: 0; width: min(380px, 100%); margin: 0; padding: 12px 14px; border-radius: 14px; border: 1px solid var(--line); background: var(--card); font-size: 13px; box-shadow: 0 8px 24px rgba(20, 22, 40, .18); }
.tpcn-bubble::before { content: ""; position: absolute; top: -7px; left: 20px; width: 12px; height: 12px; background: var(--card); border: solid var(--line); border-width: 1px 0 0 1px; transform: rotate(45deg); border-radius: 2px; }
.tpcn-bubble ol { margin: 0; padding-left: 18px; }
.tpcn-bubble li { margin: 2px 0; }
@media (prefers-reduced-motion: no-preference) {
  .tpcn-spark { animation: tpcn-twinkle 2.4s ease-in-out infinite; }
  .tpcn-face.wag { animation: tpcn-wag .5s ease; }
  @keyframes tpcn-twinkle { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: .35; transform: scale(.75); } }
  @keyframes tpcn-wag { 25% { transform: rotate(-10deg); } 75% { transform: rotate(10deg); } }
}
.tpcn-msg { margin: 0; padding: 12px 16px; border-radius: 14px; font-weight: 700; }
.tpcn-msg.ok { background: var(--done-soft); color: #13784f; }
.tpcn-msg.bad { background: var(--failed-soft); color: #b42333; }
.tpcn-panel { background: var(--card); border-radius: 22px; padding: 18px; border: 1px solid var(--line); box-shadow: 0 1px 2px rgba(59, 47, 42, .04), 0 8px 24px rgba(59, 47, 42, .06); min-width: 0; }
.tpcn-panel h2 { margin: 0 0 14px; font-family: var(--font-display); font-weight: 400; font-size: 20px; display: flex; align-items: baseline; gap: 8px; color: var(--ink); }
.tpcn-panel h2 small { font-family: var(--font-body); font-size: 12px; color: var(--muted); font-weight: 500; }
.tpcn-form { display: grid; gap: 14px; }
.tpcn-field label { display: block; margin-bottom: 6px; font-weight: 700; }
.tpcn-field label em { margin-left: 4px; font-style: normal; font-weight: 500; font-size: 12px; color: var(--muted); }
/* 필수 칸: 노란 형광펜을 아래쪽 절반에만 칠한 것처럼 (10/17 사용자) */
.tpcn-field label em.tpcn-must { padding: 0 3px; font-weight: 700; color: var(--ink); background: linear-gradient(transparent 45%, #ffe45c 45%, #ffe45c 92%, transparent 92%); }
.tpcn-field .tpcn-hint { margin: 6px 0 0; font-size: 12px; color: var(--muted); }
.tpcn-field .tpcn-hint b { color: var(--ink); }
.tpcn-how { margin-top: 6px; font-size: 12.5px; }
/* 10/18 사용자: 접을 수 있다는 게 보여야 해서 글자 대신 알약 버튼 + 오른쪽에 '접기 ▴ / 펼치기 ▾' */
.tpcn-how summary { display: inline-flex; align-items: center; gap: 8px; padding: 5px 12px; border-radius: 999px; background: var(--fresh-soft); color: var(--fresh); font-weight: 700; cursor: pointer; list-style: none; user-select: none; }
.tpcn-how summary::-webkit-details-marker { display: none; }
.tpcn-how summary::after { content: "펼치기 ▾"; padding-left: 8px; border-left: 1px solid currentColor; font-size: 11.5px; font-weight: 500; }
.tpcn-how[open] summary::after { content: "접기 ▴"; }
.tpcn-how summary:hover { background: #f7d5c4; }
.tpcn-how summary:focus-visible { outline: 2px solid var(--fresh); outline-offset: 2px; }
.tpcn-how ul { margin: 8px 0 0; padding: 10px 14px 10px 28px; border-radius: 12px; background: var(--bg); border: 1px dashed var(--line-strong); }
.tpcn-how li { margin: 3px 0; }
.tpcn-plug { margin-top: 8px; padding: 10px 14px; border-radius: 12px; background: var(--bg); border: 1px dashed var(--line-strong); }
.tpcn-plug ol { margin: 8px 0 0; padding-left: 18px; }
.tpcn-plug li { margin: 3px 0; }
.tpcn-plug .tpcn-plug-update { margin: 10px 0 0; padding-top: 8px; border-top: 1px dashed var(--line-strong); font-size: 12.5px; line-height: 1.6; }
.tpcn-dl { display: inline-block; padding: 6px 14px; border-radius: 999px; background: var(--ink); color: #fff; font-weight: 700; text-decoration: none; }
.tpcn-dl:hover, .tpcn-dl:focus { color: #fff; background: #5a4a42; }
/* 받기 버튼이 둘 이상이면 위아래로 간격을 두고 폭을 같게 맞춘다(안 하면 폭이 들쭉날쭉하고 서로 붙어 보인다) */
.tpcn-dls { display: grid; gap: 8px; }
.tpcn-dls .tpcn-dl { text-align: center; }
.tpcn-cap { display: flex; gap: 14px; align-items: center; margin-top: 10px; padding: 10px; border-radius: 12px; background: var(--bg); border: 1px dashed var(--line-strong); font-size: 12.5px; }
.tpcn-capvid { flex: none; width: 150px; height: 150px; border-radius: 10px; background: #0d1014; }
.tpcn-cap ol { margin: 4px 0 0; padding-left: 18px; }
.tpcn-cap li { margin: 2px 0; }
.tpcn-cap code { padding: 1px 6px; border-radius: 6px; background: var(--card); border: 1px solid var(--line); font-size: 12px; }
.tpcn-how code { padding: 1px 6px; border-radius: 6px; background: var(--card); border: 1px solid var(--line); font-size: 12px; }
.tpcn textarea { width: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font: inherit; color: var(--ink); resize: vertical; }
.tpcn textarea:focus { border-color: var(--new); outline: none; box-shadow: 0 0 0 3px var(--new-soft); }
/* zip 넣는 칸: 점선 상자. 고르면 파일 이름이 상자 안에 뜬다 */
.tpcn-drop { position: relative; display: flex; align-items: center; gap: 12px; padding: 16px; border: 2px dashed var(--line-strong); border-radius: 16px; background: var(--bg); cursor: pointer; }
.tpcn-drop:hover, .tpcn-drop.is-over { border-color: var(--new); background: var(--new-soft); }
.tpcn-drop.has-file { border-style: solid; border-color: var(--done); background: var(--done-soft); }
.tpcn-drop input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
.tpcn-drop .tpcn-ico { flex: none; width: 40px; height: 40px; border-radius: 12px; display: grid; place-items: center; background: var(--card); font-size: 20px; }
.tpcn-drop b { display: block; font-size: 14px; }
.tpcn-drop span { font-size: 12px; color: var(--muted); }
/* 영상 카드 줄: 카드 번호 · 파일 · 주소 · 지우기 */
.tpcn-vrows { display: grid; gap: 8px; }
.tpcn-vrow { display: grid; grid-template-columns: 72px minmax(0, 200px) minmax(0, 1fr) 32px; gap: 8px; align-items: center; }
.tpcn-vrow input[type=number], .tpcn-vrow input[type=url] { width: 100%; padding: 8px 10px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font: inherit; color: var(--ink); }
.tpcn-vrow input:focus { border-color: var(--new); outline: none; box-shadow: 0 0 0 3px var(--new-soft); }
.tpcn-vfile { position: relative; display: block; padding: 8px 10px; border: 1.5px dashed var(--line-strong); border-radius: 12px; background: var(--bg); font-size: 12.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer; }
.tpcn-vfile.has-file { border-style: solid; border-color: var(--done); background: var(--done-soft); }
.tpcn-vfile input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
.tpcn-vdel { width: 32px; height: 32px; border: 0; border-radius: 50%; background: none; color: var(--muted); font-size: 18px; cursor: pointer; }
.tpcn-vdel:hover { background: var(--failed-soft); color: var(--failed); }
.tpcn-vadd { margin-top: 8px; padding: 4px 12px; border: 1.5px solid var(--line); border-radius: 999px; background: var(--card); color: var(--ink); font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; }
/* 주문 종류 전환: 알약 두 개 중 하나가 토마토색으로 */
.tpcn-kind { display: inline-flex; justify-self: start; gap: 4px; padding: 4px; border-radius: 999px; background: var(--bg); border: 1.5px solid var(--line); }
.tpcn-kind input, .tpcn-layouts input { position: absolute; opacity: 0; pointer-events: none; }
.tpcn-kind span { display: block; padding: 7px 18px; border-radius: 999px; font-weight: 700; cursor: pointer; }
.tpcn-kind input:checked + span { background: var(--tomato); color: #fff; }
.tpcn-kind input:focus-visible + span, .tpcn-layouts input:focus-visible + span { box-shadow: 0 0 0 3px var(--new-soft); }
/* 영상 가이드: 종류 탭과 한 줄. 자리가 모자라면 아래 줄로 내려간다(flex-wrap) */
.tpcn-toprow { display: flex; flex-wrap: wrap; align-items: center; gap: 12px 20px; }
.tpcn-vg { display: grid; gap: 4px; min-width: 0; }
.tpcn-vg-t { font-size: 12px; color: var(--muted); font-weight: 700; }
.tpcn-vg-list { display: flex; flex-wrap: wrap; gap: 8px; }
.tpcn-vg-card { display: flex; align-items: center; gap: 8px; width: 216px; padding: 5px 10px 5px 5px; border-radius: 12px; background: var(--bg); border: 1.5px solid var(--line); color: var(--ink); text-decoration: none; font-weight: 700; font-size: 12.5px; line-height: 1.35; }
.tpcn-vg-card:hover { border-color: var(--tomato); }
.tpcn-vg-card:focus-visible { outline: none; box-shadow: 0 0 0 3px var(--new-soft); }
.tpcn-vg-th { position: relative; flex: none; width: 96px; height: 54px; border-radius: 8px; overflow: hidden; background: var(--line); }
.tpcn-vg-th img { display: block; width: 100%; height: 100%; object-fit: cover; }
.tpcn-vg-th::after { content: "▶"; position: absolute; inset: 0; display: grid; place-items: center; color: #fff; font-size: 16px; text-shadow: 0 1px 4px rgba(0, 0, 0, .55); }
/* 인터뷰 칸: 형식 카드 두 장 + 대상 줄 */
.tpcn-iv { display: grid; gap: 16px; padding: 14px; border-radius: 16px; border: 1.5px dashed var(--line-strong); }
.tpcn-iv[hidden] { display: none; }
.tpcn-layouts { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.tpcn-layouts label { position: relative; margin: 0; font-weight: 500; }
.tpcn-layouts span { display: block; height: 100%; padding: 10px 12px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font-size: 12.5px; color: var(--muted); cursor: pointer; }
.tpcn-layouts span b { display: block; margin-bottom: 2px; font-size: 14px; color: var(--ink); }
.tpcn-layouts input:checked + span { border-color: var(--tomato); background: var(--card); box-shadow: 0 0 0 3px rgba(226, 88, 50, .15); }
.tpcn-prows { display: grid; gap: 8px; }
.tpcn-prow { display: grid; grid-template-columns: minmax(0, 140px) minmax(0, 1fr) minmax(0, 160px) 32px; gap: 8px; align-items: center; }
.tpcn-prow input[type=text], .tpcn-prow input[type=url] { width: 100%; padding: 8px 10px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font: inherit; color: var(--ink); }
.tpcn-prow input:focus { border-color: var(--new); outline: none; box-shadow: 0 0 0 3px var(--new-soft); }
.tpcn-tag { display: inline-block; margin-right: 6px; padding: 1px 8px; border-radius: 999px; background: var(--bg); border: 1px solid var(--line); font-size: 11px; font-weight: 700; vertical-align: 2px; }
.tpcn-tag.is-iv { background: #fde9e2; border-color: #f4b8a5; color: #a8401f; }
/* 광고 딱지 이름표는 is-ad를 쓰면 안 된다: 광고 차단기(EasyList ##.is-ad)가 숨겨 버린다(10/18 896 주문에서 딱지가 안 보임) */
.tpcn-tag.is-sponsor { background: #e6effd; border-color: #a9c4f2; color: #1f4fa8; }
.tpcn-tag.is-nl { background: #fff3e0; border-color: #f2c894; color: #9a5a00; }
.tpcn-nlbox { margin: 10px 0; }
.tpcn-nl-copy { padding: 8px 14px; border: 2px solid #3b2a20; border-radius: 10px; background: #fff; font-weight: 800; cursor: pointer; }
.tpcn-nl-note { margin-left: 8px; font-size: 12px; color: #7a6a5a; }
.tpcn-nl-frame { display: block; width: 100%; max-width: 640px; height: 900px; margin-top: 8px; border: 1px solid #ddd; border-radius: 10px; background: #ececec; }
.tpcn-go { justify-self: start; padding: 11px 22px; border: 0; border-radius: 999px; background: var(--tomato); color: #fff; font-family: var(--font-display); font-size: 17px; cursor: pointer; box-shadow: 0 4px 0 #b8401d; }
.tpcn-go:hover { background: #ec6a43; }
.tpcn-go:active { transform: translateY(2px); box-shadow: 0 2px 0 #b8401d; }
.tpcn-go:disabled { opacity: .5; cursor: wait; }
.tpcn-list { margin: 0; padding: 0; list-style: none; display: grid; gap: 10px; }
.tpcn-item { display: grid; grid-template-columns: 44px 1fr auto; gap: 4px 12px; align-items: start; padding: 12px; border: 1px solid var(--line); border-radius: 16px; }
.tpcn-no { min-width: 44px; height: 36px; padding: 0 6px; border-radius: 12px; display: grid; place-items: center; font-family: var(--font-display); font-size: 15px; color: #fff; background: var(--s); }
.tpcn-item h3 { margin: 0; font-size: 15px; font-weight: 700; color: var(--ink); }
.tpcn-item .tpcn-when { margin: 0; font-size: 12px; color: var(--muted); }
.tpcn-chip { display: inline-flex; align-items: center; gap: 5px; padding: 3px 10px; border-radius: 999px; font-size: 12.5px; font-weight: 700; white-space: nowrap; background: var(--s-soft); color: var(--s); }
.tpcn-chip::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
.tpcn-item.is-working .tpcn-chip::before { animation: tpcn-blink 1.2s ease-in-out infinite; }
/* 마지막으로 탭을 본 뒤에 끝난 주문: 테두리를 상태 색으로, 이름 옆에 작은 표 */
.tpcn-item.is-fresh { border-color: var(--s); box-shadow: 0 0 0 3px var(--s-soft); }
.tpcn-fresh { display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 999px; background: var(--s); color: #fff; font-size: 11px; font-weight: 700; vertical-align: 2px; }
.tpcn-live-btn { margin-left: 8px; padding: 3px 12px; border: 0; border-radius: 999px; background: var(--done); color: #fff; font: inherit; font-size: 12.5px; cursor: pointer; }
@keyframes tpcn-blink { 50% { opacity: .2; } }
.s-new { --s: var(--new); --s-soft: var(--new-soft); }
.s-revise { --s: var(--revise); --s-soft: var(--revise-soft); }
.s-working { --s: var(--working); --s-soft: var(--working-soft); }
/* 고쳐 주세요: 완성된 주문 아래 메모 칸 + 지난 수정 기록 */
.tpcn-revise { margin-top: 10px; display: grid; gap: 6px; }
.tpcn-revise textarea { font-size: 13px; }
.tpcn-revise button { justify-self: start; padding: 6px 16px; border: 0; border-radius: 999px; background: var(--revise); color: #fff; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; }
.tpcn-rounds { margin: 8px 0 0; padding: 0; list-style: none; display: grid; gap: 6px; }
.tpcn-rounds > li { padding: 8px 10px; border-radius: 10px; background: var(--bg); border: 1px dashed var(--line-strong); }
.tpcn-rounds b { color: var(--revise); }
.tpcn-rounds ul { margin: 4px 0 0; padding-left: 18px; color: var(--muted); }
.s-done { --s: var(--done); --s-soft: var(--done-soft); }
.s-question, .s-answered { --s: #d6336c; --s-soft: #fde2ec; }
.tpcn-q { padding: 8px 10px; border-radius: 10px; background: var(--s-soft); }
.tpcn-body .tpcn-memo { padding: 8px 10px; border-radius: 10px; background: var(--bg); border: 1px dashed var(--line-strong); color: var(--muted); }
.tpcn-answer button { background: #d6336c; }
.s-failed { --s: var(--failed); --s-soft: var(--failed-soft); }
.tpcn-body { grid-column: 2 / -1; font-size: 13px; }
.tpcn-body p { margin: 4px 0 0; }
.tpcn-body .tpcn-title { font-weight: 700; }
.tpcn-links { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.tpcn-links a { display: inline-block; padding: 5px 12px; border-radius: 999px; border: 1.5px solid var(--line); color: var(--ink); text-decoration: none; font-weight: 700; font-size: 12.5px; }
.tpcn-links a.main { background: var(--ink); border-color: var(--ink); color: #fff; }
.tpcn-links a:hover { border-color: var(--muted); }
/* 발행된 주문: 버터색 카드(10/18 사용자, 시안 1018-1 P3). 번호 상자·딱지도 같은 색, 글 보기 버튼은 흰 바탕 */
.tpcn-item.is-pub { --s: #d08c12; --s-soft: #fbedc9; background: linear-gradient(135deg, #fff1d6, #fff8ea); border-color: #f2d394; }
.tpcn-chip.is-pub { background: #c27c0e; color: #fff; }
.tpcn-item.is-pub .tpcn-links a.main { background: #fff; color: var(--ink); border-color: var(--ink); }
/* 셰프가 손본 것의 중요도(시안 1018-1 C): 확인 항목은 늘 펼친 상자로, ❗는 분홍 띠 */
.tpcn-check { margin-top: 8px; padding: 10px 12px; border-radius: 12px; background: #fff3d6; border: 1.5px solid #f2cf7c; }
.tpcn-check > b { display: block; margin-bottom: 4px; }
.tpcn-check ul { margin: 0; padding: 0; list-style: none; display: grid; gap: 4px; }
.tpcn-check li { padding: 0 8px; }
.tpcn-check li.lv3 { padding: 4px 8px; border-radius: 8px; background: #ffdbe4; color: #9b1c3d; font-weight: 700; }
.tpcn-changes li.lv2, .tpcn-changes li.lv3 { color: var(--ink); font-weight: 700; }
.tpcn-publish { margin: 0; }
.tpcn-publish button { padding: 5px 14px; border: 0; border-radius: 999px; background: var(--tomato); color: #fff; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; box-shadow: 0 2px 0 #b8401d; }
.tpcn-publish button:hover { background: #ec6a43; }
.tpcn-sched, .tpcn-unsched { margin: 0; display: inline-flex; gap: 6px; align-items: center; }
.tpcn-sched input { padding: 3px 10px; border: 1.5px solid var(--line); border-radius: 999px; font: inherit; font-size: 12.5px; background: #fff; }
.tpcn-sched button, .tpcn-unsched button { padding: 5px 14px; border: 0; border-radius: 999px; background: #4a6fa5; color: #fff; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; box-shadow: 0 2px 0 #34507a; }
.tpcn-unsched button { background: #fff; color: var(--ink); box-shadow: 0 2px 0 var(--line); }
.tpcn-sched-on { padding: 5px 12px; border-radius: 999px; background: #e8f0fb; color: #2d4a73; font-weight: 700; font-size: 12.5px; }
.tpcn-field label.tpcn-saved { display: flex; align-items: center; gap: 6px; margin: 0; cursor: pointer; }
.tpcn-saved-btn { margin: 0; }
.tpcn-more { display: block; margin: 14px auto 0; padding: 10px 16px; max-width: 260px; border: 2px solid var(--ink); border-radius: 999px; background: #fff; color: var(--ink); text-align: center; text-decoration: none; font-weight: 700; box-shadow: 3px 3px 0 var(--ink); }
.tpcn-more:hover { color: var(--ink); background: #fff7e6; }
.tpcn-saved-btn button { padding: 5px 12px; border: 1.5px solid var(--line); border-radius: 999px; background: #fff; color: var(--ink); font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; }
.tpcn-saved-btn.is-on button { background: #111; border-color: #111; color: #fff; }
.tpcn-body details { margin-top: 8px; }
.tpcn-body summary { cursor: pointer; color: var(--fresh); font-weight: 700; }
.tpcn-body details ul { margin: 6px 0 0; padding-left: 18px; }
.tpcn-recall { margin-top: 8px; }
.tpcn-recall p { margin: 0 0 6px; color: var(--muted); }
.tpcn-recall button { padding: 5px 14px; border: 0; border-radius: 999px; background: var(--tomato); color: #fff; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer; }
.tpcn-bell summary { cursor: pointer; font-family: var(--font-display); font-size: 18px; }
.tpcn-bell summary small { margin-left: 6px; font-family: var(--font-body); font-size: 12px; color: var(--muted); }
.tpcn-bell form { display: grid; gap: 12px; margin-top: 12px; }
/* 설치 안내 둘: 제목 줄 오른쪽 알약, 펼치면 오른쪽 끝에 맞춘 말풍선 */
.tpcn-guides { margin-left: auto; display: flex; gap: 8px; position: relative; }
.tpcn-guides .tpcn-how { margin: 0; }
.tpcn-guides .tpcn-how summary::after { content: "▾"; }
.tpcn-guides .tpcn-how[open] summary::after { content: "▴"; }
.tpcn-guides .tpcn-how > div { position: absolute; z-index: 6; right: 0; top: calc(100% + 8px); width: min(380px, calc(100vw - 40px)); margin: 0; padding: 12px 14px; border-radius: 14px; border: 1px solid var(--line); background: var(--card); box-shadow: 0 8px 24px rgba(20, 22, 40, .18); font-size: 13px; }
.tpcn-app-link { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin: 0; }
.tpcn-app .tpcn-hint { margin: 6px 0 0; font-size: 12px; color: var(--muted); }
.tpcn-app-steps { margin: 12px 0 0; padding-left: 18px; }
.tpcn-app-steps li { margin: 4px 0; }
.tpcn-bell input[type=url], .tpcn-bell input[type=password] { width: 100%; padding: 9px 12px; border: 1.5px solid var(--line); border-radius: 12px; background: var(--bg); font: inherit; }
/* 주문 지우기: 눈에 덜 띄게 오른쪽 아래 작은 글씨 */
.tpcn-del { margin-top: 8px; text-align: right; }
.tpcn-del button { padding: 0; border: 0; background: none; color: var(--muted); font: inherit; font-size: 12px; cursor: pointer; }
.tpcn-del button:hover { color: var(--failed); text-decoration: underline; }
.tpcn-empty { display: grid; justify-items: center; gap: 6px; padding: 18px 0 8px; color: var(--muted); text-align: center; }
.tpcn-empty img { width: 180px; height: auto; }
@media (max-width: 782px) {
  /* 좁은 화면: 알약은 제목 아래 줄로, 말풍선은 왼쪽 끝에 맞춘다 */
  .tpcn-head { flex-wrap: wrap; }
  .tpcn-guides { margin-left: 0; width: 100%; flex-wrap: wrap; }
  .tpcn-guides .tpcn-how > div { right: auto; left: 0; }
  .tpcn-cap { flex-direction: column; align-items: flex-start; }
  .tpcn { margin-right: 10px; }
  .tpcn-item { grid-template-columns: 44px 1fr; }
  .tpcn-item .tpcn-chip { grid-column: 2; justify-self: start; }
  /* 폰: 번호·파일·지우기 한 줄, 주소는 아래 줄 전체 */
  .tpcn-vrow { grid-template-columns: 64px minmax(0, 1fr) 32px; }
  .tpcn-vrow input[type=url] { grid-column: 1 / -1; grid-row: 2; }
  /* 폰: 이름·사진·지우기 한 줄, 인스타 주소는 아래 줄 전체. 형식 카드는 세로로 */
  .tpcn-prow { grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 32px; }
  .tpcn-prow input[type=url] { grid-column: 1 / -1; grid-row: 2; }
  .tpcn-layouts { grid-template-columns: 1fr; }
}
/* ── 스티커 테마(10/18 사용자, 시안 1018-8 A): 땡땡이 바탕 + 굵은 갈색 테두리·블록 그림자 스티커 패널,
   10/18 사용자: 주문 카드도 그라데이션 없이 모두 A 모양으로.
   앞의 기본 모양 위에 덮어쓰는 묶음이라 .tpcn을 앞에 붙여 이긴다(테마만 통째로 갈아 끼울 수 있게) ── */
body.toplevel_page_tp-cardnews #wpcontent { background: #fbf4e6 radial-gradient(#ecd3b0 1.3px, transparent 1.5px) 0 0 / 18px 18px; }
.tpcn .tpcn-towel { height: 16px; border: 2px solid var(--ink); }
.tpcn .tpcn-panel { border: 2.5px solid var(--ink); border-radius: 26px; box-shadow: 6px 6px 0 var(--ink); background: var(--card); }
.tpcn .tpcn-panel h2 { font-size: 25px; }
.tpcn .tpcn-panel:has(#tpcn-form) h2::before { content: "🧾"; margin-right: 2px; }
.tpcn .tpcn-panel:has(.tpcn-list) h2::before { content: "🍳"; margin-right: 2px; }
.tpcn .tpcn-kind { border: 2px solid var(--ink); box-shadow: 3px 3px 0 var(--ink); background: #fff; }
.tpcn .tpcn-kind input:checked + span { box-shadow: inset 0 -3px 0 rgba(0, 0, 0, .18); }
.tpcn .tpcn-vg-card { border: 2px solid var(--ink); background: #fff; box-shadow: 2px 2px 0 var(--ink); }
.tpcn .tpcn-drop { border: 2.5px dashed var(--ink); background: #fff8ec; }
.tpcn .tpcn-form textarea, .tpcn .tpcn-form input[type=text], .tpcn .tpcn-form input[type=url], .tpcn .tpcn-form input[type=number] { border: 2px solid var(--ink); border-radius: 14px; background: #fff; }
.tpcn .tpcn-go { border: 2.5px solid var(--ink); border-radius: 16px; box-shadow: 5px 5px 0 var(--ink); }
.tpcn .tpcn-go:active { transform: translate(3px, 3px); box-shadow: 2px 2px 0 var(--ink); }
.tpcn .tpcn-tag { border: 1.5px solid var(--ink); }
/* 주문 현황도 스티커: 흰 카드 + 갈색 테두리 + 상태 색 블록 그림자, 번호는 기울어진 동그라미 도장 */
.tpcn .tpcn-item { border: 2px solid var(--ink); border-radius: 20px; box-shadow: 4px 4px 0 var(--s); background: #fff; }
.tpcn .tpcn-item.is-pub { background: #fff3d6; border-color: var(--ink); }
.tpcn .tpcn-item.is-fresh { border-color: var(--ink); box-shadow: 4px 4px 0 var(--s), 0 0 0 4px var(--s-soft); }
.tpcn .tpcn-no { width: 48px; height: 48px; min-width: 48px; border-radius: 50%; border: 2px solid var(--ink); box-shadow: 2px 2px 0 var(--ink); transform: rotate(-8deg); font-size: 16px; }
.tpcn .tpcn-chip { border: 2px solid currentColor; padding: 2px 10px; }
.tpcn .tpcn-chip.is-pub { border-color: var(--ink); }
.tpcn .tpcn-links a, .tpcn .tpcn-publish button, .tpcn .tpcn-sched button, .tpcn .tpcn-unsched button, .tpcn .tpcn-saved-btn button, .tpcn .tpcn-revise button, .tpcn .tpcn-recall button { border: 2px solid var(--ink); box-shadow: 3px 3px 0 var(--ink); }
/* 버튼 줄 균형(10/25 사용자): 링크·버튼·날짜 칸이 제각각 높이라 들쭉날쭉했다. 링크는 flex 기본값(stretch) 때문에 날짜 칸 높이만큼 늘어나 있었다.
   그래서 세로 가운데 정렬 + 모두 같은 높이(36px)로 맞추고, 그림자(3px)가 옆 버튼에 닿지 않게 간격을 넓힌다 */
.tpcn .tpcn-links { align-items: center; gap: 10px 12px; }
.tpcn .tpcn-links a, .tpcn .tpcn-publish button, .tpcn .tpcn-sched button, .tpcn .tpcn-unsched button, .tpcn .tpcn-saved-btn button { box-sizing: border-box; height: 36px; padding: 0 16px; display: inline-flex; align-items: center; justify-content: center; line-height: 1; white-space: nowrap; }
.tpcn .tpcn-sched { gap: 8px; }
.tpcn .tpcn-sched input { box-sizing: border-box; height: 36px; padding: 0 14px; font-size: 13px; }
/* 기능별 두 줄(10/26 사용자 "구성 조화롭게 기능별로 정렬"): 줄 앞에 기능 이름표를 같은 너비로 두어 두 줄의 첫 버튼이 세로로 맞는다.
   예약은 날짜 칸과 버튼이 한 쌍이라 한 알약으로 묶고, 켜진 뱃지는 사이트 딱지 색(저장 노랑·좋아요 분홍)을 입힌다 */
.tpcn .tpcn-row { margin-top: 10px; }
.tpcn .tpcn-row + .tpcn-row { margin-top: 14px; }
.tpcn .tpcn-rowlabel { flex: none; width: 34px; color: var(--muted); font-size: 11.5px; font-weight: 800; letter-spacing: .04em; }
.tpcn .tpcn-sched { box-sizing: border-box; gap: 0; height: 36px; border: 2px solid var(--ink); border-radius: 999px; background: #fff; box-shadow: 3px 3px 0 var(--ink); overflow: hidden; }
.tpcn .tpcn-sched input { height: 100%; border: 0; border-radius: 0; background: transparent; }
.tpcn .tpcn-sched button { height: 100%; border: 0; border-left: 2px solid var(--ink); border-radius: 0; box-shadow: none; }
.tpcn .tpcn-saved-btn.is-saved.is-on button { background: #ffd43b; border-color: var(--ink); color: var(--ink); }
.tpcn .tpcn-saved-btn.is-liked.is-on button { background: #ffd1da; border-color: var(--ink); color: #8f1237; }
.tpcn .tpcn-check { border: 2px solid var(--ink); box-shadow: 3px 3px 0 #f2cf7c; background: #fff; }
/* 손본 것 강조(10/18 사용자, 시안 1018-10 1 색 띠): 노란 상자·버터색 카드 위에서 확인 항목이 묻혀서,
   확인 항목은 어디서든(발행 전 상자·발행 뒤 목록·수정 기록) 한 줄씩 색 띠 + 왼쪽 굵은 선, 일반 기록은 흐린 회색으로 물린다 */
.tpcn .tpcn-check ul, .tpcn .tpcn-body ul.tpcn-changes { list-style: none; padding-left: 0; display: grid; gap: 4px; }
.tpcn .tpcn-check li.lv3, .tpcn .tpcn-body ul.tpcn-changes li.lv3 { padding: 5px 10px; border-radius: 8px; background: #ffdbe4; color: #9b1c3d; font-weight: 700; border-left: 5px solid #e5484d; }
.tpcn .tpcn-check li.lv2, .tpcn .tpcn-body ul.tpcn-changes li.lv2 { padding: 5px 10px; border-radius: 8px; background: #fff1b8; color: #5c4400; font-weight: 700; border-left: 5px solid #e2b100; }
.tpcn .tpcn-body ul.tpcn-changes li.lv1 { padding-left: 10px; color: #9a8f86; }
.tpcn .tpcn-body ul.tpcn-changes li.lv1::before { content: "· "; }
.tpcn .tpcn-revise textarea { border: 2px solid var(--ink); border-radius: 14px; background: #fff; }
/* 추가 디테일 주문사항(10/25 사용자 "조금 더 티나게"): 흐린 점선 상자라 카드 제목·버튼 사이에서 묻혔다.
   포스트잇처럼 진한 노란 바탕 + 갈색 테두리·블록 그림자로 띄우고, 글자도 본문 색·한 단계 크게. 발행 카드(버터색) 위에서도 갈리도록 노랑을 더 진하게 */
.tpcn .tpcn-body .tpcn-memo { margin: 8px 4px 12px 0; padding: 10px 14px 11px; border: 2px solid var(--ink); border-radius: 12px; background: #ffe27a; box-shadow: 3px 3px 0 var(--ink); color: var(--ink); font-size: 14px; line-height: 1.55; }
.tpcn .tpcn-body .tpcn-memo b { color: #b8421c; font-size: 12.5px; letter-spacing: .02em; }
</style>

<div class="tpcn-towel" aria-hidden="true"></div>
<header class="tpcn-head">
	<button type="button" class="tpcn-face" id="tpcn-face" aria-label="쓰는 법 보기" aria-controls="tpcn-bubble">
		<img src="<?php echo esc_url( $u['face'] ); ?>" width="56" height="56" alt="셰프 모자를 쓴 트란시스 마스코트, 허스키 인형">
		<svg class="tpcn-hat" viewBox="0 0 64 50" aria-hidden="true"><path d="M15 35C4 35 2 20 13 18 12 6 27 2 32 10c5-8 21-5 19 8 11 2 9 17-2 17Z" fill="#fff" stroke="#dcc9ab" stroke-width="2.2" stroke-linejoin="round"/><rect x="15" y="32" width="34" height="13" rx="3.5" fill="#fff" stroke="#dcc9ab" stroke-width="2.2"/><path d="M24 34v9M32 34v9M40 34v9" stroke="#efe3cf" stroke-width="2.2" stroke-linecap="round"/></svg>
		<span class="tpcn-spark" aria-hidden="true">✨</span>
	</button>
	<div>
		<h1>트란시스 카드뉴스 도우미</h1>
		<p>피그마 zip을 주문서로 넣어 주면, 셰프 트란시스가 사이트 초안으로 요리해 둘게요</p>
	</div>
	<?php // 10/19 사용자: 처음 한 번만 쓰는 설치 안내 둘은 제목 줄 오른쪽 빈자리에. 누르면 아래로 말풍선처럼 떠서 주문서를 밀지 않는다 ?>
	<div class="tpcn-guides">
		<?php // 10/18 사용자: 다른 컴퓨터(성현 님)에서도 피그마 플러그인을 쉽게 받게 ?>
		<details class="tpcn-how">
			<summary>🧩 피그마 플러그인 설치</summary>
			<div class="tpcn-plug">
				<div class="tpcn-dls">
					<a class="tpcn-dl" href="<?php echo esc_url( $u['fplug'] ); ?>" download>🧩 카드뉴스 비서 받기 (zip)</a>
					<?php if ( $u['splug'] ) : ?>
					<a class="tpcn-dl" href="<?php echo esc_url( $u['splug'] ); ?>" download>🖋 맞춤법 검사 비서 받기 (zip)</a>
					<?php endif; ?>
				</div>
				<ol>
					<?php // 10/18: 윈도우에서 manifest.json만 다른 곳으로 옮겨 골랐다가 에러가 났다(code.js·ui.html이 옆에 없어서) → 맥·윈도우 압축 풀기와 '세 파일 같이'를 적어 둔다 ?>
					<li>받은 zip의 압축을 풀어요 — 맥은 <b>더블클릭</b>, 윈도우는 <b>오른쪽 클릭 → 압축 풀기</b>(더블클릭은 안을 들여다보기만 해요). <code>transis-cardnews-reader</code> 폴더가 생겨요</li>
					<li>폴더 안 <code>manifest.json</code> · <code>code.js</code> · <code>ui.html</code> 세 파일은 <b>같은 폴더에 그대로</b> 둬요. 하나만 옮기거나 폴더를 지우면 플러그인이 안 열려요</li>
					<li><b>피그마 데스크톱 앱</b>에서 아무 디자인 파일이나 열어요 (예시: 2026 트렌드포털). 웹 브라우저 피그마에선 안 돼요</li>
					<li>메뉴 <b>플러그인 → 개발 → 매니페스트에서 플러그인 가져오기…</b> → 그 폴더 안 <code>manifest.json</code> 선택 (윈도우는 메뉴가 왼쪽 위 피그마 로고 안에 있어요)</li>
					<li>이제 카드뉴스 파일에서 <b>플러그인 → 개발 → 트란시스 카드뉴스 비서</b>로 zip을 받아 여기에 올려요. 패널의 <b>"어두운 그라데이션 지우기"</b>는 켜 둔 채로 읽어요(사진 아래 검은 띠가 안 생겨요)</li>
				</ol>
				<?php if ( $u['splug'] ) : ?>
				<p class="tpcn-plug-update"><b>🖋 맞춤법 검사 비서도 같은 방법이에요</b> — 위 1~4번을 맞춤법 검사 비서 zip으로 한 번 더 해요(<code>transis-spellcheck-assistant</code> 폴더의 <code>manifest.json</code>). 그다음 <b>플러그인 → 개발 → 트란시스 맞춤법 검사 비서</b>를 열고, 처음 한 번 <b>접속 암호</b>를 넣어요. 검사할 문구가 든 프레임을 고르고 누르면 돼요</p>
				<?php endif; ?>
				<?php // 10/22: 개발용 플러그인은 자동 업데이트가 없어서, 판이 바뀌면 이미 설치한 컴퓨터도 파일을 바꿔야 한다(어두운 막 지우기 판부터). manifest.json은 그대로라 다시 가져올 필요 없음 ?>
				<p class="tpcn-plug-update"><b>이미 설치했다면 (새 판으로 바꾸기)</b> — 위 zip을 새로 받아 압축을 풀고, 안의 <code>manifest.json</code> · <code>code.js</code> · <code>ui.html</code> 세 파일을 쓰던 폴더(<code>transis-cardnews-reader</code>, 맞춤법 검사 비서는 <code>transis-spellcheck-assistant</code>)에 <b>덮어써요</b>. 판이 바뀔 때 이름 같은 설정도 같이 바뀔 수 있어서 세 파일을 모두 바꿔요. 피그마에서 다시 가져올 필요는 없어요. 플러그인을 닫았다 다시 열었을 때 패널에 <b>"어두운 그라데이션 … 지우기"</b> 칸이 보이면 새 판이에요</p>
			</div>
		</details>
		<details class="tpcn-how">
			<summary>📱 트란시스 일정표 앱 설치</summary>
			<div class="tpcn-app">
			<?php if ( $u['tapp'] ) : ?>
			<p class="tpcn-app-link"><a class="tpcn-dl" href="<?php echo esc_url( $u['tapp'] ); ?>" target="_blank" rel="noopener">일정표 열기</a>
				<button type="button" class="tpcn-nl-copy" id="tpcn-app-copy" data-url="<?php echo esc_attr( $u['tapp'] ); ?>">📋 링크 복사</button></p>
			<p class="tpcn-hint">복사한 링크를 카톡 나와의 채팅 등으로 폰에 보내거나, 폰에서 이 탭을 바로 열어도 돼요.</p>
			<?php else : ?>
			<p class="tpcn-hint">일정표 주소가 아직 설정되지 않았어요 (TP Transis Frame 설정).</p>
			<?php endif; ?>
			<ol class="tpcn-app-steps">
				<li>아이폰 <b>Safari</b>로 위 링크를 열어요 (크롬·카톡 안 브라우저는 안 돼요)</li>
				<li>아래 <b>공유 버튼 → 홈 화면에 추가</b></li>
				<li><b>홈 화면에 생긴 트란시스 아이콘</b>으로 열고 🔔 알림을 켜요. Safari 탭에서는 알림을 켤 수 없어요</li>
			</ol>
			<p class="tpcn-hint">"현재 파일을 열 수 없습니다"가 뜨면 Safari에 구글 계정이 여러 개 로그인된 거예요. Safari에서 구글 로그아웃 후 다시 열어 주세요.</p>
			</div>
		</details>
	</div>
	<div class="tpcn-bubble" id="tpcn-bubble" role="status" hidden>
		<ol>
			<li>피그마에서 카드 묶음을 선택하고 플러그인 <b>트란시스 카드뉴스 비서</b> → zip 내려받기</li>
			<li>여기에 zip · 인스타 캡션 · (있으면) 영상 카드 넣고 <b>주문 넣기</b></li>
			<li><b>완성</b>이 뜨면 미리보기로 맛보고, 셰프가 손본 것 확인한 뒤 발행!</li>
		</ol>
	</div>
</header>

	<?php if ( $msg ) : ?>
<p class="tpcn-msg <?php echo esc_attr( $msg[0] ); ?>" id="tpcn-msg"><?php echo esc_html( $msg[1] ); ?></p>
	<?php endif; ?>
<?php // 알림 A: 요리가 끝나면 여기에 뜬다 (주문서를 쓰는 중이면 새로고침 대신 이 줄로 알린다) ?>
<p class="tpcn-msg ok" id="tpcn-live" role="status" hidden></p>

<section class="tpcn-panel">
	<h2>새 주문서 <small>카드뉴스·인터뷰·광고·뉴스레터 하나 = 주문 하나</small></h2>
	<form class="tpcn-form" id="tpcn-form" method="post" action="<?php echo esc_url( $u['action'] ); ?>" enctype="multipart/form-data" data-max="<?php echo (int) $u['max']; ?>">
		<input type="hidden" name="action" value="tp_cn_order">
		<?php echo $u['nonce']; // phpcs:ignore WordPress.Security.EscapeOutput -- wp_nonce_field 결과 ?>
		<?php
		// 트란시스 영상 가이드: 종류 탭 오른쪽 빈 자리에 썸네일 카드로 나열한다.
		// 영상은 임베드하지 않고 눌렀을 때 유튜브를 새 창으로 연다 — 탭을 열 때마다 플레이어를 불러오지 않고, 주문서 화면을 그대로 둔다.
		// 영상을 늘릴 땐 아래 배열에 한 줄만 추가한다(id = 유튜브 주소의 v= 뒤 11자). 일부공개·공개 영상이어야 썸네일이 보인다.
		$tpcn_videos = array(
			array( 'id' => 'Rq5PwAXT2DI', 'title' => '뉴스레터 관리자 가이드' ),
			array( 'id' => '3QL22saUmhk', 'title' => '플러그인 설치 가이드' ),
		);
		?>
		<div class="tpcn-toprow">
			<?php // 주문 종류(1.8.0, 사용자 A): 맨 위에서 고르면 인터뷰·광고일 때만 대상(브랜드) 칸이 나타난다 ?>
			<div class="tpcn-kind" role="radiogroup" aria-label="주문 종류">
				<label><input type="radio" name="kind" value="cardnews" checked><span>📰 카드뉴스</span></label>
				<label><input type="radio" name="kind" value="interview"><span>🎤 인터뷰</span></label>
				<label><input type="radio" name="kind" value="ad"><span>📢 광고</span></label>
				<label><input type="radio" name="kind" value="newsletter"><span>📮 뉴스레터</span></label>
			</div>
			<?php if ( $tpcn_videos ) : ?>
			<nav class="tpcn-vg" aria-label="트란시스 영상 가이드">
				<b class="tpcn-vg-t">🎬 트란시스 영상 가이드</b>
				<div class="tpcn-vg-list">
				<?php foreach ( $tpcn_videos as $v ) : ?>
					<a class="tpcn-vg-card" href="<?php echo esc_url( 'https://www.youtube.com/watch?v=' . $v['id'] ); ?>" target="_blank" rel="noopener noreferrer">
						<span class="tpcn-vg-th"><img src="<?php echo esc_url( 'https://i.ytimg.com/vi/' . $v['id'] . '/mqdefault.jpg' ); ?>" alt="" width="96" height="54" loading="lazy"></span>
						<span class="tpcn-vg-name"><?php echo esc_html( $v['title'] ); ?></span>
					</a>
				<?php endforeach; ?>
				</div>
			</nav>
			<?php endif; ?>
		</div>
		<div class="tpcn-field">
			<label for="tpcn-zip">피그마 zip <em class="tpcn-must">필수</em></label>
			<div class="tpcn-drop" id="tpcn-drop">
				<span class="tpcn-ico" aria-hidden="true">📦</span>
				<div><b id="tpcn-zipname">zip을 여기에 끌어다 놓거나 눌러서 고르기</b><span>'트란시스 카드뉴스 비서'에서 받은 파일 그대로</span></div>
				<input type="file" id="tpcn-zip" name="zip" accept=".zip,application/zip" required title=""><?php // title을 비워야 브라우저 기본 말풍선("No file chosen")이 안 뜬다 ?>
			</div>
		</div>
		<div class="tpcn-field">
			<label for="tpcn-caption">인스타 캡션 <em class="tpcn-must">필수</em></label>
			<textarea id="tpcn-caption" name="caption" rows="7" required placeholder="인스타 게시물 본문을 그대로 붙여 넣어 주세요 (해시태그 줄은 알아서 빼요)"></textarea>
		</div>
		<?php // 뉴스레터 폼(1.20.0): 주간 총정리 카드뉴스 zip·캡션 그대로 + 이번 주 소개할 제보. 셰프가 사이트 주간 글 초안과 뉴스레터를 같이 만든다 ?>
		<div class="tpcn-field" id="tpcn-nl" hidden>
			<label for="tpcn-reports">이번 주 소개할 제보 <em>선택</em></label>
			<textarea id="tpcn-reports" name="reports" rows="2" placeholder="제보 글 주소를 한 줄에 하나씩 (예: https://trendportal.kr/report/?uid=5&amp;mod=document)"></textarea>
			<p class="tpcn-hint"><b>주간 총정리 zip과 캡션</b>을 넣으면 셰프가 <b>사이트 주간 글 초안</b>과 <b>뉴스레터</b>를 같이 만들어요. 뉴스레터의 주목 포인트는 카드 밖까지 찾아보고 더 길게 써요. 완성되면 여기서 뉴스레터를 미리 보고 <b>스티비 HTML을 복사</b>해 스티비에 붙여 넣으면 돼요. 소개할 제보는 10/30 호부터예요</p>
		</div>
		<?php // 인터뷰·광고가 같이 쓰는 칸. 광고면 형식 칸을 숨기고 글자만 바꾼다(아래 showKind) ?>
		<div class="tpcn-iv" id="tpcn-iv" hidden>
			<div class="tpcn-field" id="tpcn-layout-field">
				<label>인터뷰 형식 <em class="tpcn-must">필수</em></label>
				<div class="tpcn-layouts">
					<label><input type="radio" name="layout" value="qa"><span><b>질문 여러 개</b>한 브랜드·사람에게 여러 질문</span></label>
					<label><input type="radio" name="layout" value="panel"><span><b>패널</b>질문 하나에 여러 명이 답함</span></label>
				</div>
			</div>
			<div class="tpcn-field">
				<label><span id="tpcn-plabel">인터뷰 대상</span> <em id="tpcn-pmust">선택</em></label>
				<div class="tpcn-prows" id="tpcn-prows">
					<div class="tpcn-prow">
						<input type="text" name="pname[0]" placeholder="이름 (예: 짐빔)" aria-label="이름">
						<input type="url" name="pinsta[0]" placeholder="인스타 주소 (https://www.instagram.com/계정/)" aria-label="인스타 주소">
						<label class="tpcn-vfile"><input type="file" name="pfile[0]" accept="image/jpeg,image/png,image/webp" title=""><span>🖼 프로필 사진</span></label>
						<button type="button" class="tpcn-vdel" aria-label="이 줄 지우기">×</button>
					</div>
				</div>
				<button type="button" class="tpcn-vadd" id="tpcn-padd">+ 한 명 더</button>
				<p class="tpcn-hint" id="tpcn-adhint" hidden>글 맨 위 <b>[광고] 표시 바로 아래와 글 끝</b>에 브랜드 프로필 카드가 들어가요. <b>인스타 주소는 꼭</b> 넣어 주세요. 프로필 사진은 브랜드 인스타 프로필 화면을 캡처해 그대로 올리면 셰프가 동그란 사진만 잘라서 써요</p>
				<p class="tpcn-hint" id="tpcn-ivhint">글 <b>시작과 끝의 프로필 카드</b>에 들어가요. 프로필 사진은 인스타 프로필 화면을 캡처해 그대로 올려 주세요. 셰프가 동그란 프로필 사진만 잘라서 써요. 비우면 프로필 카드 없이 만들고 알려 드려요. 패널형은 카드에 계정·얼굴이 있어서 보통 비워도 돼요</p>
				<?php
				// 10/18 사용자: 프로필 캡처를 어떻게 하는지 움직이는 그림으로, 접지 않고 늘 보이게. 인터뷰·광고가 같은 칸이라 여기 하나만.
				// GIF(635KB) 대신 소리 없는 mp4(73KB): 9분의 1 크기에 영상 처리 기능으로 재생돼 가볍다.
				// autoplay를 안 거는 건 카드뉴스 주문 땐 받지도 않으려고 — 인터뷰·광고 칸이 열릴 때 showKind가 재생한다
				?>
				<div class="tpcn-cap">
					<video class="tpcn-capvid" id="tpcn-capvid" src="<?php echo esc_url( $u['pcap'] ); ?>" width="400" height="400" muted loop playsinline preload="none" aria-label="인스타 프로필 화면에서 동그란 프로필 사진에 상자를 치고 그 사진으로 확대하는 영상"></video>
					<div>
						<b>프로필 사진 캡처하는 법</b>
						<ol>
							<li>인스타에서 그 계정의 <b>프로필 화면</b>을 열어요 (PC·폰 다 돼요)</li>
							<li><b>동그란 프로필 사진만 나오면 돼요.</b> Mac은 <code>⌘ Shift 4</code>로 원 둘레를 끌어서, 폰은 스크린샷 그대로 올려도 돼요</li>
							<li>스토리 테두리(무지개 고리)가 있어도 괜찮아요. 셰프가 동그란 사진만 잘라서 써요</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
		<div class="tpcn-field">
			<label>영상 카드 <em>있을 때만</em></label>
			<div class="tpcn-vrows" id="tpcn-vrows">
				<?php // 줄 번호(i)를 이름에 박아 둔다 — 파일을 안 고른 줄이 있어도 번호·파일·주소가 같은 줄끼리 짝지어지게 ?>
				<div class="tpcn-vrow">
					<input type="number" name="vcard[0]" min="1" max="99" placeholder="카드" aria-label="카드 번호">
					<label class="tpcn-vfile"><input type="file" name="vfile[0]" accept="video/mp4,video/quicktime,video/x-m4v,video/webm,image/jpeg,image/png,image/webp" title=""><span>🎬 파일 고르기</span></label>
					<input type="url" name="vurl[0]" placeholder="원본 영상 주소 (남의 영상일 때)" aria-label="원본 영상 주소">
					<button type="button" class="tpcn-vdel" aria-label="이 줄 지우기">×</button>
				</div>
			</div>
			<button type="button" class="tpcn-vadd" id="tpcn-vadd">+ 한 줄 더</button>
			<p class="tpcn-hint"><b>주소가 있으면</b> 남의 영상 → 정지 화면 + ▶ 링크 · <b>주소 없이 영상만</b> 넣으면 우리가 찍은 영상 → 사이트에서 바로 재생</p>
			<?php // 10/17 사용자: 쓰는 법을 도우미 화면에서도 알 수 있게. 10/18: 들어오면 펼쳐진 채로 두고, 필요 없으면 접는다 → 10/26 사용자: 화면이 길어져서 기본은 접어 둔다 ?>
			<details class="tpcn-how">
				<summary>자세히 보기</summary>
				<ul>
					<li><b>카드 번호</b> = 피그마 프레임 이름 끝 숫자예요. 예: <code>트렌드포털 802-4</code> → <b>4</b> (표지가 1번이라, 카드뉴스를 넘겨 보는 순서와 같아요)</li>
					<?php // 1.27.0(10/25): 1번 카드가 영상인 새 카드뉴스 포맷(글자가 영상에 박혀 있음) ?>
					<li><b>1번 = 표지 영상</b>: 표지가 영상이고 글자가 영상에 들어 있으면 <b>카드 1 + 영상 파일 하나</b>만 넣으세요 (주소는 비워 두기). 글 맨 위에서 소리 없이 자동 재생되고, 홈 목록 카드에서도 앞 8초가 소리 없이 움직여요 (그래서 제목 글자가 앞 8초 안에 나오는 게 좋아요). 영상 장면 하나는 정지 미리보기 사진(공유·카톡)이 돼요</li>
					<li><b>주소</b> = 원래 영상이 올라간 곳의 주소. 인스타 릴스·게시물, 유튜브(일반·youtu.be·쇼츠), X를 받아요. <code>?igsh=…</code> 같은 꼬리는 알아서 떼요</li>
					<li><b>주소 + 영상 파일</b>: 셰프가 영상에서 잘 나온 장면을 골라 정지 화면으로 써요 (인스타 정지 화면보다 선명). 영상 자체는 사이트에 안 올려요</li>
					<li><b>주소 + 사진 파일</b>: 그 사진(직접 캡처한 장면)을 정지 화면으로 써요</li>
					<li><b>주소만</b>: 셰프가 원본 게시물의 정지 화면을 가져와요</li>
					<li><b>영상 파일만</b>: 우리가 찍은 영상으로 보고, 소리를 빼서 사이트에서 자동 재생돼요</li>
					<li>장면이 마음에 안 들면 완성 뒤 "고쳐 주세요"에 <code>3번 정지 화면 5초 장면으로</code>처럼 적어 주세요</li>
					<?php // 10/23 868-7: 카드 아래에 영상 링크를 글자로 적어 두었더니 그룹이 2641×2607로 커져서 플러그인이 카드로 안 치고 zip에서 뺐다(경고도 없이) ?>
					<li><b>zip에 카드 한 장이 통째로 없다면</b> (예: 7번): 플러그인은 가로세로 <b>4:5</b>(보통 2000×2500)인 카드만 읽어요. 카드 밖으로 <b>삐져나온 글자나 그림</b>이 있으면 그룹이 커져서 카드로 안 쳐요. 영상 주소는 <b>이 칸에 넣으니 피그마에는 적지 않아도 돼요</b>. 적어 뒀다면 그룹 <b>밖</b>으로 빼거나 지우고 다시 읽어 주세요</li>
					<li>한 번에 올릴 수 있는 크기는 zip과 파일을 합쳐 <b><?php echo esc_html( size_format( $u['max'] ) ); ?></b>까지예요</li>
				</ul>
			</details>
		</div>
		<div class="tpcn-field">
			<label for="tpcn-memo">추가 디테일 주문사항 <em>선택</em></label>
			<textarea id="tpcn-memo" name="memo" rows="2" placeholder="예: 카드 배경처럼 어둡게 물들여서 / 제목에 '팝업' 넣어 주세요"></textarea>
			<?php // 10/17 사용자: 메모로 무엇까지 시킬 수 있는지 화면에서 알 수 있게. 형식 이름은 docs/post-formats.md와 같게. 10/26: 기본은 접어 둔다 ?>
			<details class="tpcn-how">
				<summary>추가 디테일 주문사항으로 할 수 있는 것</summary>
				<ul>
					<li><b>인터뷰</b>는 여기 말고 맨 위 <b>🎤 인터뷰</b>를 눌러 형식·대상을 골라 주세요</li>
					<li><b>디자인</b>: <code>카드 배경처럼 어둡게 물들여서</code>처럼 적으면 이 글에만 CSS를 입혀요. 셰프는 화면을 못 보니 미리보기로 확인해 주세요</li>
					<li><b>제목·카테고리</b>: <code>제목에 '팝업' 넣어 주세요</code>, <code>카테고리는 브랜드</code></li>
					<li><b>카드에 없는 사실</b>: 인스타 계정, 바른 이름처럼 셰프가 알 수 없는 것</li>
					<li>아직 못 하는 것: 카피 모음형 디자인(지금은 일본 카피 글에만 써요)</li>
					<li>완성 뒤 고칠 것은 "고쳐 주세요"에 같은 식으로 적으면 돼요</li>
				</ul>
			</details>
		</div>
		<div class="tpcn-field" id="tpcn-saved">
			<?php foreach ( TP_CN_BADGES as $key => $badge ) : ?>
			<label class="tpcn-saved"><input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1"> <?php echo esc_html( $badge['icon'] ); ?> 인스타 <?php echo esc_html( $badge['label'] ); ?> 1,000+ <em>선택</em></label>
			<?php endforeach; ?>
			<p class="tpcn-hint">인사이트에서 저장이나 좋아요가 <b>1,000번 넘은</b> 카드면 체크해 주세요(둘 다 체크해도 돼요). 사이트 카드에 <b>저장 1,000+</b>·<b>좋아요 1,000+</b> 뱃지가 붙어요. 나중에 넘으면 주문 현황의 버튼으로 붙이면 돼요</p>
		</div>
		<button type="submit" class="tpcn-go" id="tpcn-go">주문 넣기</button>
	</form>
</section>

<section class="tpcn-panel">
	<h2>주문 현황 <small><?php echo $u['more'] ? '최근 ' . (int) $u['show'] . '개' : '전체 ' . count( $orders ) . '개'; ?></small></h2>
	<?php if ( ! $orders ) : ?>
	<div class="tpcn-empty">
		<img src="<?php echo esc_url( $u['rest'] ); ?>" width="180" alt="쉬고 있는 트란시스">
		<p>아직 주문이 없어요. 셰프 트란시스는 쉬는 중!</p>
	</div>
	<?php else : ?>
	<ol class="tpcn-list">
		<?php
		foreach ( $orders as $i => $o ) :
			$s = isset( TP_CN_STATUS[ $o['status'] ] ) ? $o['status'] : 'new';
			// 더 보기로 새로 펼친 첫 주문(= 지난번 마지막 다음)에 책갈피
			$next = $i > 0 && $i === $u['show'] - TP_CN_PAGE ? ' id="tpcn-next"' : '';
			// 발행된 주문은 '완성' 대신 '발행됨' 딱지(10/18 사용자). 화면 표시만 바꾸고 저장된 상태는 그대로 done
			$pub = 'done' === $s && 'publish' === $o['post_status'];
			?>
		<li<?php echo $next; // phpcs:ignore WordPress.Security.EscapeOutput -- 고정 문자열 ?> class="tpcn-item s-<?php echo esc_attr( $s ); ?> is-<?php echo esc_attr( $s ); ?><?php echo $pub ? ' is-pub' : ''; ?><?php echo $o['finished'] > $u['seen'] ? ' is-fresh' : ''; ?>" data-id="<?php echo (int) $o['id']; ?>" data-status="<?php echo esc_attr( $s ); ?>">
			<span class="tpcn-no" title="주문 번호"><?php echo (int) $o['id']; ?></span>
			<div>
				<h3><?php // 주문 종류는 모든 주문에 붙인다(10/17 사용자). 1.8.0 전 주문은 kind가 없어 카드뉴스로 나온다 ?><?php if ( 'interview' === $o['kind'] ) : ?><span class="tpcn-tag is-iv">🎤 인터뷰 · <?php echo esc_html( TP_CN_LAYOUTS[ $o['layout'] ] ?? '형식 미정' ); ?></span><?php elseif ( 'ad' === $o['kind'] ) : ?><span class="tpcn-tag is-sponsor">📢 광고</span><?php elseif ( 'newsletter' === $o['kind'] ) : ?><span class="tpcn-tag is-nl">📮 뉴스레터</span><?php else : ?><span class="tpcn-tag">📰 카드뉴스</span><?php endif; ?><?php echo esc_html( $o['group'] ); ?><?php if ( $o['finished'] > $u['seen'] ) : ?> <span class="tpcn-fresh">방금 나왔어요</span><?php endif; ?></h3>
				<p class="tpcn-when"><?php echo esc_html( $fmt( $o['created'] ) ); ?> 주문</p>
			</div>
			<span class="tpcn-chip<?php echo $pub ? ' is-pub' : ''; ?>"><?php echo esc_html( $pub ? '발행됨' : ( ( 'done' === $s && 'future' === $o['post_status'] ) ? '예약됨' : TP_CN_STATUS[ $s ] ) ); ?></span>
			<div class="tpcn-body">
			<?php if ( '' !== trim( (string) $o['memo'] ) ) : // 10/25 사용자: 처음 주문할 때 쓴 메모도 내역에 남긴다. 어느 상태든 맨 위에 ?>
				<p class="tpcn-memo">📝 <b>추가 디테일 주문사항</b><br><?php echo nl2br( esc_html( $o['memo'] ) ); ?></p>
			<?php endif; ?>
			<?php if ( 'new' === $s ) : ?>
				<?php if ( null === tp_cn_recall_reason( $o, $u['now'] ) ) : // 초인종이 실패했으면 "곧 가져가요"는 틀린 말이라 아래 이유만 ?>
				<p>셰프 트란시스가 곧 주문서를 가져가요.</p>
				<?php endif; ?>
			<?php elseif ( 'revise' === $s ) : ?>
				<p>✏️ <?php echo esc_html( $o['feedback'] ); ?></p>
				<?php if ( null === tp_cn_recall_reason( $o, $u['now'] ) ) : ?>
				<p>셰프 트란시스가 곧 와서 같은 초안을 고쳐요.</p>
				<?php endif; ?>
			<?php elseif ( 'question' === $s ) : ?>
				<?php // 셰프가 추측하지 않고 물은 것. 답하면 셰프가 하던 데서 이어 만든다 ?>
				<p class="tpcn-q">🙋 <b>셰프가 물어봐요</b><br><?php echo nl2br( esc_html( $o['question'] ) ); ?></p>
				<form class="tpcn-revise tpcn-answer" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
					<input type="hidden" name="action" value="tp_cn_answer">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_answer_' . (int) $o['id'] ); ?>
					<textarea name="answer" rows="2" required placeholder="답을 적어 주세요"></textarea>
					<button type="submit">💬 답하고 이어서 요리</button>
				</form>
			<?php elseif ( 'answered' === $s ) : ?>
				<p class="tpcn-q">🙋 <?php echo nl2br( esc_html( $o['question'] ) ); ?><br>💬 <?php echo esc_html( $o['answer'] ); ?></p>
				<?php if ( null === tp_cn_recall_reason( $o, $u['now'] ) ) : ?>
				<p>셰프 트란시스가 곧 와서 이어서 만들어요.</p>
				<?php endif; ?>
			<?php elseif ( 'working' === $s ) : ?>
				<p><?php echo $o['feedback'] ? '✏️ ' . esc_html( $o['feedback'] ) . ' — 고치는 중이에요.' : '사진을 고르고 글을 굽는 중이에요.'; ?></p>
			<?php elseif ( 'failed' === $s ) : ?>
				<p><?php echo esc_html( $o['error'] ?: '이유를 남기지 못하고 주방이 멈췄어요.' ); ?></p>
				<?php if ( $o['post_id'] ) : // 수정 중에 멈춰도 지난 초안은 그대로 있다 ?>
				<div class="tpcn-links">
					<a href="<?php echo esc_url( home_url( '/?p=' . (int) $o['post_id'] . '&preview=true' ) ); ?>" target="_blank" rel="noopener">지난 초안 미리보기</a>
					<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $o['post_id'] . '&action=edit' ) ); ?>">편집기에서 열기</a>
				</div>
				<?php endif; ?>
				<?php if ( $o['has_zip'] || $o['has_state'] ) : // 1.28.0: 멈춘 이유를 읽고 바로 답하기. 다시 요리할 재료(zip·작업 기록)가 없으면 말해도 소용없어서 칸을 안 둔다 ?>
				<form class="tpcn-revise" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
					<input type="hidden" name="action" value="tp_cn_revise">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_revise_' . (int) $o['id'] ); ?>
					<textarea name="feedback" rows="2" required placeholder="셰프에게 한마디 — 예: 3번 사진은 그냥 빼고 만들어 줘 / 제목은 원본 그대로 써 줘"></textarea>
					<button type="submit">✏️ 말하고 다시 요리</button>
				</form>
				<?php endif; ?>
			<?php else : ?>
				<?php if ( $o['title'] ) : ?>
				<p class="tpcn-title"><?php echo esc_html( $o['title'] ); ?></p>
				<?php endif; ?>
				<?php if ( $o['post_id'] ) : ?>
					<?php // 10/26 사용자: 버튼을 기능별로 두 줄로 나눈다 — 발행 줄(미리보기·발행·예약)과 뱃지 줄(저장·좋아요) ?>
					<div class="tpcn-links tpcn-row">
						<span class="tpcn-rowlabel">발행</span>
					<?php if ( 'publish' === $o['post_status'] ) : ?>
					<a class="main" href="<?php echo esc_url( get_permalink( (int) $o['post_id'] ) ); ?>" target="_blank" rel="noopener">✅ 발행됨 · 글 보기</a>
					<?php else : ?>
					<a class="main" href="<?php echo esc_url( home_url( '/?p=' . (int) $o['post_id'] . '&preview=true' ) ); ?>" target="_blank" rel="noopener">미리보기</a>
					<?php $sched = 'future' === $o['post_status']; // 1.26.0: 예약 중인 글 ?>
					<?php if ( $sched ) : ?>
					<span class="tpcn-sched-on">⏰ 예약됨 · <?php echo esc_html( mysql2date( 'n월 j일 H:i', $o['post_date'] ) ); ?> 공개</span>
					<form class="tpcn-unsched" method="post" action="<?php echo esc_url( $u['action'] ); ?>" onsubmit="return confirm('예약을 취소할까요? 초안으로 돌아가요.');">
						<input type="hidden" name="action" value="tp_cn_unschedule">
						<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
						<?php wp_nonce_field( 'tp_cn_unschedule_' . (int) $o['id'] ); ?>
						<button type="submit">예약 취소</button>
					</form>
					<?php endif; ?>
					<?php // 10/18 사용자: 편집기를 거치지 않고 탭에서 바로 발행. 누르기 전에 한 번 묻는다 ?>
					<form class="tpcn-publish" method="post" action="<?php echo esc_url( $u['action'] ); ?>" onsubmit="return confirm('<?php echo $sched ? '예약을 건너뛰고 지금 발행할까요? 바로 공개돼요.' : '이 초안을 사이트에 발행할까요? 발행하면 바로 공개돼요.'; ?>');">
						<input type="hidden" name="action" value="tp_cn_publish">
						<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
						<?php wp_nonce_field( 'tp_cn_publish_' . (int) $o['id'] ); ?>
						<button type="submit"><?php echo $sched ? '🚀 지금 발행' : '🚀 발행'; ?></button>
					</form>
					<?php if ( ! $sched ) : // 10/23 사용자: 금요일 08:30 같은 시각에 자동으로 공개. 시각 칸은 다가오는 금요일 08:30으로 채워 둔다 ?>
					<form class="tpcn-sched" method="post" action="<?php echo esc_url( $u['action'] ); ?>" onsubmit="return confirm('선택한 시각에 사이트에 자동으로 공개할까요?');">
						<input type="hidden" name="action" value="tp_cn_schedule">
						<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
						<?php wp_nonce_field( 'tp_cn_schedule_' . (int) $o['id'] ); ?>
						<input type="datetime-local" name="when" required value="<?php echo esc_attr( tp_cn_default_when() ); ?>" aria-label="예약 시각">
						<button type="submit">⏰ 예약 발행</button>
					</form>
					<?php endif; ?>
					<?php endif; ?>
					</div>
					<?php if ( 'newsletter' !== $o['kind'] ) : // 발행 뒤에 1,000을 넘는 글이 많아서 발행 전·후 모두 누를 수 있게 ?>
					<div class="tpcn-links tpcn-row">
						<span class="tpcn-rowlabel">뱃지</span>
					<?php foreach ( TP_CN_BADGES as $key => $badge ) : ?>
					<form class="tpcn-saved-btn is-<?php echo esc_attr( $key ); ?><?php echo $o[ $key ] ? ' is-on' : ''; ?>" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
						<input type="hidden" name="action" value="tp_cn_badge">
						<input type="hidden" name="badge" value="<?php echo esc_attr( $key ); ?>">
						<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
						<?php wp_nonce_field( 'tp_cn_badge_' . (int) $o['id'] . '_' . $key ); ?>
						<button type="submit" title="<?php echo $o[ $key ] ? '누르면 뱃지를 떼요' : esc_attr( $badge['hint'] ); ?>"><?php echo esc_html( $badge['icon'] . ' ' . $badge['label'] . ' 1,000+ ' . ( $o[ $key ] ? '붙음' : '붙이기' ) ); ?></button>
					</form>
					<?php endforeach; ?>
					</div>
					<?php endif; ?>
				<?php endif; ?>
				<?php
				if ( 'newsletter' === $o['kind'] && $o['has_newsletter'] ) :
					$nl = (string) get_post_meta( $o['id'], '_tp_cn_newsletter', true );
					?>
				<?php // 뉴스레터: 스티비 HTML 편집기에 붙여 넣을 HTML을 복사 + 메일 모양 미리보기(스크립트 막은 iframe) ?>
				<div class="tpcn-nlbox">
					<button type="button" class="tpcn-nl-copy" data-src="tpcn-nlsrc-<?php echo (int) $o['id']; ?>">📋 스티비 HTML 복사</button>
					<span class="tpcn-nl-note">사이트 주간 글은 금요일 08:30, 인스타·뉴스레터와 같이 발행해 주세요 (⏰ 예약 발행도 돼요)</span>
					<textarea id="tpcn-nlsrc-<?php echo (int) $o['id']; ?>" hidden readonly><?php echo esc_textarea( $nl ); ?></textarea>
					<details class="tpcn-how">
						<summary>📮 뉴스레터 미리보기</summary>
						<iframe class="tpcn-nl-frame" sandbox title="뉴스레터 미리보기" srcdoc="<?php echo esc_attr( $nl ); ?>"></iframe>
					</details>
				</div>
				<?php endif; ?>
				<?php
				if ( $o['changes'] ) :
					// 확인 항목(❗·🟡)은 위로 모은다. 발행 전엔 "발행 전에 봐 주세요" 상자로 늘 펼쳐 두고(시안 1018-1 C),
					// 발행 뒤엔 다 본 것이니 상자 없이 접힌 목록 맨 위에 둔다
					$checks = array_values( array_filter( $o['changes'], fn( $c ) => tp_cn_level( $c )[0] > 1 ) );
					usort( $checks, fn( $a, $b ) => tp_cn_level( $b )[0] <=> tp_cn_level( $a )[0] );
					$rest = array_values( array_filter( $o['changes'], fn( $c ) => 1 === tp_cn_level( $c )[0] ) );
					$box  = $checks && ! $pub;
					$fold = $box ? $rest : array_merge( $checks, $rest );
					?>
				<?php if ( $box ) : ?>
				<div class="tpcn-check">
					<b>👀 발행 전에 봐 주세요 (<?php echo count( $checks ); ?>)</b>
					<ul><?php foreach ( $checks as $c ) { echo tp_cn_change_li( $c ); } // phpcs:ignore WordPress.Security.EscapeOutput -- 안에서 esc_html ?></ul>
				</div>
				<?php endif; ?>
				<?php if ( $fold ) : ?>
				<details>
					<summary><?php echo $box ? '셰프가 알아서 고친 것' : '셰프가 손본 것'; ?> <?php echo count( $fold ); ?>건</summary>
					<ul class="tpcn-changes"><?php foreach ( $fold as $c ) { echo tp_cn_change_li( $c ); } // phpcs:ignore WordPress.Security.EscapeOutput -- 안에서 esc_html ?></ul>
				</details>
				<?php endif; ?>
				<?php endif; ?>
				<?php if ( $o['rounds'] ) : ?>
				<ol class="tpcn-rounds">
					<?php foreach ( $o['rounds'] as $i => $r ) : ?>
					<li><b><?php echo (int) $i + 1; ?>차 수정</b> · <?php echo esc_html( $r['feedback'] ); ?>
						<?php if ( ! empty( $r['changes'] ) ) : ?>
						<ul class="tpcn-changes"><?php foreach ( $r['changes'] as $c ) { echo tp_cn_change_li( $c ); } // phpcs:ignore WordPress.Security.EscapeOutput -- 안에서 esc_html ?></ul>
						<?php endif; ?>
					</li>
					<?php endforeach; ?>
				</ol>
				<?php endif; ?>
				<?php if ( $o['post_id'] && ! $pub ) : // 발행된 글은 셰프가 고치지 않는다(draft의 guard가 막음) ?>
				<?php // 10/17 사용자: Claude Code 없이 관리자 창에서 메모로 고치기. 셰프가 같은 초안을 고치고 위 기록에 쌓인다 ?>
				<form class="tpcn-revise" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
					<input type="hidden" name="action" value="tp_cn_revise">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_revise_' . (int) $o['id'] ); ?>
					<textarea name="feedback" rows="2" required placeholder="고쳐 주세요 — 예: 제목을 더 짧게 / 3번 설명 두 문단으로 / 카테고리는 브랜드로"></textarea>
					<button type="submit">✏️ 다시 요리</button>
				</form>
				<?php endif; ?>
			<?php endif; ?>
			<?php
			$why = tp_cn_recall_reason( $o, $u['now'] );
			if ( null !== $why ) :
				?>
				<form class="tpcn-recall" method="post" action="<?php echo esc_url( $u['action'] ); ?>">
					<?php if ( '' !== $why ) : ?>
					<p><?php echo esc_html( $why ); ?></p>
					<?php endif; ?>
					<input type="hidden" name="action" value="tp_cn_recall">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_recall_' . (int) $o['id'] ); ?>
					<button type="submit">🔔 셰프 다시 부르기</button>
				</form>
			<?php endif; ?>
			<?php if ( 'working' !== $s ) : // 요리 중엔 못 지운다(셰프가 일하는 중) ?>
				<form class="tpcn-del" method="post" action="<?php echo esc_url( $u['action'] ); ?>" onsubmit="return confirm('주문 <?php echo (int) $o['id']; ?>을 지울까요?\n아직 발행 안 한 임시글과 셰프가 올린 사진도 같이 지워져요. 되돌릴 수 없어요.');">
					<input type="hidden" name="action" value="tp_cn_delete">
					<input type="hidden" name="order" value="<?php echo (int) $o['id']; ?>">
					<?php wp_nonce_field( 'tp_cn_delete_' . (int) $o['id'] ); ?>
					<button type="submit">🗑 주문 지우기</button>
				</form>
			<?php endif; ?>
			</div>
		</li>
		<?php endforeach; ?>
	</ol>
		<?php if ( $u['more'] ) : ?>
	<a class="tpcn-more" href="<?php echo esc_url( $u['more'] ); ?>">지난 주문 <?php echo (int) TP_CN_PAGE; ?>개 더 보기 ↓</a>
		<?php endif; ?>
	<?php endif; ?>
</section>

<?php // 초인종 설정: 처음 한 번과 열쇠를 바꿀 때만 쓰니 접어 둔다. 열쇠는 저장 뒤 다시 보여 주지 않는다 ?>
<details class="tpcn-panel tpcn-bell"<?php echo empty( $u['bell']['token'] ) ? ' open' : ''; ?>>
	<summary>🔔 셰프 초인종 설정 <small><?php echo empty( $u['bell']['token'] ) ? '아직 설정 안 됨 — 주문해도 셰프가 오지 않아요' : '연결됨'; ?></small></summary>
	<form method="post" action="<?php echo esc_url( $u['action'] ); ?>">
		<input type="hidden" name="action" value="tp_cn_bell">
		<?php wp_nonce_field( 'tp_cn_bell' ); ?>
		<p class="tpcn-hint">claude.ai/code/routines → 셰프 routine → Edit → API 트리거에서 받은 주소와 열쇠를 넣어 주세요.</p>
		<div class="tpcn-field">
			<label for="tpcn-bell-url">주소</label>
			<input type="url" id="tpcn-bell-url" name="bell_url" required value="<?php echo esc_attr( $u['bell']['url'] ?? '' ); ?>" placeholder="https://api.anthropic.com/v1/claude_code/routines/trig_…/fire">
		</div>
		<div class="tpcn-field">
			<label for="tpcn-bell-token">열쇠 <em><?php echo empty( $u['bell']['token'] ) ? '필수' : '바꿀 때만 — 비워 두면 그대로'; ?></em></label>
			<input type="password" id="tpcn-bell-token" name="bell_token" autocomplete="off" <?php echo empty( $u['bell']['token'] ) ? 'required' : ''; ?> placeholder="sk-ant-…">
		</div>
		<button type="submit" class="tpcn-go">저장</button>
	</form>
</details>

<script>
(() => {
	const $ = id => document.getElementById(id);
	// 얼굴을 누르면 꼬리 흔들기 + 쓰는 법 말풍선 (8초 뒤 저절로 닫힘)
	let t;
	$('tpcn-face').addEventListener('click', () => {
		const open = $('tpcn-bubble').hidden;
		$('tpcn-bubble').hidden = !open;
		$('tpcn-face').classList.remove('wag');
		void $('tpcn-face').offsetWidth;
		$('tpcn-face').classList.add('wag');
		clearTimeout(t);
		if (open) t = setTimeout(() => { $('tpcn-bubble').hidden = true; }, 8000);
	});
	// zip 칸: 고른 파일 이름을 보여 주고, 끌어다 놓을 때 상자 색을 바꾼다
	const drop = $('tpcn-drop'), zip = $('tpcn-zip');
	zip.addEventListener('change', () => {
		const f = zip.files[0];
		drop.classList.toggle('has-file', !!f);
		$('tpcn-zipname').textContent = f ? `${f.name} · ${(f.size / 1048576).toFixed(1)}MB` : 'zip을 여기에 끌어다 놓거나 눌러서 고르기';
	});
	['dragenter', 'dragover'].forEach(e => zip.addEventListener(e, () => drop.classList.add('is-over')));
	['dragleave', 'drop'].forEach(e => zip.addEventListener(e, () => drop.classList.remove('is-over')));
	// 줄 칸(영상 카드 줄, 인터뷰 대상 줄): 파일 이름 보여 주기, 줄 더하기·지우기. 새 줄은 첫 줄을 복사해 이름의 [번호]만 바꾼다
	const lines = (list, add, label) => {
		let next = 1;
		const fresh = row => {
			row.querySelectorAll('input').forEach(i => { i.value = ''; });
			const box = row.querySelector('.tpcn-vfile');
			box.classList.remove('has-file');
			box.querySelector('span').textContent = label;
		};
		list.addEventListener('change', e => {
			if (e.target.type !== 'file') return;
			const f = e.target.files[0], box = e.target.closest('.tpcn-vfile');
			box.classList.toggle('has-file', !!f);
			box.querySelector('span').textContent = f ? `${f.name} · ${(f.size / 1048576).toFixed(1)}MB` : label;
		});
		list.addEventListener('click', e => {
			if (!e.target.classList.contains('tpcn-vdel')) return;
			const row = e.target.parentElement;
			// 마지막 한 줄은 지우지 않고 비우기만 한다(칸이 사라지면 다시 넣을 곳이 없어서)
			if (list.children.length > 1) row.remove(); else fresh(row);
		});
		add.addEventListener('click', () => {
			const row = list.firstElementChild.cloneNode(true);
			row.querySelectorAll('input').forEach(i => { i.name = i.name.replace(/\[\d+\]/, `[${next}]`); });
			next++;
			fresh(row);
			list.append(row);
			row.querySelector('input').focus();
		});
	};
	const rows = $('tpcn-vrows'), people = $('tpcn-prows');
	lines(rows, $('tpcn-vadd'), '🎬 파일 고르기');
	lines(people, $('tpcn-padd'), '🖼 프로필 사진');
	// 주문 종류: 인터뷰면 형식(꼭 고름) + 대상 칸, 광고면 같은 칸을 광고 브랜드 칸으로(인스타 주소 필수) 보여 준다
	const kind = () => $('tpcn-form').querySelector('input[name=kind]:checked').value;
	const showKind = () => {
		const iv = kind() === 'interview', ad = kind() === 'ad';
		$('tpcn-nl').hidden = kind() !== 'newsletter';
		$('tpcn-saved').hidden = kind() === 'newsletter';
		$('tpcn-iv').hidden = !(iv || ad);
		$('tpcn-layout-field').hidden = !iv;
		$('tpcn-form').querySelector('input[name=layout]').required = iv;
		$('tpcn-plabel').textContent = ad ? '광고 브랜드' : '인터뷰 대상';
		$('tpcn-pmust').textContent = ad ? '필수' : '선택';
		$('tpcn-pmust').className = ad ? 'tpcn-must' : '';
		$('tpcn-padd').textContent = ad ? '+ 브랜드 하나 더' : '+ 한 명 더';
		$('tpcn-adhint').hidden = !ad;
		$('tpcn-ivhint').hidden = ad;
		// 첫 줄 인스타 주소만 브라우저에서 바로 막는다(서버도 같은 검사를 한다)
		$('tpcn-prows').querySelector('input[type=url]').required = ad;
		// 캡처 안내 영상: 칸이 보일 때만 재생(소리 없는 영상이라 자동 재생이 막히지 않는다)
		const vid = $('tpcn-capvid');
		if (iv || ad) vid.play().catch(() => {}); else vid.pause();
	};
	$('tpcn-form').querySelectorAll('input[name=kind]').forEach(r => r.addEventListener('change', showKind));
	// 뉴스레터 HTML 복사: 클립보드가 막힌 브라우저면 글자를 골라 놓고 직접 복사하게
	document.querySelectorAll('.tpcn-nl-copy').forEach(b => b.addEventListener('click', async () => {
		const src = $(b.dataset.src).value;
		try { await navigator.clipboard.writeText(src); b.textContent = '✅ 복사했어요 — 스티비 HTML 편집기에 붙여 넣으세요'; }
		catch (e) { const t = $(b.dataset.src); t.hidden = false; t.select(); b.textContent = '글자를 골라 뒀어요 — Ctrl/⌘ + C로 복사해 주세요'; }
	}));
	// 트란시스 앱 링크 복사: 클립보드가 막히면 주소를 띄워 직접 복사하게
	const appCopy = $('tpcn-app-copy');
	if (appCopy) appCopy.addEventListener('click', async () => {
		try { await navigator.clipboard.writeText(appCopy.dataset.url); appCopy.textContent = '✅ 복사했어요'; }
		catch (e) { prompt('이 주소를 복사해 주세요', appCopy.dataset.url); }
	});
	showKind();
	// 큰 zip은 올리는 데 시간이 걸려서, 두 번 누르지 않게 버튼을 잠근다.
	// 서버 한도를 넘으면 다 올린 뒤에야 실패해서, 보내기 전에 합계를 재서 막는다
	$('tpcn-form').addEventListener('submit', e => {
		const files = [...$('tpcn-form').querySelectorAll('input[type=file]')].flatMap(i => [...i.files]);
		const total = files.reduce((s, f) => s + f.size, 0), max = Number($('tpcn-form').dataset.max);
		if (max && total > max) {
			e.preventDefault();
			alert(`파일을 합쳐 ${(total / 1048576).toFixed(1)}MB라 한 번에 못 보내요 (최대 ${(max / 1048576).toFixed(0)}MB).\n영상을 짧게 자르거나, 정지 화면 사진으로 바꿔 주세요.`);
			return;
		}
		$('tpcn-go').disabled = true;
		$('tpcn-go').textContent = '올리는 중…';
	});

	// ── 알림 A(10/17 사용자 결정 A+B): 접수·요리 중인 주문이 있으면 20초마다 상태를 확인한다 ──
	// 바뀐 게 있으면: 주문서를 쓰는 중이 아니면 새로고침해서 목록을 다시 그리고, 쓰는 중이면 알림 줄만 띄운다(쓰던 내용을 날리지 않게)
	const base = document.title;
	const items = [...document.querySelectorAll('.tpcn-item')];
	const known = Object.fromEntries(items.map(li => [li.dataset.id, li.dataset.status]));
	const waiting = () => Object.values(known).some(s => s === 'new' || s === 'revise' || s === 'answered' || s === 'working');
	const typing = () => zip.files.length || ['tpcn-caption', 'tpcn-memo'].some(id => $(id).value.trim())
		|| [...rows.querySelectorAll('input'), ...people.querySelectorAll('input')].some(i => (i.files ? i.files.length : i.value.trim()))
		|| $('tpcn-reports').value.trim();
	const FLASH = 'tpcn-flash', LAST = 'tpcn-reloaded';
	const done = { done: '✅ 완성', failed: '⚠️ 주방 멈춤', question: '🙋 셰프가 물어봐요' };
	const clean = location.pathname + '?page=<?php echo esc_js( TP_CN_SLUG ); ?>';
	// 주문 직후 붙은 ?tp_cn_ok= 꼬리를 주소창에서 지운다 — 그대로 새로고침하면 "곧 시작해요" 알림이 또 뜨던 문제(10/17)
	if (/[?&]tp_cn_(ok|err|info|rev)=/.test(location.search)) history.replaceState(null, '', clean);

	// 새로고침 뒤: 무엇이 끝났는지 위에 띄우고, 다른 탭을 보고 있었다면 탭 제목으로도 알린다
	try {
		const f = sessionStorage.getItem(FLASH);
		if (f) {
			sessionStorage.removeItem(FLASH);
			$('tpcn-live').textContent = f;
			$('tpcn-live').hidden = false;
			if (document.hidden) document.title = f.split(' · ')[0] + ' · ' + base;
		}
	} catch (e) {}
	document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(() => { document.title = base; }, 2500); });

	async function check() {
		let list;
		try {
			const r = await fetch(document.getElementById('tpcn').dataset.poll, { headers: { 'X-WP-Nonce': document.getElementById('tpcn').dataset.nonce }, credentials: 'same-origin' });
			if (!r.ok) return;
			list = await r.json();
		} catch (e) { return; }
		const changed = list.filter(o => known[o.id] !== undefined && known[o.id] !== o.status);
		if (!changed.length) return;
		changed.forEach(o => { known[o.id] = o.status; });
		const ends = changed.filter(o => done[o.status]);
		const text = ends.length
			? ends.map(o => `${done[o.status]} · 주문 ${o.id} ${o.group}`).join('  /  ') + (ends.some(o => o.status === 'done') ? ' — 미리보기로 맛보세요!' : '')
			: `🍳 주문 ${changed[0].id} 요리를 시작했어요`;
		if (ends.length && document.hidden) document.title = done[ends[0].status] + ' · ' + base;
		// 30초 안에 또 새로고침하지 않는다: 혹시 화면과 서버 상태가 계속 어긋나도 새로고침이 끝없이 돌지 않게
		let recent = false;
		try { recent = Date.now() - Number(sessionStorage.getItem(LAST) || 0) < 30000; } catch (e) {}
		if (!typing() && !recent) {
			try { sessionStorage.setItem(FLASH, text); sessionStorage.setItem(LAST, String(Date.now())); } catch (e) {}
			location.replace(clean);
			return;
		}
		$('tpcn-live').innerHTML = '';
		$('tpcn-live').append(text, Object.assign(document.createElement('button'), { type: 'button', className: 'tpcn-live-btn', textContent: '목록 새로 보기', onclick: () => location.reload() }));
		$('tpcn-live').hidden = false;
	}
	(function loop() {
		if (!waiting()) return; // 기다릴 주문이 없으면 확인하지 않는다
		setTimeout(async () => { await check(); loop(); }, 20000);
	})();
})();
</script>
</div>
	<?php
}
